/* RAFAELIA ROOT OPTIMIZER - Turbo C / ANSI C subset
   Uso conceitual antigo: RAFOPT.EXE EXAMPLE.CMI
   Emite ASM textual ARM64-like. Sem C99.
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void trim(char *s) {
    int i, j, len;
    while (isspace((unsigned char)*s)) memmove(s, s+1, strlen(s));
    len = strlen(s);
    while (len > 0 && isspace((unsigned char)s[len-1])) s[--len] = 0;
    if (len > 0 && s[len-1] == ';') s[len-1] = 0;
}

void emit_line(char *line) {
    char *eq, *op, dst[64], expr[128], a[64], b[64];
    long imm;
    trim(line);
    if (line[0] == 0) return;
    if (line[0] == '#' || (line[0] == '/' && line[1] == '/')) return;

    if (strncmp(line, "if", 2) == 0) {
        printf("// cmp candidate: %s\n", line);
        return;
    }

    eq = strchr(line, '=');
    if (!eq) {
        printf("// raw: %s\n", line);
        return;
    }

    *eq = 0;
    strcpy(dst, line);
    strcpy(expr, eq + 1);
    trim(dst);
    trim(expr);

    if ((expr[0] == '-' && isdigit((unsigned char)expr[1])) || isdigit((unsigned char)expr[0])) {
        imm = atol(expr);
        printf("mov %s, #%ld    // %s = %s\n", dst, imm, dst, expr);
        return;
    }

    op = strchr(expr, '+');
    if (!op) op = strchr(expr, '-');

    if (op) {
        char opch = *op;
        *op = 0;
        strcpy(a, expr);
        strcpy(b, op + 1);
        trim(a); trim(b);
        printf("mov %s, %s    // %s <- %s\n", dst, a, dst, a);
        if (opch == '+') printf("add %s, %s, #%s\n", dst, dst, b);
        else printf("sub %s, %s, #%s\n", dst, dst, b);
    } else {
        printf("mov %s, %s\n", dst, expr);
    }
}

int main(int argc, char **argv) {
    FILE *f;
    char line[256];
    if (argc < 2) {
        fprintf(stderr, "usage: RAFOPT <file>\n");
        return 1;
    }
    f = fopen(argv[1], "r");
    if (!f) {
        fprintf(stderr, "cannot open file\n");
        return 1;
    }
    printf("; RAFAELIA ROOT OPTIMIZER - Turbo C ARM64-like\n");
    while (fgets(line, sizeof(line), f)) emit_line(line);
    fclose(f);
    return 0;
}
