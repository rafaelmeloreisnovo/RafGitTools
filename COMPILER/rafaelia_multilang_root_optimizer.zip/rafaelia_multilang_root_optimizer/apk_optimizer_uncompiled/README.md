# APK Optimizer não compilado

Ferramenta segura de auditoria/otimização estrutural de APK como ZIP.

Faz:
- lê APK como arquivo ZIP
- lista compressão por entrada
- detecta arquivos possivelmente já comprimidos
- aponta candidatos de ganho
- gera relatório JSON
- opcionalmente cria cópia ZIP recomprimida sem decompilar e sem assinar

Não faz:
- não decompila DEX
- não modifica código
- não remove assinatura
- não assina APK
- não contorna proteção
- não extrai credenciais
- não altera app de terceiros sem autorização

Use apenas em APK próprio ou autorizado.
