#!/usr/bin/env python3
"""
RAFAELIA APK STRUCTURE OPTIMIZER - SOURCE ONLY

Modo seguro:
- APK tratado como ZIP.
- Sem decompilar DEX.
- Sem assinar.
- Sem bypass.
- Sem mexer em código.
- Use apenas em APK próprio/autorizado.
"""

import argparse, zipfile, json, os, hashlib
from pathlib import Path

ALREADY_COMPRESSED = {
    ".png", ".jpg", ".jpeg", ".webp", ".mp3", ".mp4", ".ogg", ".m4a",
    ".apk", ".zip", ".gz", ".xz", ".7z", ".so", ".dex", ".arsc"
}

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def audit(apk_path):
    rows = []
    with zipfile.ZipFile(apk_path, "r") as z:
        for info in z.infolist():
            ext = Path(info.filename).suffix.lower()
            compressed = info.compress_size
            raw = info.file_size
            ratio = 0.0 if raw == 0 else 1.0 - (compressed / raw)
            rows.append({
                "name": info.filename,
                "raw_size": raw,
                "compressed_size": compressed,
                "compression_ratio": round(ratio, 4),
                "method": info.compress_type,
                "already_compressed_ext": ext in ALREADY_COMPRESSED,
                "candidate_note": candidate_note(info.filename, raw, compressed, ext),
            })
    total_raw = sum(r["raw_size"] for r in rows)
    total_comp = sum(r["compressed_size"] for r in rows)
    return {
        "apk": str(apk_path),
        "sha256": sha256_file(apk_path),
        "entries": len(rows),
        "total_raw": total_raw,
        "total_compressed": total_comp,
        "global_ratio": round(0 if total_raw == 0 else 1.0 - total_comp / total_raw, 4),
        "items": rows,
    }

def candidate_note(name, raw, compressed, ext):
    if raw == 0:
        return "empty"
    if ext in ALREADY_COMPRESSED:
        return "usually keep/store; recompression often gives low gain"
    ratio = 1.0 - compressed / raw if raw else 0
    if ratio < 0.05 and raw > 4096:
        return "low compression gain; check store/deflate policy"
    if ratio > 0.35:
        return "good deflate gain"
    return "neutral"

def recompress_copy(src, dst, level=9):
    """Creates an unsigned structural ZIP copy. It does not sign or decompile."""
    with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(dst, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=level) as zout:
        for info in zin.infolist():
            data = zin.read(info.filename)
            ext = Path(info.filename).suffix.lower()
            zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            zi.external_attr = info.external_attr
            zi.comment = info.comment
            zi.extra = info.extra

            # Keep critical/already-compressed payloads stored to avoid wasted CPU and preserve structure.
            if ext in ALREADY_COMPRESSED or info.filename.upper().startswith("META-INF/"):
                zi.compress_type = zipfile.ZIP_STORED
            else:
                zi.compress_type = zipfile.ZIP_DEFLATED
            zout.writestr(zi, data)
    return sha256_file(dst)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("apk")
    ap.add_argument("--json", default="apk_audit.json")
    ap.add_argument("--recompress-copy", help="gera cópia ZIP/APK não assinada e não compilada")
    ns = ap.parse_args()

    report = audit(ns.apk)
    with open(ns.json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"[OK] audit: {ns.json}")
    print(f"[OK] entries={report['entries']} global_ratio={report['global_ratio']} sha256={report['sha256'][:16]}...")

    if ns.recompress_copy:
        h = recompress_copy(ns.apk, ns.recompress_copy)
        print(f"[OK] recompressed unsigned structural copy: {ns.recompress_copy}")
        print(f"[OK] copy_sha256={h}")
        print("[WARN] Copy is not signed/aligned for distribution. Use only in authorized engineering flow.")

if __name__ == "__main__":
    main()
