// RAFAELIA ROOT OPTIMIZER - C++17
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

struct IR {
    int uid;
    std::string op, dst, src, text;
    long imm = 0;
    bool hasImm = false;
};

static std::string trim(std::string s) {
    auto notspace = [](unsigned char c){ return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notspace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notspace).base(), s.end());
    if (!s.empty() && s.back() == ';') s.pop_back();
    return s;
}

static std::vector<std::string> split2(const std::string& s, char c) {
    auto p = s.find(c);
    if (p == std::string::npos) return {s};
    return {s.substr(0,p), s.substr(p+1)};
}

static std::vector<IR> parse(const std::string& code) {
    std::vector<IR> out;
    std::istringstream in(code);
    std::string line;
    int uid = 0;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line.rfind("//",0)==0 || line.rfind("#",0)==0) continue;
        uid++;
        if (line.rfind("if",0)==0) { out.push_back({uid,"CMP","",line,line}); continue; }
        auto eq = split2(line, '=');
        if (eq.size()!=2) { out.push_back({uid,"RAW","","",line}); continue; }
        std::string dst=trim(eq[0]), expr=trim(eq[1]);
        char* end=nullptr;
        long val = std::strtol(expr.c_str(), &end, 10);
        if (end && *end == 0) out.push_back({uid,"MOVI",dst,"",line,val,true});
        else {
            size_t plus=expr.find('+'), minus=expr.find('-');
            if (plus!=std::string::npos || minus!=std::string::npos) {
                char opchar = plus!=std::string::npos ? '+' : '-';
                auto xs=split2(expr, opchar);
                out.push_back({uid,"MOV",dst,trim(xs[0]),dst+" <- "+trim(xs[0])});
                uid++;
                char* e2=nullptr;
                long v2=std::strtol(trim(xs[1]).c_str(), &e2, 10);
                out.push_back({uid,opchar=='+'?"ADD":"SUB",dst,trim(xs[1]),line,v2,e2 && *e2==0});
            } else out.push_back({uid,"MOV",dst,expr,line});
        }
    }
    return out;
}

static void emitArm64(const std::vector<IR>& ir) {
    std::cout << "// RAFAELIA ROOT OPTIMIZER - C++ ARM64\n";
    for (auto& i: ir) {
        if (i.op=="MOVI") std::cout<<"mov "<<i.dst<<", #"<<i.imm<<"    // "<<i.text<<"\n";
        else if (i.op=="MOV") std::cout<<"mov "<<i.dst<<", "<<i.src<<"    // "<<i.text<<"\n";
        else if (i.op=="ADD") std::cout<<"add "<<i.dst<<", "<<i.dst<<", #"<<(i.hasImm?i.imm:0)<<"    // "<<i.text<<"\n";
        else if (i.op=="SUB") std::cout<<"sub "<<i.dst<<", "<<i.dst<<", #"<<(i.hasImm?i.imm:0)<<"    // "<<i.text<<"\n";
        else if (i.op=="CMP") std::cout<<"// cmp candidate: "<<i.text<<"\n";
        else std::cout<<"// raw: "<<i.text<<"\n";
    }
}

int main(int argc, char** argv) {
    if (argc < 2) { std::cerr<<"usage: raf_root_optimizer <file>\n"; return 1; }
    std::ifstream f(argv[1]);
    std::stringstream ss; ss << f.rdbuf();
    emitArm64(parse(ss.str()));
    return 0;
}
