-- RAFAELIA ROOT OPTIMIZER - Lua
local file = assert(arg[1], "usage: lua raf_root_optimizer.lua <file>")
local code = assert(io.open(file, "r")):read("*a")

local function trim(s)
  s = s:gsub("^%s+", ""):gsub("%s+$", "")
  s = s:gsub(";$", "")
  return s
end

local ir, uid = {}, 0

for raw in code:gmatch("[^\n]+") do
  local line = trim(raw)
  if line ~= "" and not line:match("^//") and not line:match("^#") then
    uid = uid + 1
    if line:match("^if") then
      table.insert(ir, {uid=uid, op="CMP", text=line})
    else
      local dst, expr = line:match("^(%w+)%s*=%s*(.+)$")
      if dst then
        local imm = tonumber(expr)
        if imm then
          table.insert(ir, {uid=uid, op="MOVI", dst=dst, imm=imm, text=line})
        else
          local a, plus = expr:match("^(%w+)%s*%+%s*(-?%d+)$")
          local b, minus = expr:match("^(%w+)%s*%-%s*(-?%d+)$")
          if a then
            table.insert(ir, {uid=uid, op="MOV", dst=dst, src=a, text=dst .. " <- " .. a})
            uid = uid + 1
            table.insert(ir, {uid=uid, op="ADD", dst=dst, imm=tonumber(plus), text=line})
          elseif b then
            table.insert(ir, {uid=uid, op="MOV", dst=dst, src=b, text=dst .. " <- " .. b})
            uid = uid + 1
            table.insert(ir, {uid=uid, op="SUB", dst=dst, imm=tonumber(minus), text=line})
          else
            table.insert(ir, {uid=uid, op="MOV", dst=dst, src=expr, text=line})
          end
        end
      else
        table.insert(ir, {uid=uid, op="RAW", text=line})
      end
    end
  end
end

print("-- RAFAELIA ROOT OPTIMIZER - Lua ARM64")
for _, i in ipairs(ir) do
  if i.op == "MOVI" then print(("mov %s, #%d    // %s"):format(i.dst, i.imm, i.text))
  elseif i.op == "MOV" then print(("mov %s, %s    // %s"):format(i.dst, i.src, i.text))
  elseif i.op == "ADD" then print(("add %s, %s, #%d    // %s"):format(i.dst, i.dst, i.imm, i.text))
  elseif i.op == "SUB" then print(("sub %s, %s, #%d    // %s"):format(i.dst, i.dst, i.imm, i.text))
  elseif i.op == "CMP" then print("// cmp candidate: " .. i.text)
  else print("// raw: " .. i.text) end
end
