'
' RAFAELIA ROOT OPTIMIZER - VBS
' Uso: cscript //nologo raf_root_optimizer.vbs example.cmini

If WScript.Arguments.Count < 1 Then
  WScript.Echo "usage: cscript //nologo raf_root_optimizer.vbs <file>"
  WScript.Quit 1
End If

Set fso = CreateObject("Scripting.FileSystemObject")
Set f = fso.OpenTextFile(WScript.Arguments(0), 1)
uid = 0
WScript.Echo "' RAFAELIA ROOT OPTIMIZER - VBS ARM64"

Do Until f.AtEndOfStream
  line = Trim(f.ReadLine)
  If Right(line,1) = ";" Then line = Left(line, Len(line)-1)
  If line <> "" Then
    If Left(line,2) <> "//" And Left(line,1) <> "#" Then
      uid = uid + 1
      If Left(line,2) = "if" Then
        WScript.Echo "// cmp candidate: " & line
      ElseIf InStr(line, "=") > 0 Then
        parts = Split(line, "=", 2)
        dst = Trim(parts(0))
        expr = Trim(parts(1))
        If IsNumeric(expr) Then
          WScript.Echo "mov " & dst & ", #" & expr & "    // " & line
        ElseIf InStr(expr, "+") > 0 Then
          xs = Split(expr, "+", 2)
          src = Trim(xs(0))
          imm = Trim(xs(1))
          WScript.Echo "mov " & dst & ", " & src & "    // " & dst & " <- " & src
          WScript.Echo "add " & dst & ", " & dst & ", #" & imm & "    // " & line
        ElseIf InStr(expr, "-") > 0 Then
          xs = Split(expr, "-", 2)
          src = Trim(xs(0))
          imm = Trim(xs(1))
          WScript.Echo "mov " & dst & ", " & src & "    // " & dst & " <- " & src
          WScript.Echo "sub " & dst & ", " & dst & ", #" & imm & "    // " & line
        Else
          WScript.Echo "mov " & dst & ", " & expr & "    // " & line
        End If
      Else
        WScript.Echo "// raw: " & line
      End If
    End If
  End If
Loop
