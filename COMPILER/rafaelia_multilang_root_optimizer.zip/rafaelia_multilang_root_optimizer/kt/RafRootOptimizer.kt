import java.io.File
import java.security.MessageDigest

data class IR(
    val uid: Int,
    val op: String,
    val dst: String? = null,
    val src: String? = null,
    val imm: Long? = null,
    val text: String
)

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
        .joinToString("") { "%02x".format(it) }

fun parse(code: String): List<IR> {
    val out = mutableListOf<IR>()
    var uid = 0
    for (raw in code.lines()) {
        val line = raw.trim().trimEnd(';')
        if (line.isEmpty() || line.startsWith("//") || line.startsWith("#")) continue
        uid++
        if (line.startsWith("if")) {
            out += IR(uid, "CMP", src = line, text = line)
            continue
        }
        val parts = line.split("=", limit = 2)
        if (parts.size != 2) {
            out += IR(uid, "RAW", text = line)
            continue
        }
        val dst = parts[0].trim()
        val expr = parts[1].trim()
        val imm = expr.toLongOrNull()
        if (imm != null) {
            out += IR(uid, "MOVI", dst = dst, imm = imm, text = line)
        } else if (expr.contains("+") || expr.contains("-")) {
            val opChar = if (expr.contains("+")) "+" else "-"
            val xs = expr.split(opChar, limit = 2)
            out += IR(uid, "MOV", dst = dst, src = xs[0].trim(), text = "$dst <- ${xs[0].trim()}")
            uid++
            out += IR(uid, if (opChar == "+") "ADD" else "SUB", dst = dst, src = xs[1].trim(), imm = xs[1].trim().toLongOrNull(), text = line)
        } else {
            out += IR(uid, "MOV", dst = dst, src = expr, text = line)
        }
    }
    return out
}

fun emitArm64(ir: List<IR>): String {
    val sb = StringBuilder("// RAFAELIA ROOT OPTIMIZER - Kotlin ARM64\n")
    for (i in ir) {
        when (i.op) {
            "MOVI" -> sb.append("mov ${i.dst}, #${i.imm}    // ${i.uid}: ${i.text}\n")
            "MOV" -> sb.append("mov ${i.dst}, ${i.src}    // ${i.uid}: ${i.text}\n")
            "ADD" -> sb.append("add ${i.dst}, ${i.dst}, #${i.imm ?: 0}    // ${i.uid}: ${i.text}\n")
            "SUB" -> sb.append("sub ${i.dst}, ${i.dst}, #${i.imm ?: 0}    // ${i.uid}: ${i.text}\n")
            "CMP" -> sb.append("// cmp candidate: ${i.text}\n")
            else -> sb.append("// raw: ${i.text}\n")
        }
    }
    return sb.toString()
}

fun main(args: Array<String>) {
    require(args.isNotEmpty()) { "usage: kotlin RafRootOptimizerKt <file>" }
    val code = File(args[0]).readText()
    val ir = parse(code)
    val asm = emitArm64(ir)
    println(asm)
    println("// audit_sha256=${sha256(code + ir.toString())}")
}
