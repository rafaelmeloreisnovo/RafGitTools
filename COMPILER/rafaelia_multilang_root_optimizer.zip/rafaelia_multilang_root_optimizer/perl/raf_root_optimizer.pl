#!/usr/bin/env perl
# RAFAELIA ROOT OPTIMIZER - Perl
use strict;
use warnings;
my $file = shift @ARGV or die "usage: perl raf_root_optimizer.pl <file>\n";
open my $fh, "<", $file or die $!;
my @ir; my $uid = 0;

while (my $line = <$fh>) {
    chomp $line;
    $line =~ s/^\s+|\s+$//g;
    $line =~ s/;$//;
    next if $line eq "" || $line =~ /^\/\// || $line =~ /^#/;
    $uid++;
    if ($line =~ /^if/) {
        push @ir, {uid=>$uid, op=>"CMP", text=>$line};
    } elsif ($line =~ /^(\w+)\s*=\s*(-?\d+)$/) {
        push @ir, {uid=>$uid, op=>"MOVI", dst=>$1, imm=>$2, text=>$line};
    } elsif ($line =~ /^(\w+)\s*=\s*(\w+)\s*([+\-])\s*(-?\d+)$/) {
        my ($dst,$src,$op,$imm)=($1,$2,$3,$4);
        push @ir, {uid=>$uid, op=>"MOV", dst=>$dst, src=>$src, text=>"$dst <- $src"};
        $uid++;
        push @ir, {uid=>$uid, op=>$op eq "+" ? "ADD":"SUB", dst=>$dst, imm=>$imm, text=>$line};
    } elsif ($line =~ /^(\w+)\s*=\s*(\w+)$/) {
        push @ir, {uid=>$uid, op=>"MOV", dst=>$1, src=>$2, text=>$line};
    } else {
        push @ir, {uid=>$uid, op=>"RAW", text=>$line};
    }
}

print "; RAFAELIA ROOT OPTIMIZER - Perl ARM64\n";
for my $i (@ir) {
    if ($i->{op} eq "MOVI") { print "mov $i->{dst}, #$i->{imm}    // $i->{text}\n"; }
    elsif ($i->{op} eq "MOV") { print "mov $i->{dst}, $i->{src}    // $i->{text}\n"; }
    elsif ($i->{op} eq "ADD") { print "add $i->{dst}, $i->{dst}, #$i->{imm}    // $i->{text}\n"; }
    elsif ($i->{op} eq "SUB") { print "sub $i->{dst}, $i->{dst}, #$i->{imm}    // $i->{text}\n"; }
    elsif ($i->{op} eq "CMP") { print "// cmp candidate: $i->{text}\n"; }
    else { print "// raw: $i->{text}\n"; }
}
