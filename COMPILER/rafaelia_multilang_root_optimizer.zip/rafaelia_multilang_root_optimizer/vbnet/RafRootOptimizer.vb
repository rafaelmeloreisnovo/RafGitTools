Imports System
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Module RafRootOptimizer
    Function Sha256Hex(s As String) As String
        Using sha = SHA256.Create()
            Dim b = sha.ComputeHash(Encoding.UTF8.GetBytes(s))
            Return BitConverter.ToString(b).Replace("-", "").ToLowerInvariant()
        End Using
    End Function

    Sub EmitLine(line As String)
        line = line.Trim().TrimEnd(";"c)
        If line = "" OrElse line.StartsWith("//") OrElse line.StartsWith("#") Then Return

        If line.StartsWith("if") Then
            Console.WriteLine("// cmp candidate: " & line)
            Return
        End If

        If Not line.Contains("=") Then
            Console.WriteLine("// raw: " & line)
            Return
        End If

        Dim parts = line.Split(New Char() {"="c}, 2)
        Dim dst = parts(0).Trim()
        Dim expr = parts(1).Trim()
        Dim n As Long

        If Long.TryParse(expr, n) Then
            Console.WriteLine($"mov {dst}, #{n}    // {line}")
        ElseIf expr.Contains("+") Then
            Dim xs = expr.Split(New Char() {"+"c}, 2)
            Console.WriteLine($"mov {dst}, {xs(0).Trim()}    // {dst} <- {xs(0).Trim()}")
            Console.WriteLine($"add {dst}, {dst}, #{xs(1).Trim()}    // {line}")
        ElseIf expr.Contains("-") Then
            Dim xs = expr.Split(New Char() {"-"c}, 2)
            Console.WriteLine($"mov {dst}, {xs(0).Trim()}    // {dst} <- {xs(0).Trim()}")
            Console.WriteLine($"sub {dst}, {dst}, #{xs(1).Trim()}    // {line}")
        Else
            Console.WriteLine($"mov {dst}, {expr}    // {line}")
        End If
    End Sub

    Sub Main(args As String())
        If args.Length < 1 Then
            Console.Error.WriteLine("usage: dotnet run -- <file>")
            Environment.Exit(1)
        End If
        Dim code = File.ReadAllText(args(0))
        Console.WriteLine("' RAFAELIA ROOT OPTIMIZER - VB.NET ARM64")
        For Each line In code.Split({vbCrLf, vbLf}, StringSplitOptions.None)
            EmitLine(line)
        Next
        Console.WriteLine("' audit_sha256=" & Sha256Hex(code))
    End Sub
End Module
