use sha2::{Digest, Sha256};
use std::{env, fs};

#[derive(Debug, Clone)]
struct Ir {
    uid: usize,
    op: String,
    dst: Option<String>,
    src: Option<String>,
    imm: Option<i64>,
    text: String,
}

fn parse(code: &str) -> Vec<Ir> {
    let mut out = Vec::new();
    let mut uid = 0usize;

    for raw in code.lines() {
        let line = raw.trim().trim_end_matches(';').to_string();
        if line.is_empty() || line.starts_with("//") || line.starts_with('#') { continue; }
        uid += 1;

        if line.starts_with("if") {
            out.push(Ir { uid, op: "CMP".into(), dst: None, src: Some(line.clone()), imm: None, text: line });
            continue;
        }

        let parts: Vec<&str> = line.split('=').collect();
        if parts.len() != 2 {
            out.push(Ir { uid, op: "RAW".into(), dst: None, src: None, imm: None, text: line });
            continue;
        }

        let dst = parts[0].trim().to_string();
        let expr = parts[1].trim();

        if let Ok(v) = expr.parse::<i64>() {
            out.push(Ir { uid, op: "MOVI".into(), dst: Some(dst), src: None, imm: Some(v), text: line });
        } else if expr.contains('+') || expr.contains('-') {
            let op_char = if expr.contains('+') { '+' } else { '-' };
            let xs: Vec<&str> = expr.split(op_char).collect();
            let src = xs[0].trim().to_string();
            uid += 1;
            out.push(Ir { uid: uid - 1, op: "MOV".into(), dst: Some(dst.clone()), src: Some(src), imm: None, text: format!("{} <- {}", dst, xs[0].trim()) });
            out.push(Ir { uid, op: if op_char == '+' { "ADD".into() } else { "SUB".into() }, dst: Some(dst), src: Some(xs[1].trim().to_string()), imm: xs[1].trim().parse().ok(), text: line });
        } else {
            out.push(Ir { uid, op: "MOV".into(), dst: Some(dst), src: Some(expr.to_string()), imm: None, text: line });
        }
    }
    out
}

fn emit_arm64(ir: &[Ir]) -> String {
    let mut s = String::from("// RAFAELIA ROOT OPTIMIZER - Rust ARM64\n");
    for i in ir {
        match i.op.as_str() {
            "MOVI" => s.push_str(&format!("mov {}, #{}    // {}\n", i.dst.as_ref().unwrap(), i.imm.unwrap(), i.text)),
            "MOV" => s.push_str(&format!("mov {}, {}    // {}\n", i.dst.as_ref().unwrap(), i.src.as_ref().unwrap(), i.text)),
            "ADD" => s.push_str(&format!("add {}, {}, #{}    // {}\n", i.dst.as_ref().unwrap(), i.dst.as_ref().unwrap(), i.imm.unwrap_or(0), i.text)),
            "SUB" => s.push_str(&format!("sub {}, {}, #{}    // {}\n", i.dst.as_ref().unwrap(), i.dst.as_ref().unwrap(), i.imm.unwrap_or(0), i.text)),
            "CMP" => s.push_str(&format!("// cmp candidate: {}\n", i.text)),
            _ => s.push_str(&format!("// raw: {}\n", i.text)),
        }
    }
    s
}

fn main() {
    let file = env::args().nth(1).expect("usage: raf_root_optimizer <file>");
    let code = fs::read_to_string(file).expect("read failed");
    let ir = parse(&code);
    let asm = emit_arm64(&ir);
    let mut hasher = Sha256::new();
    hasher.update(code.as_bytes());
    hasher.update(format!("{:?}", ir).as_bytes());
    println!("{}", asm);
    println!("// audit_sha256={:x}", hasher.finalize());
}
