#!/usr/bin/env python3
"""
RAFAELIA ROOT OPTIMIZER - PY
Parser mínimo C-like → IR → ASM textual + auditoria SHA256.
Fonte educacional, sem binários.
"""

from dataclasses import dataclass, field
from typing import List, Set, Optional
import argparse, hashlib, json, re, sys

@dataclass
class IR:
    uid: int
    op: str
    dst: Optional[str] = None
    src: Optional[str] = None
    imm: Optional[int] = None
    text: str = ""
    defines: Set[str] = field(default_factory=set)
    uses: Set[str] = field(default_factory=set)

class Parser:
    def __init__(self):
        self.uid = 0

    def next(self):
        self.uid += 1
        return self.uid

    def parse(self, code: str) -> List[IR]:
        out: List[IR] = []
        for raw in code.splitlines():
            line = raw.strip().rstrip(";")
            if not line or line.startswith("//") or line.startswith("#"):
                continue

            m = re.match(r"if\s*\(\s*(\w+)\s*([<>=!]+)\s*(-?\d+)\s*\)", line)
            if m:
                var, cond, val = m.groups()
                out.append(IR(self.next(), f"CMP_{cond}", src=var, imm=int(val), text=line, uses={var}))
                continue

            m = re.match(r"(\w+)\s*=\s*(\w+)\s*([+\-])\s*(-?\d+)$", line)
            if m:
                dst, src, op, imm = m.groups()
                out.append(IR(self.next(), "MOV", dst=dst, src=src, text=f"{dst} <- {src}", defines={dst}, uses={src}))
                out.append(IR(self.next(), "ADD" if op == "+" else "SUB", dst=dst, imm=int(imm), text=line, defines={dst}, uses={dst}))
                continue

            m = re.match(r"(\w+)\s*=\s*(\w+)\s*([+\-])\s*(\w+)$", line)
            if m:
                dst, a, op, b = m.groups()
                out.append(IR(self.next(), "MOV", dst=dst, src=a, text=f"{dst} <- {a}", defines={dst}, uses={a}))
                out.append(IR(self.next(), "ADDV" if op == "+" else "SUBV", dst=dst, src=b, text=line, defines={dst}, uses={dst, b}))
                continue

            m = re.match(r"(\w+)\s*=\s*(-?\d+)$", line)
            if m:
                dst, imm = m.groups()
                out.append(IR(self.next(), "MOVI", dst=dst, imm=int(imm), text=line, defines={dst}))
                continue

            m = re.match(r"(\w+)\s*=\s*(\w+)$", line)
            if m:
                dst, src = m.groups()
                out.append(IR(self.next(), "MOV", dst=dst, src=src, text=line, defines={dst}, uses={src}))
                continue

            out.append(IR(self.next(), "RAW", text=line))
        return out

class Auditor:
    @staticmethod
    def hash_ir(code: str, ir: List[IR]) -> str:
        payload = {
            "source_sha256": hashlib.sha256(code.encode()).hexdigest(),
            "ir": [i.__dict__ | {"defines": sorted(i.defines), "uses": sorted(i.uses)} for i in ir],
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

class Backend:
    def __init__(self, target="arm64"):
        self.target = target
        self.regs = {}
        self.pool_arm = ["x0","x1","x2","x3","x4","x5","x6","x7","x8","x9"]
        self.pool_x86 = ["rax","rbx","rcx","rdx","r8","r9","r10","r11"]

    def reg(self, v):
        if v is None: return None
        if v not in self.regs:
            pool = self.pool_arm if self.target == "arm64" else self.pool_x86
            self.regs[v] = pool[len(self.regs) % len(pool)]
        return self.regs[v]

    def emit(self, ir: List[IR]) -> str:
        lines = [f"; RAFAELIA ROOT OPTIMIZER target={self.target}"]
        for i in ir:
            d, s = self.reg(i.dst), self.reg(i.src)
            if self.target == "arm64":
                if i.op == "MOVI": lines.append(f"mov {d}, #{i.imm}    // {i.uid}: {i.text}")
                elif i.op == "MOV": lines.append(f"mov {d}, {s}    // {i.uid}: {i.text}")
                elif i.op == "ADD": lines.append(f"add {d}, {d}, #{i.imm}    // {i.uid}: {i.text}")
                elif i.op == "SUB": lines.append(f"sub {d}, {d}, #{i.imm}    // {i.uid}: {i.text}")
                elif i.op == "ADDV": lines.append(f"add {d}, {d}, {s}    // {i.uid}: {i.text}")
                elif i.op == "SUBV": lines.append(f"sub {d}, {d}, {s}    // {i.uid}: {i.text}")
                elif i.op.startswith("CMP"): lines.append(f"cmp {s}, #{i.imm}    // {i.uid}: {i.text}")
                else: lines.append(f"// raw {i.uid}: {i.text}")
            else:
                if i.op == "MOVI": lines.append(f"mov {d}, {i.imm}    ; {i.uid}: {i.text}")
                elif i.op == "MOV": lines.append(f"mov {d}, {s}    ; {i.uid}: {i.text}")
                elif i.op == "ADD": lines.append(f"add {d}, {i.imm}    ; {i.uid}: {i.text}")
                elif i.op == "SUB": lines.append(f"sub {d}, {i.imm}    ; {i.uid}: {i.text}")
                elif i.op == "ADDV": lines.append(f"add {d}, {s}    ; {i.uid}: {i.text}")
                elif i.op == "SUBV": lines.append(f"sub {d}, {s}    ; {i.uid}: {i.text}")
                elif i.op.startswith("CMP"): lines.append(f"cmp {s}, {i.imm}    ; {i.uid}: {i.text}")
                else: lines.append(f"; raw {i.uid}: {i.text}")
        return "\n".join(lines)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--target", choices=["arm64","x86_64"], default="arm64")
    ap.add_argument("--audit")
    ns = ap.parse_args()
    code = open(ns.file, encoding="utf-8").read()
    ir = Parser().parse(code)
    asm = Backend(ns.target).emit(ir)
    h = Auditor.hash_ir(code, ir)
    if ns.audit:
        open(ns.audit, "w", encoding="utf-8").write(json.dumps({"audit_sha256": h, "target": ns.target}, indent=2))
    print(asm)
    print(f"\n; audit_sha256={h}")

if __name__ == "__main__":
    main()
