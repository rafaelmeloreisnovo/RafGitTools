#!/usr/bin/env bash
set -euo pipefail
echo "[check] bash: $BASH_VERSION"
command -v python3 >/dev/null && echo "[check] python3 OK" || echo "[warn] python3 ausente"
command -v cmake >/dev/null && echo "[check] cmake OK" || echo "[warn] cmake ausente"
command -v c++ >/dev/null && echo "[check] c++ OK" || echo "[warn] c++ ausente"
command -v md5sum >/dev/null && echo "[check] md5sum OK" || echo "[warn] md5sum ausente"
command -v sha256sum >/dev/null && echo "[check] sha256sum OK" || echo "[warn] sha256sum ausente"
