# RAFAELIA Root Build

Estrutura criada por `rafaelia_factory.sh`.

## Ideia

```text
entrada C-like / arquivo / APK próprio
→ normalização segura
→ parser / auditor estrutural
→ heurísticas
→ mitigação
→ IR / relatório
→ hash MD5 + SHA256
→ saída ASM textual / JSON
```

## Componentes

- `rafctl.sh`: CLI principal + menu BBS-like.
- `tools/raf_optimizer.py`: otimizador/auditor C-like.
- `tools/apk_audit.py`: auditor seguro de APK/ZIP.
- `src/raf_core.cpp`: núcleo C++ demonstrativo.
- `include/raf_core.hpp`: interface C++.
- `CMakeLists.txt`: build CMake.
- `Makefile`: orquestração simples.
- `docs/METHODOLOGY.md`: metodologia.
- `docs/SECURITY.md`: segurança e limites.
- `docs/HEURISTICS.md`: heurísticas e mitigação.
- `examples/example.cmini`: exemplo.

## Uso rápido

```bash
./rafctl.sh menu
./rafctl.sh audit examples/example.cmini
./rafctl.sh py examples/example.cmini
./rafctl.sh apk-audit caminho/app.apk
cmake -S . -B build
cmake --build build
```

## Segurança

Use apenas em código/APK próprio ou autorizado.
Este pacote não contém lógica de bypass, assinatura, decompilação DEX ou alteração de app de terceiros.
