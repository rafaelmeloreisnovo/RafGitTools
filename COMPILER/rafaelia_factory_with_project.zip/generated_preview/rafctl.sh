#!/usr/bin/env bash
set -euo pipefail

cmd="${1:-help}"
shift || true

mkdir -p reports build

banner() {
cat <<'BANNER'
╔══════════════════════════════════════════════════════════════════╗
║                 RAFAELIA ROOT CONTROL / BBS MODE                ║
║      heurísticas • mitigação • auditoria • CMake • APK safe      ║
╚══════════════════════════════════════════════════════════════════╝
BANNER
}

help_msg() {
cat <<'HELP'
Uso:
  ./rafctl.sh menu
  ./rafctl.sh audit <file.cmini>
  ./rafctl.sh py <file.cmini>
  ./rafctl.sh x86 <file.cmini>
  ./rafctl.sh apk-audit <file.apk|file.zip>
  ./rafctl.sh hashes <file>
  ./rafctl.sh cmake
  ./rafctl.sh build
  ./rafctl.sh test
  ./rafctl.sh clean
HELP
}

hashes() {
  local f="$1"
  echo "[MD5]    $(md5sum "$f" | awk '{print $1}')"
  echo "[SHA256] $(sha256sum "$f" | awk '{print $1}')"
}

bbs_menu() {
  while true; do
    clear || true
    banner
    cat <<'MENU'

 [1] Rodar optimizer ARM64 no exemplo
 [2] Rodar optimizer x86_64 no exemplo
 [3] Auditar exemplo com JSON
 [4] Auditar APK/ZIP
 [5] Mostrar hashes de arquivo
 [6] Configurar CMake
 [7] Build CMake
 [8] Testes CTest
 [9] Ver metodologia
 [0] Sair

MENU
    printf "Escolha: "
    read -r opt
    case "$opt" in
      1) ./rafctl.sh py examples/example.cmini; read -r -p "ENTER..." _ ;;
      2) ./rafctl.sh x86 examples/example.cmini; read -r -p "ENTER..." _ ;;
      3) ./rafctl.sh audit examples/example.cmini; read -r -p "ENTER..." _ ;;
      4) printf "Caminho APK/ZIP: "; read -r apk; ./rafctl.sh apk-audit "$apk"; read -r -p "ENTER..." _ ;;
      5) printf "Arquivo: "; read -r f; ./rafctl.sh hashes "$f"; read -r -p "ENTER..." _ ;;
      6) ./rafctl.sh cmake; read -r -p "ENTER..." _ ;;
      7) ./rafctl.sh build; read -r -p "ENTER..." _ ;;
      8) ./rafctl.sh test; read -r -p "ENTER..." _ ;;
      9) sed -n '1,220p' docs/METHODOLOGY.md; read -r -p "ENTER..." _ ;;
      0) exit 0 ;;
      *) echo "Opção inválida"; sleep 1 ;;
    esac
  done
}

case "$cmd" in
  help|-h|--help)
    help_msg
    ;;
  menu)
    bbs_menu
    ;;
  py|arm64)
    in="${1:-examples/example.cmini}"
    python3 tools/raf_optimizer.py "$in" --target arm64 --report reports/optimizer_arm64.json
    ;;
  x86|x86_64)
    in="${1:-examples/example.cmini}"
    python3 tools/raf_optimizer.py "$in" --target x86_64 --report reports/optimizer_x86_64.json
    ;;
  audit)
    in="${1:-examples/example.cmini}"
    python3 tools/raf_optimizer.py "$in" --target arm64 --report reports/audit.json --asm reports/output_arm64.s
    echo "[OK] ASM: reports/output_arm64.s"
    echo "[OK] REPORT: reports/audit.json"
    ;;
  apk-audit)
    f="${1:?informe APK/ZIP}"
    python3 tools/apk_audit.py "$f" --report reports/apk_audit.json
    ;;
  hashes)
    f="${1:?informe arquivo}"
    hashes "$f"
    ;;
  cmake)
    cmake -S . -B build
    ;;
  build)
    cmake --build build
    ;;
  test)
    ctest --test-dir build --output-on-failure
    ;;
  clean)
    rm -rf build reports/*
    ;;
  *)
    help_msg
    exit 1
    ;;
esac
