#pragma once
#include <string>
#include <vector>

namespace raf {

struct Instruction {
    int uid;
    std::string op;
    std::string dst;
    std::string src;
    long imm;
    bool has_imm;
    std::string origin;
};

std::vector<Instruction> parse_cmini(const std::string& code);
std::string emit_arm64(const std::vector<Instruction>& ir);
std::string version();

}
