#include "raf_core.hpp"
#include <fstream>
#include <iostream>
#include <sstream>

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "usage: raf_core_cli <file.cmini>\n";
        return 1;
    }
    std::ifstream f(argv[1]);
    if (!f) {
        std::cerr << "cannot open input\n";
        return 2;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    auto ir = raf::parse_cmini(ss.str());
    std::cout << raf::emit_arm64(ir);
    return 0;
}
