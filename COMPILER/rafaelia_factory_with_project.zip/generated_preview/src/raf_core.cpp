#include "raf_core.hpp"
#include <sstream>
#include <algorithm>
#include <cctype>
#include <cstdlib>

namespace raf {

static std::string trim(std::string s) {
    auto ns = [](unsigned char c){ return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), ns));
    s.erase(std::find_if(s.rbegin(), s.rend(), ns).base(), s.end());
    if (!s.empty() && s.back() == ';') s.pop_back();
    return s;
}

static bool parse_long(const std::string& s, long& out) {
    char* end = nullptr;
    out = std::strtol(s.c_str(), &end, 10);
    return end && *end == 0;
}

std::vector<Instruction> parse_cmini(const std::string& code) {
    std::vector<Instruction> ir;
    std::istringstream in(code);
    std::string line;
    int uid = 0;

    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty()) continue;
        if (line.rfind("//", 0) == 0 || line.rfind("#", 0) == 0) continue;

        uid++;
        if (line.rfind("if", 0) == 0) {
            ir.push_back({uid, "BARRIER_CMP", "", "", 0, false, line});
            continue;
        }

        auto eq = line.find('=');
        if (eq == std::string::npos) {
            ir.push_back({uid, "RAW_BARRIER", "", "", 0, false, line});
            continue;
        }

        std::string dst = trim(line.substr(0, eq));
        std::string expr = trim(line.substr(eq + 1));

        long v = 0;
        if (parse_long(expr, v)) {
            ir.push_back({uid, "MOVI", dst, "", v, true, line});
            continue;
        }

        auto plus = expr.find('+');
        auto minus = expr.find('-');
        if (plus != std::string::npos || minus != std::string::npos) {
            bool is_add = plus != std::string::npos;
            auto pos = is_add ? plus : minus;
            std::string a = trim(expr.substr(0, pos));
            std::string b = trim(expr.substr(pos + 1));
            long imm = 0;
            bool has_imm = parse_long(b, imm);

            ir.push_back({uid, "MOV", dst, a, 0, false, dst + " <- " + a});
            uid++;
            ir.push_back({uid, is_add ? "ADD" : "SUB", dst, has_imm ? "" : b, imm, has_imm, line});
            continue;
        }

        ir.push_back({uid, "MOV", dst, expr, 0, false, line});
    }

    return ir;
}

std::string emit_arm64(const std::vector<Instruction>& ir) {
    std::ostringstream out;
    out << "// RAFAELIA CORE C++ ARM64 textual backend\n";
    for (const auto& i : ir) {
        if (i.op == "MOVI") out << "mov " << i.dst << ", #" << i.imm << "    // " << i.origin << "\n";
        else if (i.op == "MOV") out << "mov " << i.dst << ", " << i.src << "    // " << i.origin << "\n";
        else if (i.op == "ADD") {
            if (i.has_imm) out << "add " << i.dst << ", " << i.dst << ", #" << i.imm << "    // " << i.origin << "\n";
            else out << "add " << i.dst << ", " << i.dst << ", " << i.src << "    // " << i.origin << "\n";
        }
        else if (i.op == "SUB") {
            if (i.has_imm) out << "sub " << i.dst << ", " << i.dst << ", #" << i.imm << "    // " << i.origin << "\n";
            else out << "sub " << i.dst << ", " << i.dst << ", " << i.src << "    // " << i.origin << "\n";
        }
        else if (i.op == "BARRIER_CMP") out << "// barrier/cmp candidate preserved: " << i.origin << "\n";
        else out << "// raw/barrier: " << i.origin << "\n";
    }
    return out.str();
}

std::string version() {
    return "rafaelia-root-core/0.2";
}

}
