#!/usr/bin/env python3
"""
RAFAELIA APK/ZIP AUDIT 0.2

Seguro:
- não decompila;
- não assina;
- não remove assinatura;
- não executa conteúdo;
- bloqueia path traversal;
- detecta risco de ZIP bomb.
"""

from __future__ import annotations
import argparse, hashlib, json, os, zipfile, time
from pathlib import PurePosixPath

MAX_ENTRIES = 20000
MAX_TOTAL_UNCOMPRESSED = 2 * 1024 * 1024 * 1024
MAX_RATIO = 200.0

COMPRESSED_EXTS = {
    ".png", ".jpg", ".jpeg", ".webp", ".mp3", ".mp4", ".ogg", ".m4a",
    ".apk", ".zip", ".gz", ".xz", ".7z", ".so", ".dex", ".arsc", ".avif"
}

def hfile(path, algo):
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def unsafe_name(name: str) -> bool:
    p = PurePosixPath(name)
    if name.startswith("/") or "\\" in name:
        return True
    if any(part == ".." for part in p.parts):
        return True
    if ":" in name.split("/")[0]:
        return True
    return False

def audit(path: str):
    items = []
    total_raw = 0
    total_comp = 0
    risks = []

    with zipfile.ZipFile(path, "r") as z:
        infos = z.infolist()
        if len(infos) > MAX_ENTRIES:
            risks.append(f"too many entries: {len(infos)}")

        for info in infos:
            raw = info.file_size
            comp = info.compress_size
            total_raw += raw
            total_comp += comp
            ratio = (raw / comp) if comp else float("inf")
            name_risk = unsafe_name(info.filename)
            if name_risk:
                risks.append(f"unsafe path: {info.filename}")
            if ratio > MAX_RATIO and raw > 1024 * 1024:
                risks.append(f"zip bomb ratio candidate: {info.filename}")

            ext = os.path.splitext(info.filename)[1].lower()
            items.append({
                "name": info.filename,
                "raw_size": raw,
                "compressed_size": comp,
                "method": info.compress_type,
                "ratio_raw_over_compressed": ratio if ratio != float("inf") else "inf",
                "already_compressed_ext": ext in COMPRESSED_EXTS,
                "unsafe_path": name_risk,
                "note": note(ext, raw, comp),
            })

    if total_raw > MAX_TOTAL_UNCOMPRESSED:
        risks.append(f"huge uncompressed total: {total_raw}")

    return {
        "tool": "rafaelia-apk-zip-audit",
        "version": "0.2",
        "timestamp": int(time.time()),
        "file": path,
        "md5": hfile(path, "md5"),
        "sha256": hfile(path, "sha256"),
        "entries": len(items),
        "total_raw": total_raw,
        "total_compressed": total_comp,
        "global_ratio_raw_over_compressed": (total_raw / total_comp) if total_comp else "inf",
        "risks": risks,
        "items": items,
        "mitigations": [
            "path traversal detection",
            "zip bomb ratio detection",
            "entry count limit",
            "uncompressed size limit",
            "read-only audit by default"
        ]
    }

def note(ext, raw, comp):
    if ext in COMPRESSED_EXTS:
        return "usually avoid recompression; likely low gain or runtime cost"
    if raw == 0:
        return "empty"
    if comp == 0:
        return "suspicious zero compressed size"
    gain = 1 - comp / raw
    if gain > 0.35:
        return "good compression gain"
    if gain < 0.05 and raw > 4096:
        return "low compression gain; consider store policy"
    return "neutral"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("apk_or_zip")
    ap.add_argument("--report", default="reports/apk_audit.json")
    ns = ap.parse_args()

    os.makedirs(os.path.dirname(ns.report) or ".", exist_ok=True)
    rep = audit(ns.apk_or_zip)
    blob = json.dumps(rep, indent=2, ensure_ascii=False, sort_keys=True).encode()
    rep["report_sha256"] = hashlib.sha256(blob).hexdigest()
    with open(ns.report, "w", encoding="utf-8") as f:
        json.dump(rep, f, indent=2, ensure_ascii=False, sort_keys=True)

    print(f"[OK] report={ns.report}")
    print(f"[OK] entries={rep['entries']} risks={len(rep['risks'])}")
    print(f"[OK] md5={rep['md5']}")
    print(f"[OK] sha256={rep['sha256']}")

if __name__ == "__main__":
    main()
