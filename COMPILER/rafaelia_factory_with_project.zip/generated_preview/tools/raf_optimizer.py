#!/usr/bin/env python3
"""
RAFAELIA ROOT OPTIMIZER 0.2

Heurísticas:
- parser C-like mínimo;
- IR com origem;
- constant folding simples;
- grafo RAW;
- scheduling com barreiras;
- branchless apenas como candidato;
- auditoria MD5 + SHA256;
- relatório JSON.

Não promete equivalência para C geral. Funciona para subconjunto explícito.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Set, Dict, Tuple
from collections import defaultdict, deque
import argparse, hashlib, json, os, re, sys, time

MAX_INPUT_BYTES = 8 * 1024 * 1024

@dataclass
class IR:
    uid: int
    op: str
    dst: Optional[str] = None
    src: Optional[str] = None
    imm: Optional[int] = None
    origin: str = ""
    defines: Set[str] = field(default_factory=set)
    uses: Set[str] = field(default_factory=set)
    barrier: bool = False
    risk: str = "safe"
    note: str = ""

    def to_json(self):
        d = asdict(self)
        d["defines"] = sorted(self.defines)
        d["uses"] = sorted(self.uses)
        return d

def md5_bytes(b: bytes) -> str:
    return hashlib.md5(b).hexdigest()

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

class Parser:
    def __init__(self):
        self.uid = 0

    def next_uid(self):
        self.uid += 1
        return self.uid

    def parse(self, code: str) -> List[IR]:
        out: List[IR] = []
        for raw in code.splitlines():
            line = raw.strip().rstrip(";")
            if not line or line.startswith("//") or line.startswith("#"):
                continue

            # barrier: if
            m = re.match(r"if\s*\(\s*(\w+)\s*([<>=!]+)\s*(-?\d+)\s*\)", line)
            if m:
                var, cond, val = m.groups()
                out.append(IR(
                    self.next_uid(), f"CMP_{cond}", src=var, imm=int(val), origin=line,
                    uses={var}, barrier=True, risk="candidate",
                    note="branchless candidate; cmp preserved; no destructive transform"
                ))
                continue

            # assignment
            m = re.match(r"(\w+)\s*=\s*(.+)$", line)
            if not m:
                out.append(IR(self.next_uid(), "RAW", origin=line, barrier=True, risk="blocked", note="unknown syntax"))
                continue

            dst, expr = m.groups()
            expr = expr.strip()

            # const
            if re.fullmatch(r"-?\d+", expr):
                out.append(IR(self.next_uid(), "MOVI", dst=dst, imm=int(expr), origin=line, defines={dst}))
                continue

            # const folding: 2 + 3
            mcf = re.fullmatch(r"(-?\d+)\s*([+\-])\s*(-?\d+)", expr)
            if mcf:
                a, op, b = mcf.groups()
                val = int(a) + int(b) if op == "+" else int(a) - int(b)
                out.append(IR(self.next_uid(), "MOVI", dst=dst, imm=val, origin=line, defines={dst}, note="constant folded"))
                continue

            # var +/- const or var +/- var
            mbin = re.fullmatch(r"(\w+)\s*([+\-])\s*(-?\w+)", expr)
            if mbin:
                a, op, b = mbin.groups()
                out.append(IR(
                    self.next_uid(), "MOV", dst=dst, src=a, origin=f"{dst} <- {a}",
                    defines={dst}, uses={a}, note="copy source before arithmetic"
                ))
                if re.fullmatch(r"-?\d+", b):
                    out.append(IR(
                        self.next_uid(), "ADD" if op == "+" else "SUB",
                        dst=dst, imm=int(b), origin=line, defines={dst}, uses={dst}
                    ))
                else:
                    out.append(IR(
                        self.next_uid(), "ADDV" if op == "+" else "SUBV",
                        dst=dst, src=b, origin=line, defines={dst}, uses={dst, b}
                    ))
                continue

            # var move
            if re.fullmatch(r"\w+", expr):
                out.append(IR(self.next_uid(), "MOV", dst=dst, src=expr, origin=line, defines={dst}, uses={expr}))
                continue

            out.append(IR(self.next_uid(), "RAW", origin=line, barrier=True, risk="blocked", note="expression not supported"))

class Graph:
    def __init__(self, ir: List[IR]):
        self.ir = ir
        self.by_uid = {i.uid: i for i in ir}
        self.adj: Dict[int, Set[int]] = defaultdict(set)
        self.indeg: Dict[int, int] = {i.uid: 0 for i in ir}
        self.build()

    def build(self):
        for a in self.ir:
            for b in self.ir:
                if a.uid == b.uid:
                    continue
                if a.defines & b.uses and a.uid < b.uid:
                    if b.uid not in self.adj[a.uid]:
                        self.adj[a.uid].add(b.uid)
                        self.indeg[b.uid] += 1

    def schedule_safe_blocks(self) -> List[IR]:
        # Split by barrier; do not reorder through barrier.
        blocks: List[List[IR]] = []
        cur: List[IR] = []
        for inst in self.ir:
            if inst.barrier:
                if cur:
                    blocks.append(cur)
                    cur = []
                blocks.append([inst])
            else:
                cur.append(inst)
        if cur:
            blocks.append(cur)

        result: List[IR] = []
        for block in blocks:
            if len(block) <= 1 or block[0].barrier:
                result.extend(block)
            else:
                result.extend(self._schedule_block(block))
        return result

    def _schedule_block(self, block: List[IR]) -> List[IR]:
        uids = {i.uid for i in block}
        indeg = {i.uid: 0 for i in block}
        adj = {i.uid: set() for i in block}
        for a in block:
            for b in block:
                if a.uid == b.uid:
                    continue
                if a.defines & b.uses and a.uid < b.uid:
                    adj[a.uid].add(b.uid)
                    indeg[b.uid] += 1
        ready = deque([i.uid for i in block if indeg[i.uid] == 0])
        by_uid = {i.uid: i for i in block}
        out = []
        while ready:
            uid = max(list(ready), key=lambda u: len(adj[u]))
            ready.remove(uid)
            out.append(by_uid[uid])
            for v in sorted(adj[uid]):
                indeg[v] -= 1
                if indeg[v] == 0:
                    ready.append(v)
        if len(out) != len(block):
            # cycle/unknown: preserve original
            return block
        return out

class Heuristics:
    @staticmethod
    def dead_assignment_candidates(ir: List[IR]) -> List[Dict[str, str]]:
        used_after: Set[str] = set()
        notes = []
        for inst in reversed(ir):
            for d in inst.defines:
                if d not in used_after:
                    notes.append({
                        "uid": str(inst.uid),
                        "var": d,
                        "status": "candidate",
                        "reason": "defined but not observed later in supported local scan"
                    })
            used_after |= inst.uses
        return list(reversed(notes))

    @staticmethod
    def cost(ir: List[IR]) -> int:
        table = {
            "MOVI": 1, "MOV": 1, "ADD": 1, "SUB": 1, "ADDV": 1, "SUBV": 1,
            "CMP_<": 1, "CMP_>": 1, "CMP_==": 1, "CMP_!=": 1,
            "RAW": 5
        }
        return sum(table.get(i.op, 2) for i in ir)

class Backend:
    def __init__(self, target: str):
        self.target = target
        self.regmap: Dict[str, str] = {}
        self.arm_regs = ["x0","x1","x2","x3","x4","x5","x6","x7","x8","x9","x10","x11"]
        self.x86_regs = ["rax","rbx","rcx","rdx","r8","r9","r10","r11"]

    def reg(self, var: Optional[str]) -> str:
        if not var:
            return ""
        if var not in self.regmap:
            pool = self.arm_regs if self.target == "arm64" else self.x86_regs
            self.regmap[var] = pool[len(self.regmap) % len(pool)]
        return self.regmap[var]

    def emit(self, ir: List[IR]) -> str:
        return self.emit_arm64(ir) if self.target == "arm64" else self.emit_x86(ir)

    def emit_arm64(self, ir: List[IR]) -> str:
        lines = ["// RAFAELIA ROOT OPTIMIZER 0.2 - ARM64 textual output"]
        for i in ir:
            d = self.reg(i.dst)
            s = self.reg(i.src)
            if i.op == "MOVI": lines.append(f"mov {d}, #{i.imm}    // {i.uid}: {i.origin}")
            elif i.op == "MOV": lines.append(f"mov {d}, {s}    // {i.uid}: {i.origin}")
            elif i.op == "ADD": lines.append(f"add {d}, {d}, #{i.imm}    // {i.uid}: {i.origin}")
            elif i.op == "SUB": lines.append(f"sub {d}, {d}, #{i.imm}    // {i.uid}: {i.origin}")
            elif i.op == "ADDV": lines.append(f"add {d}, {d}, {s}    // {i.uid}: {i.origin}")
            elif i.op == "SUBV": lines.append(f"sub {d}, {d}, {s}    // {i.uid}: {i.origin}")
            elif i.op.startswith("CMP_"): lines.append(f"cmp {s}, #{i.imm}    // {i.uid}: {i.origin} | barrier preserved")
            else: lines.append(f"// raw/barrier {i.uid}: {i.origin}")
        return "\n".join(lines)

    def emit_x86(self, ir: List[IR]) -> str:
        lines = ["; RAFAELIA ROOT OPTIMIZER 0.2 - x86_64 textual output"]
        for i in ir:
            d = self.reg(i.dst)
            s = self.reg(i.src)
            if i.op == "MOVI": lines.append(f"mov {d}, {i.imm}    ; {i.uid}: {i.origin}")
            elif i.op == "MOV": lines.append(f"mov {d}, {s}    ; {i.uid}: {i.origin}")
            elif i.op == "ADD": lines.append(f"add {d}, {i.imm}    ; {i.uid}: {i.origin}")
            elif i.op == "SUB": lines.append(f"sub {d}, {i.imm}    ; {i.uid}: {i.origin}")
            elif i.op == "ADDV": lines.append(f"add {d}, {s}    ; {i.uid}: {i.origin}")
            elif i.op == "SUBV": lines.append(f"sub {d}, {s}    ; {i.uid}: {i.origin}")
            elif i.op.startswith("CMP_"): lines.append(f"cmp {s}, {i.imm}    ; {i.uid}: {i.origin} | barrier preserved")
            else: lines.append(f"; raw/barrier {i.uid}: {i.origin}")
        return "\n".join(lines)

def run(path: str, target: str, report_path: Optional[str], asm_path: Optional[str]):
    data = open(path, "rb").read()
    if len(data) > MAX_INPUT_BYTES:
        raise SystemExit(f"input too large: {len(data)} bytes")

    code = data.decode("utf-8", errors="replace")
    parser = Parser()
    ir = parser.parse(code)
    original_cost = Heuristics.cost(ir)

    scheduled = Graph(ir).schedule_safe_blocks()
    optimized_cost = Heuristics.cost(scheduled)

    asm = Backend(target).emit(scheduled)
    asm_bytes = asm.encode()

    report = {
        "tool": "rafaelia-root-optimizer",
        "version": "0.2",
        "input": path,
        "target": target,
        "timestamp": int(time.time()),
        "input_md5": md5_bytes(data),
        "input_sha256": sha256_bytes(data),
        "asm_md5": md5_bytes(asm_bytes),
        "asm_sha256": sha256_bytes(asm_bytes),
        "original_cost": original_cost,
        "optimized_cost": optimized_cost,
        "cost_delta": original_cost - optimized_cost,
        "dead_assignment_candidates": Heuristics.dead_assignment_candidates(scheduled),
        "ir": [i.to_json() for i in scheduled],
        "methodology": [
            "barrier-preserving scheduling",
            "RAW dependency graph",
            "constant folding",
            "branchless candidate only",
            "MD5 legacy trace + SHA256 integrity"
        ],
        "mitigations": [
            "no reorder through barriers",
            "unknown syntax becomes RAW_BARRIER",
            "cmp preserved for branch candidates",
            "input size limit",
            "origin retained per instruction"
        ],
    }
    report_blob = json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True).encode()
    report["report_sha256"] = sha256_bytes(report_blob)

    if asm_path:
        open(asm_path, "w", encoding="utf-8").write(asm + "\n")
    else:
        print(asm)

    if report_path:
        open(report_path, "w", encoding="utf-8").write(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))

def main():
    ap = argparse.ArgumentParser(prog="raf_optimizer.py")
    ap.add_argument("input")
    ap.add_argument("--target", choices=["arm64", "x86_64"], default="arm64")
    ap.add_argument("--report")
    ap.add_argument("--asm")
    ns = ap.parse_args()
    run(ns.input, ns.target, ns.report, ns.asm)

if __name__ == "__main__":
    main()
