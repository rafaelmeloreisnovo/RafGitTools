# Segurança

## Limites intencionais

Este projeto não faz:

- decompilação DEX;
- bypass de proteção;
- assinatura de APK;
- remoção de assinatura;
- alteração de app de terceiro;
- extração de segredo;
- execução automática de payload externo.

## Mitigações

### Path traversal

Entradas ZIP/APK com `../`, caminho absoluto ou drive Windows são bloqueadas.

### ZIP bomb

O auditor calcula:

- tamanho total descomprimido;
- razão comprimido/descomprimido;
- quantidade de entradas;
- maior entrada.

Arquivos acima dos limites configurados são marcados como risco.

### Hash

Relatórios possuem:

- md5;
- sha256;
- hash por entrada;
- hash do relatório.

### Modo seguro

Por padrão, o APK é apenas lido. A recompressão opcional cria cópia estrutural não assinada.
