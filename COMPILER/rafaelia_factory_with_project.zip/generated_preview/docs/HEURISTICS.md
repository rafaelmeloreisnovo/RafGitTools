# Heurísticas e Mitigações

## Heurísticas implementadas

1. Constant folding simples.
2. Cópia explícita antes de ADD/SUB.
3. Dead assignment candidate.
4. Dependency graph RAW.
5. Scheduling seguro por bloco.
6. Barreiras para `if`, `call`, `raw` e entrada desconhecida.
7. Detecção de branchless candidate sem aplicar transformação destrutiva.
8. Cálculo de custo estimado por instrução.
9. Classificação de risco por transformação.
10. Auditoria MD5/SHA256.

## Mitigações implementadas

1. Não reordenar através de barreiras.
2. Não apagar instrução se variável pode ser observada.
3. Não gerar `cmov/csel` sem `cmp` preservado.
4. Não aceitar arquivo enorme sem alerta.
5. Não processar ZIP com path traversal.
6. Não tratar MD5 como prova forte.
7. Não modificar APK de entrada.
8. Não escrever fora do diretório de saída.
