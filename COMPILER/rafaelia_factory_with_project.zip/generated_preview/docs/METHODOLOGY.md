# Metodologias RAFAELIA

## 1. Fonte como evidência

Nenhuma transformação deve apagar a origem. Cada instrução IR carrega:

- uid
- linha original
- operação
- defines
- uses
- hash parcial

## 2. Sem inferência destrutiva

Heurística não é prova. Toda otimização deve ser marcada como:

- `safe`: preserva semântica no subconjunto suportado.
- `candidate`: precisa validação.
- `blocked`: mitigada por risco.

## 3. Pipeline

```text
read
→ normalize
→ tokenize
→ parse
→ IR
→ dependency graph
→ heuristics
→ mitigations
→ emit
→ audit
```

## 4. Auditoria dupla

O sistema gera MD5 para compatibilidade histórica e SHA256 para integridade forte.

MD5 não deve ser usado como prova criptográfica forte. Ele serve para rastreio legado.
SHA256 é o hash principal.

## 5. Equivalência

Uma otimização só é considerada fechada quando:

- mantém dependências RAW;
- não atravessa barreiras;
- não remove origem;
- não transforma branch sem flags válidas;
- não modifica arquivo fora do diretório permitido.
