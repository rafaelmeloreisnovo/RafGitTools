# Prompt para Codex — RAFAELIA Bare-Metal Lab

Trabalhe somente neste repositório.

Objetivo único:
fazer a estrutura compilar limpa em Linux host e preparar caminho para Android NDK, AVR e Raspberry Pi, sem expandir arquitetura.

Não criar novos conceitos.
Não integrar llama.
Não integrar Magisk.
Não criar módulos grandes.
Não trocar a proposta técnica.

Tarefas obrigatórias:

1. Rodar build host:
cmake -S . -B build-host -DCMAKE_BUILD_TYPE=Release
cmake --build build-host --parallel

2. Verificar warnings:
- Wall
- Wextra
- Wpedantic

3. Corrigir apenas erro real de compilação.

4. Preservar headers:
- include/rafaelia_common.h
- include/rafaelia_mmio.h
- include/rafaelia_bench.h
- include/rafaelia_avr_atmega328p.h
- include/rafaelia_rpi_bcm.h

5. Não adicionar dependência externa.

6. Se mexer em CMakeLists.txt, manter C puro C11.

7. Gerar relatório curto:
- o que compilou;
- o que quebrou;
- o que foi corrigido;
- o que ainda depende de hardware real.

Critério de aceite:
- build host limpo;
- scripts preservados;
- CI não removido;
- documentação não apagada;
- nada inventado fora do escopo.
