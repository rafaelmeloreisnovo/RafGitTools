#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

: "${ANDROID_NDK_HOME:?Defina ANDROID_NDK_HOME apontando para o Android NDK}"

for ABI in arm64-v8a armeabi-v7a; do
  BUILD="$ROOT/build-android-$ABI"
  cmake -S "$ROOT" -B "$BUILD"     -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake"     -DANDROID_ABI="$ABI"     -DANDROID_PLATFORM=android-23     -DCMAKE_BUILD_TYPE=Release
  cmake --build "$BUILD" --parallel
done
