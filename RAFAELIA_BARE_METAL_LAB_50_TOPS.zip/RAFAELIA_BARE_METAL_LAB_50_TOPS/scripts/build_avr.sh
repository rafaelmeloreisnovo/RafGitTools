#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/build-avr"
mkdir -p "$OUT"

cat > "$OUT/blink_pb5.c" <<'EOF'
#include <stdint.h>
#include "rafaelia_avr_atmega328p.h"

int main(void) {
    rafaelia_avr_pb5_output();
    for (;;) {
        rafaelia_avr_pb5_toggle_via_pinb();
        for (volatile uint16_t i = 0; i < 60000u; ++i) {}
    }
}
EOF

avr-gcc -mmcu=atmega328p -DF_CPU=16000000UL -Os   -I"$ROOT/include"   -ffunction-sections -fdata-sections   -Wl,--gc-sections   "$OUT/blink_pb5.c" -o "$OUT/blink_pb5.elf"

avr-objcopy -O ihex "$OUT/blink_pb5.elf" "$OUT/blink_pb5.hex"
avr-size --format=avr --mcu=atmega328p "$OUT/blink_pb5.elf"
