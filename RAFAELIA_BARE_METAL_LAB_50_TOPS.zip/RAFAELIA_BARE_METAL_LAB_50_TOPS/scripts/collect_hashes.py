#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
items = []

for path in sorted(root.rglob("*")):
    if path.is_file() and not any(part.startswith(".git") for part in path.parts):
        h = hashlib.sha256(path.read_bytes()).hexdigest()
        items.append({
            "path": str(path.relative_to(root)),
            "bytes": path.stat().st_size,
            "sha256": h,
        })

print(json.dumps(items, indent=2, ensure_ascii=False))
