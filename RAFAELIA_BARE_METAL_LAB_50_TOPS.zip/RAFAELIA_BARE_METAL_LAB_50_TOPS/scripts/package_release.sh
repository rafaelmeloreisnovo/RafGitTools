#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/dist"
mkdir -p "$OUT"

python3 "$ROOT/scripts/collect_hashes.py" "$ROOT" > "$OUT/hashes.json"

tar -czf "$OUT/rafaelia-bare-metal-lab.tar.gz"   --exclude build-host   --exclude build-android-arm64-v8a   --exclude build-android-armeabi-v7a   --exclude build-avr   --exclude dist   -C "$ROOT" .

echo "Release em: $OUT/rafaelia-bare-metal-lab.tar.gz"
