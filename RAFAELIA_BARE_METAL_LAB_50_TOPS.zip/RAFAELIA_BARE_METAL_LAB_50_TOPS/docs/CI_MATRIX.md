# Matriz de CI

## Linux host

- gcc
- clang
- cmake
- ninja
- shellcheck
- python checks

## Android NDK

- arm64-v8a
- armeabi-v7a
- API mínima definida no projeto
- CMake toolchain do NDK

## AVR

- avr-gcc
- avr-objcopy
- avr-size

## Raspberry Pi cross

- aarch64-linux-gnu-gcc
- arm-linux-gnueabihf-gcc

## Saídas esperadas

- binários;
- logs;
- arquivos JSON de benchmark sintético;
- manifesto;
- hashes;
- relatório markdown.
