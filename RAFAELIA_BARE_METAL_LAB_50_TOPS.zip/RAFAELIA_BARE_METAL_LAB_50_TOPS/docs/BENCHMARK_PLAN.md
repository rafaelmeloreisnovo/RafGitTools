# Plano de Benchmark

## Métricas obrigatórias

- tempo médio;
- p50;
- p95;
- p99;
- mínimo;
- máximo;
- desvio;
- throughput;
- tamanho binário;
- uso de memória;
- hash do artefato.

## Benchmarks mínimos

### GPIO
Comparar:

- acesso direto;
- biblioteca comum;
- syscall;
- framework alto nível.

### Timer
Comparar:

- delay busy loop;
- Timer CTC;
- interrupção;
- clock monotônico.

### ADC
Comparar:

- leitura comum;
- free-running;
- oversampling;
- filtragem fixa.

### SPI/I2C
Comparar:

- biblioteca;
- registrador direto;
- DMA quando disponível.

### NEON
Comparar:

- loop C escalar;
- loop C otimizado;
- intrinsics NEON;
- assembly pontual.

### Android
Comparar:

- Java/Kotlin puro;
- JNI simples;
- JNI com batch;
- NDK direto.

## Formato JSON

Cada benchmark deve gerar arquivo `bench/results/*.json`.

Campos:

- name;
- target;
- arch;
- compiler;
- flags;
- iterations;
- mean_ns;
- p95_ns;
- p99_ns;
- binary_size_bytes;
- sha256;
- notes.
