# Manifesto de Arquivos

## Documentação

- `README.md`
- `docs/50_TOPS_LATENTES.md`
- `docs/ROADMAP.md`
- `docs/VALIDATION_PROTOCOL.md`
- `docs/HARDWARE_TARGETS.md`
- `docs/BENCHMARK_PLAN.md`
- `docs/ARCHITECTURE.md`
- `docs/LEVELS_OF_EVIDENCE.md`
- `docs/CI_MATRIX.md`

## Código

- `include/rafaelia_common.h`
- `include/rafaelia_mmio.h`
- `include/rafaelia_bench.h`
- `include/rafaelia_avr_atmega328p.h`
- `include/rafaelia_rpi_bcm.h`
- `src/rafaelia_bench.c`
- `src/rafaelia_stub.c`

## Scripts

- `scripts/build_host.sh`
- `scripts/build_android.sh`
- `scripts/build_avr.sh`
- `scripts/collect_hashes.py`
- `scripts/package_release.sh`

## CI

- `.github/workflows/ci.yml`

## Prompts

- `prompts/CODEX_BUILD_FIX_PROMPT.md`
