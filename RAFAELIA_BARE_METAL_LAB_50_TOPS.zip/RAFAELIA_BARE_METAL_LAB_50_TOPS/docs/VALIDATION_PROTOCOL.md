# Protocolo de Validação Técnica

## Classes de validação

### N0 — Ideia
Existe apenas como hipótese textual.

### N1 — Esqueleto
Existe arquivo, função ou header inicial, mas ainda sem compilação limpa.

### N2 — Compila
Compila em pelo menos um alvo.

### N3 — Executa
Roda em hardware real ou ambiente controlado.

### N4 — Mede
Gera métrica: ciclos, latência, tamanho, consumo, throughput ou jitter.

### N5 — Reproduz
Outro ambiente consegue repetir resultado com hash, flags e logs.

## Campos mínimos de evidência

Cada técnica deve registrar:

- nome;
- alvo;
- commit;
- compilador;
- versão do compilador;
- flags;
- tamanho binário;
- hash SHA256;
- tempo médio;
- p95;
- p99;
- observação;
- limite conhecido.

## Regra de recusa técnica

Se não houver medição, a técnica deve ser marcada como:

- experimental;
- não validada;
- dependente de hardware;
- dependente de datasheet;
- dependente de kernel/driver.
