# Arquitetura Mínima

## Princípio

A arquitetura deve ser menor que o problema.

Não criar camadas antes de medir o custo da ausência delas.

## Camadas

### 1. Hardware Map
Mapeia registradores, bits e periféricos.

### 2. Primitive Ops
Operações mínimas:

- set bit;
- clear bit;
- toggle bit;
- read bit;
- memory barrier;
- cycle counter.

### 3. Drivers mínimos
Apenas quando necessário:

- GPIO;
- Timer;
- UART;
- SPI;
- I2C;
- ADC;
- PWM;
- DMA.

### 4. Bench Layer
Mede tudo.

### 5. Host Orchestrator
Scripts para compilar, rodar, medir e empacotar.

### 6. Android Bridge
JNI fino para acionar núcleo nativo.

### 7. VM Layer
Vectras/QEMU entra somente depois da medição do núcleo.

## Proibição estrutural

Não criar:

- framework interno sem benchmark;
- classe abstrata antes de uso real;
- DSL antes de validar o formato manual;
- scheduler antes de medir gargalos.
