# Roadmap Técnico

## Fase 0 — Congelamento de escopo

Objetivo: impedir expansão desordenada.

Critérios:

- não integrar novos frameworks;
- não criar módulo sem teste;
- não afirmar performance sem benchmark;
- não misturar documentação filosófica com medição técnica.

Entregáveis:

- README técnico;
- lista de alvos;
- matriz de compilação;
- protocolo de evidência.

## Fase 1 — Bare-metal mínimo

Objetivo: validar registrador, bit e ciclo.

Entregáveis:

- blink AVR sem Arduino;
- GPIO Raspberry Pi por `/dev/gpiomem`;
- benchmark de toggle;
- relatório JSON.

## Fase 2 — Medição séria

Objetivo: transformar hipótese em dado.

Entregáveis:

- CSV de latência;
- hash de binário;
- flags de compilação;
- tamanho `.text`, `.data`, `.bss`;
- comparação contra baseline.

## Fase 3 — Android NDK / Termux

Objetivo: levar o núcleo para Android sem carregar overhead desnecessário.

Entregáveis:

- build arm64-v8a;
- build armeabi-v7a;
- CLI Termux;
- JNI mínimo;
- logs reproduzíveis.

## Fase 4 — Vectras / QEMU

Objetivo: medir gargalos reais antes de otimizar.

Entregáveis:

- profiling do TCG;
- contagem de blocos traduzidos;
- custo de dispatch;
- custo de syscall;
- relatório de hot paths.

## Fase 5 — Produto

Objetivo: tornar o sistema demonstrável.

Entregáveis:

- pacote de exemplos;
- documentação por evidência;
- dashboard de benchmark;
- release zipado;
- workflow CI.
