# Níveis de Evidência

## Termos permitidos

### Hipótese
Ainda não compilou nem mediu.

### Protótipo
Compila ou executa, mas sem benchmark.

### Experimental
Executa e tem medição inicial.

### Validado em bancada
Medição feita em hardware real.

### Validado em CI
Compila e testa automaticamente.

### Reproduzível
Outro ambiente consegue repetir resultado com logs e hash.

## Termos a evitar

Evitar como afirmação final:

- inédito;
- nunca aplicado;
- máximo absoluto;
- impossível superar;
- 100x melhor;
- zero overhead.

Esses termos só podem aparecer em seção de hipótese ou intenção, nunca como resultado medido.
