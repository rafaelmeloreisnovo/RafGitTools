# Alvos de Hardware

## MCU

### ATmega328P
Uso: baseline educacional e validação de registrador direto.

Medições principais:

- ciclos de GPIO;
- tamanho de flash;
- uso de SRAM;
- ADC free-running;
- Timer CTC;
- PWM;
- UART.

### RP2040
Uso: alvo moderno barato com PIO.

Medições principais:

- PIO state machines;
- dual core;
- DMA;
- GPIO determinístico.

### STM32
Uso: alvo industrial de MCU.

Medições principais:

- timers avançados;
- DMA;
- ADC;
- baixo consumo;
- interrupções.

### ESP32
Uso: IoT e conectividade.

Medições principais:

- dual core;
- Wi-Fi impactando jitter;
- periféricos;
- FreeRTOS overhead.

## Linux ARM

### Raspberry Pi 3/4/5
Uso: ARM Linux baixo nível e periféricos via MMIO.

Medições principais:

- `/dev/gpiomem`;
- `/dev/mem`;
- NEON;
- DMA;
- SPI;
- I2C;
- PWM.

## Android

### ARM64-v8a
Uso: alvo principal moderno.

Medições principais:

- NDK;
- JNI;
- NEON;
- startup;
- throughput;
- tamanho APK/AAB.

### armeabi-v7a
Uso: compatibilidade com aparelhos 32-bit.

Medições principais:

- ARMv7;
- NEON opcional;
- limite de memória;
- compatibilidade Termux.
