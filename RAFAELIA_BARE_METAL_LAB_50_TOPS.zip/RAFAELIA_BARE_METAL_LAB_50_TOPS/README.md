# RAFAELIA Bare-Metal Lab — 50 Tops Latentes

Versão: 0.1.0  
Data-base: 2026-05-06

Este pacote organiza os 50 tópicos latentes em uma estrutura prática de projeto.

Objetivo central:

- sair de texto solto;
- virar repositório testável;
- compilar em múltiplos alvos;
- medir ciclos, tamanho binário, latência, consumo e regressão;
- separar hipótese, técnica experimental e técnica validada.

## Núcleo técnico

O projeto parte de quatro eixos:

1. Bare-metal em microcontroladores.
2. Raspberry Pi / ARM / Linux baixo nível.
3. Android NDK / Termux / Vectras / QEMU.
4. IA compacta, estado semântico e validação de coerência.

## Estrutura

- `docs/50_TOPS_LATENTES.md`: lista completa dos 50 tópicos.
- `docs/ROADMAP.md`: etapas de evolução.
- `docs/VALIDATION_PROTOCOL.md`: protocolo de validação técnica.
- `docs/HARDWARE_TARGETS.md`: alvos de hardware.
- `docs/BENCHMARK_PLAN.md`: plano de medições.
- `docs/ARCHITECTURE.md`: arquitetura mínima.
- `docs/LEVELS_OF_EVIDENCE.md`: níveis de evidência.
- `include/`: headers iniciais.
- `src/`: código mínimo inicial.
- `scripts/`: scripts de build, medição e empacotamento.
- `.github/workflows/ci.yml`: workflow base.
- `prompts/CODEX_BUILD_FIX_PROMPT.md`: prompt para Codex aplicar estrutura sem inventar arquitetura.

## Regra de ouro

Nenhuma afirmação técnica forte entra como “validada” sem:

- compilação;
- medição;
- ambiente descrito;
- hash do binário;
- flags de compilação;
- resultado reproduzível.

## Status inicial

Este ZIP é uma semente estrutural. Ele não promete performance. Ele cria a base para provar performance.
