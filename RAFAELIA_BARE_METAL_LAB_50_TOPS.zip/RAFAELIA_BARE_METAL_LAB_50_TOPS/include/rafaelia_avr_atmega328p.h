#ifndef RAFAELIA_AVR_ATMEGA328P_H
#define RAFAELIA_AVR_ATMEGA328P_H

#include <stdint.h>

#define RAFAELIA_AVR_DDRB   (*(volatile uint8_t *)0x24)
#define RAFAELIA_AVR_PORTB  (*(volatile uint8_t *)0x25)
#define RAFAELIA_AVR_PINB   (*(volatile uint8_t *)0x23)

#define RAFAELIA_AVR_DDRC   (*(volatile uint8_t *)0x27)
#define RAFAELIA_AVR_PORTC  (*(volatile uint8_t *)0x28)
#define RAFAELIA_AVR_PINC   (*(volatile uint8_t *)0x26)

#define RAFAELIA_AVR_DDRD   (*(volatile uint8_t *)0x2A)
#define RAFAELIA_AVR_PORTD  (*(volatile uint8_t *)0x2B)
#define RAFAELIA_AVR_PIND   (*(volatile uint8_t *)0x29)

#define RAFAELIA_AVR_BIT(n) ((uint8_t)(1u << (n)))

static inline void rafaelia_avr_pb5_output(void) {
    RAFAELIA_AVR_DDRB |= RAFAELIA_AVR_BIT(5);
}

static inline void rafaelia_avr_pb5_toggle_via_pinb(void) {
    RAFAELIA_AVR_PINB = RAFAELIA_AVR_BIT(5);
}

#endif
