#ifndef RAFAELIA_COMMON_H
#define RAFAELIA_COMMON_H

#include <stdint.h>
#include <stddef.h>

#ifndef RAFAELIA_VERSION
#define RAFAELIA_VERSION "0.1.0"
#endif

#define RAFAELIA_UNUSED(x) ((void)(x))

typedef enum rafaelia_status_e {
    RAFAELIA_OK = 0,
    RAFAELIA_ERR_INVALID_ARG = -1,
    RAFAELIA_ERR_UNSUPPORTED = -2,
    RAFAELIA_ERR_IO = -3,
    RAFAELIA_ERR_TIMEOUT = -4
} rafaelia_status_t;

#endif
