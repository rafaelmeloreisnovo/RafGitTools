#ifndef RAFAELIA_BENCH_H
#define RAFAELIA_BENCH_H

#include <stdint.h>

#if defined(__aarch64__)
static inline uint64_t rafaelia_cycles(void) {
    uint64_t v;
    __asm__ __volatile__("mrs %0, cntvct_el0" : "=r"(v));
    return v;
}

static inline uint64_t rafaelia_cycle_freq(void) {
    uint64_t v;
    __asm__ __volatile__("mrs %0, cntfrq_el0" : "=r"(v));
    return v;
}
#elif defined(__x86_64__)
static inline uint64_t rafaelia_cycles(void) {
    unsigned int lo, hi;
    __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32u) | lo;
}

static inline uint64_t rafaelia_cycle_freq(void) {
    return 0;
}
#else
static inline uint64_t rafaelia_cycles(void) {
    return 0;
}

static inline uint64_t rafaelia_cycle_freq(void) {
    return 0;
}
#endif

#endif
