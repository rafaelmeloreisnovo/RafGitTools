#ifndef RAFAELIA_RPI_BCM_H
#define RAFAELIA_RPI_BCM_H

#include <stdint.h>

#define RAFAELIA_RPI1_PERIPH_BASE  0x20000000UL
#define RAFAELIA_RPI2_3_BASE       0x3F000000UL
#define RAFAELIA_RPI4_BASE         0xFE000000UL

#define RAFAELIA_BCM_GPIO_OFFSET   0x00200000UL
#define RAFAELIA_BCM_PWM_OFFSET    0x0020C000UL
#define RAFAELIA_BCM_CLK_OFFSET    0x00101000UL
#define RAFAELIA_BCM_SPI0_OFFSET   0x00204000UL
#define RAFAELIA_BCM_I2C1_OFFSET   0x00804000UL
#define RAFAELIA_BCM_TIMER_OFFSET  0x00003000UL

#define RAFAELIA_GPIO_GPFSEL0      0x00u
#define RAFAELIA_GPIO_GPSET0       0x1Cu
#define RAFAELIA_GPIO_GPCLR0       0x28u
#define RAFAELIA_GPIO_GPLEV0       0x34u

static inline uint32_t rafaelia_rpi_gpio_fsel_offset(unsigned gpio) {
    return (gpio / 10u) * 4u;
}

static inline unsigned rafaelia_rpi_gpio_fsel_shift(unsigned gpio) {
    return (gpio % 10u) * 3u;
}

#endif
