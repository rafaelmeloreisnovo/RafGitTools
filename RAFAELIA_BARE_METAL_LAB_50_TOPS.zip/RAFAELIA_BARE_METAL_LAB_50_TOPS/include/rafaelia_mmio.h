#ifndef RAFAELIA_MMIO_H
#define RAFAELIA_MMIO_H

#include <stdint.h>

static inline uint32_t rafaelia_mmio_read32(volatile void *base, uintptr_t offset) {
    volatile uint32_t *p = (volatile uint32_t *)((volatile uint8_t *)base + offset);
    return *p;
}

static inline void rafaelia_mmio_write32(volatile void *base, uintptr_t offset, uint32_t value) {
    volatile uint32_t *p = (volatile uint32_t *)((volatile uint8_t *)base + offset);
    *p = value;
}

static inline void rafaelia_mmio_set_bits32(volatile void *base, uintptr_t offset, uint32_t mask) {
    rafaelia_mmio_write32(base, offset, rafaelia_mmio_read32(base, offset) | mask);
}

static inline void rafaelia_mmio_clear_bits32(volatile void *base, uintptr_t offset, uint32_t mask) {
    rafaelia_mmio_write32(base, offset, rafaelia_mmio_read32(base, offset) & ~mask);
}

#if defined(__aarch64__)
static inline void rafaelia_memory_barrier(void) {
    __asm__ __volatile__("dmb sy" ::: "memory");
}
#else
static inline void rafaelia_memory_barrier(void) {
    __asm__ __volatile__("" ::: "memory");
}
#endif

#endif
