#include <stdio.h>
#include <stdint.h>
#include "rafaelia_bench.h"

extern uint64_t rafaelia_bench_empty_loop(uint32_t iterations);

int main(void) {
    uint32_t iterations = 1000000u;
    uint64_t cycles = rafaelia_bench_empty_loop(iterations);
    uint64_t freq = rafaelia_cycle_freq();

    printf("{\"name\":\"empty_loop\",\"iterations\":%u,\"cycles\":%llu,\"freq\":%llu}\n",
           iterations,
           (unsigned long long)cycles,
           (unsigned long long)freq);
    return 0;
}
