#include <stdint.h>
#include "rafaelia_avr_atmega328p.h"

int main(void) {
    rafaelia_avr_pb5_output();

    for (;;) {
        rafaelia_avr_pb5_toggle_via_pinb();
        for (volatile uint16_t i = 0; i < 60000u; ++i) {}
    }
}
