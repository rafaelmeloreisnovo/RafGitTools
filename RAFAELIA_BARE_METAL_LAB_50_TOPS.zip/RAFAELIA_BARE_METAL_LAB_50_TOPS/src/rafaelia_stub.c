#include "rafaelia_common.h"

int rafaelia_stub(void) {
    return RAFAELIA_OK;
}
