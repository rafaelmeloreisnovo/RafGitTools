#include "rafaelia_bench.h"
#include "rafaelia_common.h"

uint64_t rafaelia_bench_empty_loop(uint32_t iterations) {
    uint64_t start = rafaelia_cycles();
    volatile uint32_t sink = 0;

    for (uint32_t i = 0; i < iterations; ++i) {
        sink += i;
    }

    RAFAELIA_UNUSED(sink);
    return rafaelia_cycles() - start;
}
