package com.rafgittools.worktree

import java.io.File

/**
 * WorktreeManager — git worktree management.
 *
 * JGit 6.x has no public worktree API, so we delegate to the `git` CLI.
 * On Android the git binary is NOT available by default — the app must
 * either bundle a static git binary (e.g. via termux-packages) or limit
 * worktree support to rooted/termux environments.
 *
 * This implementation uses ProcessBuilder with `git worktree` subcommands
 * and returns typed Result<T> for safe error propagation.
 */
object WorktreeManager {

    data class Worktree(
        val path: String,
        val branch: String?,
        val headSha: String?,
        val isMain: Boolean = false,
        val isLocked: Boolean = false,
        val isPrunable: Boolean = false
    )

    /**
     * Add a linked worktree at [worktreePath] checked out to [branch].
     * Pass [createBranch] = true to create the branch if it doesn't exist.
     */
    fun add(
        repoPath: String,
        worktreePath: String,
        branch: String,
        createBranch: Boolean = false
    ): Result<Worktree> = runCatching {
        val args = buildList {
            add("git"); add("worktree"); add("add")
            if (createBranch) add("-b")
            add(worktreePath)
            add(branch)
        }
        val res = exec(repoPath, args)
        if (res.exitCode != 0) error("git worktree add failed: ${res.stderr}")
        Worktree(path = worktreePath, branch = branch, headSha = null)
    }

    /**
     * List all worktrees (main + linked). Parses `git worktree list --porcelain`.
     */
    fun list(repoPath: String): Result<List<Worktree>> = runCatching {
        val res = exec(repoPath, listOf("git", "worktree", "list", "--porcelain"))
        if (res.exitCode != 0) error("git worktree list failed: ${res.stderr}")

        val worktrees = mutableListOf<Worktree>()
        var path: String? = null
        var head: String? = null
        var branch: String? = null
        var isMain = false
        var isLocked = false
        var isPrunable = false

        fun flush() {
            if (path != null) {
                worktrees.add(Worktree(path!!, branch, head, isMain, isLocked, isPrunable))
                path = null; head = null; branch = null
                isMain = false; isLocked = false; isPrunable = false
            }
        }

        for (line in res.stdout.lines()) {
            when {
                line.startsWith("worktree ") -> { flush(); path = line.removePrefix("worktree "); isMain = worktrees.isEmpty() }
                line.startsWith("HEAD ")     -> head = line.removePrefix("HEAD ")
                line.startsWith("branch ")   -> branch = line.removePrefix("branch refs/heads/")
                line == "locked"             -> isLocked = true
                line == "prunable"           -> isPrunable = true
                line.isBlank()              -> flush()
            }
        }
        flush()
        worktrees
    }

    /**
     * Remove the linked worktree at [worktreePath].
     * Use [force] = true to remove even if the worktree has uncommitted changes.
     */
    fun remove(repoPath: String, worktreePath: String, force: Boolean = false): Result<Unit> = runCatching {
        val args = buildList {
            add("git"); add("worktree"); add("remove")
            if (force) add("--force")
            add(worktreePath)
        }
        val res = exec(repoPath, args)
        if (res.exitCode != 0) error("git worktree remove failed: ${res.stderr}")
    }

    /** Lock a worktree to prevent `git worktree prune` from deleting it. */
    fun lock(repoPath: String, worktreePath: String, reason: String = ""): Result<Unit> = runCatching {
        val args = buildList {
            add("git"); add("worktree"); add("lock")
            if (reason.isNotBlank()) { add("--reason"); add(reason) }
            add(worktreePath)
        }
        val res = exec(repoPath, args)
        if (res.exitCode != 0) error("git worktree lock failed: ${res.stderr}")
    }

    /** Prune stale worktree administrative files. */
    fun prune(repoPath: String, dryRun: Boolean = false): Result<List<String>> = runCatching {
        val args = buildList {
            add("git"); add("worktree"); add("prune"); add("-v")
            if (dryRun) add("--dry-run")
        }
        val res = exec(repoPath, args)
        if (res.exitCode != 0) error("git worktree prune failed: ${res.stderr}")
        res.stdout.lines().filter { it.isNotBlank() }
    }

    // ── Process helper ────────────────────────────────────────────────────────
    private data class CmdResult(val exitCode: Int, val stdout: String, val stderr: String)

    private fun exec(workDir: String, args: List<String>): CmdResult {
        val proc = ProcessBuilder(args)
            .directory(File(workDir))
            .redirectErrorStream(false)
            .start()
        val out = proc.inputStream.bufferedReader().readText()
        val err = proc.errorStream.bufferedReader().readText()
        return CmdResult(proc.waitFor(), out, err)
    }
}
