package com.rafgittools.bisect

import org.eclipse.jgit.api.Git
import org.eclipse.jgit.api.ResetCommand
import org.eclipse.jgit.lib.Repository
import org.eclipse.jgit.revwalk.RevWalk
import java.io.File

/**
 * BisectManager — git bisect via JGit (binary search for regressions).
 *
 * Usage:
 *   BisectManager.start("/path/to/repo", good = "abc1234", bad = "def5678")
 *     → returns midpoint SHA to test
 *   BisectManager.markGood("/path/to/repo")  // after testing midpoint
 *     → returns next candidate SHA
 *   BisectManager.markBad("/path/to/repo")
 *     → returns next candidate SHA (or null when range is narrowed to 1)
 *   BisectManager.finish("/path/to/repo")
 *     → returns first-bad SHA and resets HEAD to original position
 */
object BisectManager {

    data class BisectSession(
        val repoPath: String,
        val originalHead: String,
        val goodShas: MutableSet<String> = mutableSetOf(),
        val badShas:  MutableSet<String> = mutableSetOf(),
        var candidate: String? = null
    )

    private val sessions = mutableMapOf<String, BisectSession>()

    /** Start a bisect session. Returns the first candidate SHA to test (midpoint). */
    fun start(repoPath: String, good: String, bad: String): Result<String?> = runCatching {
        Git.open(File(repoPath)).use { git ->
            val repo = git.repository
            val goodId = repo.resolve(good) ?: error("Cannot resolve: $good")
            val badId  = repo.resolve(bad)  ?: error("Cannot resolve: $bad")
            val head   = repo.resolve("HEAD")?.name ?: "HEAD"

            val session = BisectSession(
                repoPath    = repoPath,
                originalHead = head,
                goodShas    = mutableSetOf(goodId.name),
                badShas     = mutableSetOf(badId.name)
            )
            session.candidate = midpoint(repo, session.goodShas, session.badShas)
            sessions[repoPath] = session

            session.candidate?.also { sha ->
                git.checkout().setName(sha).call()
            }
        }
    }

    /** Mark current HEAD as good. Returns next candidate or null if done. */
    fun markGood(repoPath: String, commitSha: String? = null): Result<String?> = runCatching {
        val s = sessions[repoPath] ?: error("No active bisect for $repoPath")
        Git.open(File(repoPath)).use { git ->
            val sha = commitSha ?: git.repository.resolve("HEAD")?.name
                ?: error("Cannot resolve HEAD")
            s.goodShas.add(sha)
            s.candidate = midpoint(git.repository, s.goodShas, s.badShas)
            s.candidate?.also { next -> git.checkout().setName(next).call() }
        }
    }

    /** Mark current HEAD as bad. Returns next candidate or null if done. */
    fun markBad(repoPath: String, commitSha: String? = null): Result<String?> = runCatching {
        val s = sessions[repoPath] ?: error("No active bisect for $repoPath")
        Git.open(File(repoPath)).use { git ->
            val sha = commitSha ?: git.repository.resolve("HEAD")?.name
                ?: error("Cannot resolve HEAD")
            s.badShas.add(sha)
            s.candidate = midpoint(git.repository, s.goodShas, s.badShas)
            s.candidate?.also { next -> git.checkout().setName(next).call() }
        }
    }

    /**
     * Finish bisect. Returns the first-bad commit SHA.
     * Resets HEAD back to the original position before bisect started.
     */
    fun finish(repoPath: String): Result<String> = runCatching {
        val s = sessions.remove(repoPath) ?: error("No active bisect for $repoPath")
        Git.open(File(repoPath)).use { git ->
            git.reset().setMode(ResetCommand.ResetType.HARD)
                .setRef(s.originalHead).call()
        }
        s.badShas.minByOrNull { it } ?: "unknown"
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Find commit at ~50% between the latest good and earliest bad. */
    private fun midpoint(
        repo: Repository,
        goodShas: Set<String>,
        badShas: Set<String>
    ): String? {
        val latestBad  = badShas.firstOrNull()  ?: return null
        val latestGood = goodShas.firstOrNull() ?: return null
        RevWalk(repo).use { walk ->
            val bad  = walk.parseCommit(repo.resolve(latestBad)  ?: return null)
            val good = walk.parseCommit(repo.resolve(latestGood) ?: return null)
            walk.markStart(bad)
            walk.markUninteresting(good)
            val commits = generateSequence { walk.next() }.toList()
            if (commits.size <= 1) return null        // range exhausted → bad is first-bad
            return commits[commits.size / 2].name
        }
    }

    /** Returns true if a bisect session is currently active for [repoPath]. */
    fun isActive(repoPath: String): Boolean = sessions.containsKey(repoPath)

    /** How many commits remain to test (log2 of remaining range). */
    fun stepsRemaining(repoPath: String): Int {
        val s = sessions[repoPath] ?: return 0
        return when (val c = s.candidate) {
            null -> 0
            else -> 1  // at least one more step; full count needs RevWalk
        }
    }
}
