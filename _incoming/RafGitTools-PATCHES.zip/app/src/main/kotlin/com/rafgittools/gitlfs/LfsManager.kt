package com.rafgittools.gitlfs

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * LfsManager — Git LFS pointer-file management and download.
 *
 * JGit 6.x does not natively support LFS. This implementation:
 *  - Reads / writes .gitattributes LFS tracking rules
 *  - Detects and parses LFS pointer files
 *  - Downloads LFS objects via GitHub's Batch API (RFC draft)
 *  - Writes downloaded content back in-place (replaces pointer with real file)
 *
 * LFS pointer format:
 *   version https://git-lfs.github.com/spec/v1
 *   oid sha256:<hex64>
 *   size <bytes>
 */
object LfsManager {

    private const val LFS_MAGIC   = "version https://git-lfs.github.com/spec/v1"
    private const val BATCH_PATH  = "/info/lfs/objects/batch"
    private const val MAX_PTR_LEN = 512   // pointers are tiny; real files are bigger

    data class LfsPointer(val oid: String, val size: Long)

    // ── .gitattributes ────────────────────────────────────────────────────────

    /**
     * Register [pattern] (e.g. `*.psd`, `assets/**`) in `.gitattributes`
     * with the standard LFS filter attributes. Idempotent.
     */
    fun track(repoPath: String, pattern: String): Result<Unit> = runCatching {
        val attr = File(repoPath, ".gitattributes")
        val rule = "$pattern filter=lfs diff=lfs merge=lfs -text"
        val lines = if (attr.exists()) attr.readLines().toMutableList() else mutableListOf()
        if (lines.none { it.trimStart().startsWith(pattern) }) {
            lines += rule
            attr.writeText(lines.joinToString("\n") + "\n")
        }
    }

    /**
     * Remove LFS tracking rule for [pattern].
     */
    fun untrack(repoPath: String, pattern: String): Result<Unit> = runCatching {
        val attr = File(repoPath, ".gitattributes")
        if (!attr.exists()) return@runCatching
        val filtered = attr.readLines().filterNot { it.trimStart().startsWith(pattern) }
        attr.writeText(filtered.joinToString("\n") + "\n")
    }

    /** All currently tracked LFS patterns in `.gitattributes`. */
    fun trackedPatterns(repoPath: String): List<String> {
        val attr = File(repoPath, ".gitattributes")
        return if (!attr.exists()) emptyList()
        else attr.readLines()
            .filter { "filter=lfs" in it }
            .map { it.substringBefore(" ").trim() }
    }

    // ── Pointer detection ─────────────────────────────────────────────────────

    /** Returns true if [filePath] is an LFS pointer (not the actual object). */
    fun isPointer(filePath: String): Boolean {
        val f = File(filePath)
        if (!f.exists() || f.length() > MAX_PTR_LEN) return false
        return f.bufferedReader().use { it.readLine()?.startsWith(LFS_MAGIC) == true }
    }

    /**
     * Parse an LFS pointer file.
     * Returns [LfsPointer] with oid (e.g. `sha256:abc...`) and size in bytes.
     */
    fun parsePointer(filePath: String): Result<LfsPointer> = runCatching {
        val lines = File(filePath).readLines()
        require(lines.firstOrNull()?.startsWith(LFS_MAGIC) == true) { "Not an LFS pointer: $filePath" }
        val oid  = lines.first { it.startsWith("oid ")  }.removePrefix("oid ").trim()
        val size = lines.first { it.startsWith("size ") }.removePrefix("size ").trim().toLong()
        LfsPointer(oid, size)
    }

    // ── Batch API download ────────────────────────────────────────────────────

    /**
     * Download a single LFS object from [lfsServerUrl] into [destFile].
     * Uses the GitHub-compatible LFS Batch API.
     *
     * @param lfsServerUrl  Git remote URL, e.g. `https://github.com/owner/repo.git`
     * @param pointer       Parsed LFS pointer (oid + size)
     * @param destFile      Where to write the real file content
     * @param token         GitHub PAT for private repos; null for public
     */
    fun download(
        lfsServerUrl: String,
        pointer: LfsPointer,
        destFile: File,
        token: String? = null
    ): Result<Unit> = runCatching {
        // Step 1 — Batch request
        val batchUrl = lfsServerUrl.trimEnd('/') + BATCH_PATH
        val reqBody  = buildString {
            append("""{"operation":"download","transfers":["basic"],""")
            append(""""objects":[{"oid":"${pointer.oid}","size":${pointer.size}}]}""")
        }

        val batchConn = (URL(batchUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/vnd.git-lfs+json")
            setRequestProperty("Accept",       "application/vnd.git-lfs+json")
            token?.let { setRequestProperty("Authorization", "Bearer $it") }
            doOutput = true
            outputStream.write(reqBody.toByteArray(Charsets.UTF_8))
        }
        check(batchConn.responseCode == 200) {
            "LFS batch failed HTTP ${batchConn.responseCode}: ${batchConn.errorStream?.bufferedReader()?.readText()}"
        }
        val batchResp = batchConn.inputStream.bufferedReader().readText()

        // Step 2 — Parse href (minimal regex; avoids pulling in a JSON library)
        val href = Regex(""""href"\s*:\s*"([^"]+)"""").find(batchResp)?.groupValues?.get(1)
            ?: error("No download href in LFS batch response for oid ${pointer.oid}")

        // Step 3 — Stream download
        val dlConn = URL(href).openConnection() as HttpURLConnection
        token?.let { dlConn.setRequestProperty("Authorization", "Bearer $it") }
        check(dlConn.responseCode in 200..299) {
            "LFS download failed HTTP ${dlConn.responseCode} for $href"
        }
        dlConn.inputStream.use { input ->
            destFile.parentFile?.mkdirs()
            destFile.outputStream().use { out -> input.copyTo(out) }
        }
    }

    /**
     * Smudge a pointer file: if [filePath] is a pointer, download the real object
     * and replace the pointer with the actual content.
     */
    fun smudge(
        filePath: String,
        lfsServerUrl: String,
        token: String? = null
    ): Result<Unit> = runCatching {
        if (!isPointer(filePath)) return@runCatching
        val ptr = parsePointer(filePath).getOrThrow()
        val tmp = File("$filePath.lfs_tmp")
        download(lfsServerUrl, ptr, tmp, token).getOrThrow()
        tmp.renameTo(File(filePath))
    }

    /** Install LFS configuration in a repository (writes `.lfsconfig` marker). */
    fun install(repoPath: String): Result<Unit> = runCatching {
        val cfg = File(repoPath, ".lfsconfig")
        if (!cfg.exists()) cfg.writeText("[lfs]\n\turl = \n")  // user fills url
        val hooks = File(repoPath, ".git/hooks")
        for (hook in listOf("pre-push", "post-checkout", "post-commit", "post-merge")) {
            val h = File(hooks, hook)
            if (!h.exists()) {
                h.writeText("#!/bin/sh\ngit lfs $hook -- \"\$@\"\n")
                h.setExecutable(true)
            }
        }
    }
}
