package com.rafgittools.webhook

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * WebhookHandler — GitHub webhook signature verification and event routing.
 *
 * Every GitHub webhook POST carries:
 *   X-GitHub-Event:     event type (push, pull_request, issues, …)
 *   X-Hub-Signature-256: sha256=<hmac-hex>   (requires webhook secret)
 *   X-GitHub-Delivery:  unique delivery UUID
 *
 * SECURITY: Always verify the signature before processing the payload.
 * Failure to do so opens the endpoint to arbitrary payload injection.
 */
object WebhookHandler {

    // ── Signature verification ────────────────────────────────────────────────

    /**
     * Verify the GitHub HMAC-SHA256 webhook signature.
     *
     * @param secret          Webhook secret configured in repo → Settings → Webhooks.
     * @param payloadBytes    Raw (unmodified) request body bytes.
     * @param signatureHeader Value of `X-Hub-Signature-256` header, e.g. `sha256=abc123`.
     * @return true if signature is valid.
     */
    fun verifySignature(
        secret: String,
        payloadBytes: ByteArray,
        signatureHeader: String
    ): Boolean {
        if (!signatureHeader.startsWith("sha256=")) return false
        val expected = signatureHeader.removePrefix("sha256=").lowercase(java.util.Locale.ROOT)
        val mac = Mac.getInstance("HmacSHA256").apply {
            init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        }
        val computed = mac.doFinal(payloadBytes).joinToString("") { "%02x".format(it) }
        // Constant-time comparison prevents timing-based secret extraction
        return MessageDigest.isEqual(computed.toByteArray(), expected.toByteArray())
    }

    // ── Event routing ─────────────────────────────────────────────────────────

    /** Typed listener for webhook events. */
    interface WebhookListener {
        fun onPush(payload: String)                             = Unit
        fun onPullRequest(action: String, payload: String)      = Unit
        fun onIssues(action: String, payload: String)           = Unit
        fun onIssueComment(action: String, payload: String)     = Unit
        fun onRelease(action: String, payload: String)          = Unit
        fun onStar(action: String, payload: String)             = Unit
        fun onFork(payload: String)                             = Unit
        fun onPing(zen: String, hookId: String)                 = Unit
        fun onCheckRun(action: String, payload: String)         = Unit
        fun onWorkflowRun(action: String, payload: String)      = Unit
        fun onUnknown(eventType: String, payload: String)       = Unit
    }

    /**
     * Route a **verified** webhook payload to the appropriate listener method.
     *
     * @param eventType  Value of `X-GitHub-Event` header.
     * @param payload    Raw JSON string body.
     * @param listener   Your [WebhookListener] implementation.
     */
    fun dispatch(eventType: String, payload: String, listener: WebhookListener) {
        val action = extractField(payload, "action")
        when (eventType.lowercase(java.util.Locale.ROOT)) {
            "push"           -> listener.onPush(payload)
            "pull_request"   -> listener.onPullRequest(action ?: "", payload)
            "issues"         -> listener.onIssues(action ?: "", payload)
            "issue_comment"  -> listener.onIssueComment(action ?: "", payload)
            "release"        -> listener.onRelease(action ?: "", payload)
            "star"           -> listener.onStar(action ?: "", payload)
            "fork"           -> listener.onFork(payload)
            "ping"           -> listener.onPing(
                                    extractField(payload, "zen") ?: "",
                                    extractField(payload, "hook_id") ?: ""
                                )
            "check_run"      -> listener.onCheckRun(action ?: "", payload)
            "workflow_run"   -> listener.onWorkflowRun(action ?: "", payload)
            else             -> listener.onUnknown(eventType, payload)
        }
    }

    /**
     * One-stop handler: verifies signature then dispatches.
     * Returns false (and does NOT dispatch) if the signature is invalid.
     */
    fun handle(
        secret: String,
        eventType: String,
        payload: String,
        signatureHeader: String,
        listener: WebhookListener
    ): Boolean {
        val valid = verifySignature(secret, payload.toByteArray(Charsets.UTF_8), signatureHeader)
        if (valid) dispatch(eventType, payload, listener)
        return valid
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Extract a top-level string field from a JSON payload (no library dependency). */
    fun extractField(json: String, key: String): String? =
        Regex(""""$key"\s*:\s*"([^"]+)"""").find(json)?.groupValues?.get(1)

    /** Extract a top-level numeric field. */
    fun extractLongField(json: String, key: String): Long? =
        Regex(""""$key"\s*:\s*(\d+)""").find(json)?.groupValues?.get(1)?.toLongOrNull()
}

private typealias MessageDigest = java.security.MessageDigest
