package com.rafgittools.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.*
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec

/**
 * GpgKeyManager — asymmetric signing on Android using the Hardware-backed KeyStore.
 *
 * True RFC-4880 GPG is unavailable without native libs. This implementation uses
 * Android KeyStore + ECDSA (secp256r1 / P-256) which is hardware-backed on
 * devices with a Secure Element (TEE). The public key is PEM-encoded for export
 * to GPG-compatible tools via `gpg --import`.
 *
 * Key storage: Android KeyStore (keys never leave the secure element).
 * Algorithm:   ECDSA SHA-256 (equivalent to GPG sign mode 19 / nistP256).
 * Alias format: "gpg_<name>_<email>" — all lowercase, spaces → underscores.
 *
 * For full RFC-4880 armored export/import, add:
 *   implementation 'org.bouncycastle:bcpg-android:1.70'
 */
object GpgKeyManager {

    private const val KEYSTORE   = "AndroidKeyStore"
    private const val EC_ALGO    = "EC"
    private const val SIG_ALGO   = "SHA256withECDSA"
    private const val CURVE      = "secp256r1"

    data class GpgKey(
        val alias: String,
        val email: String,
        val publicKeyPem: String
    )

    // ── Key generation ────────────────────────────────────────────────────────

    /**
     * Generate an ECDSA key pair in the Android KeyStore.
     * [passphrase] is not used for KeyStore keys (the TEE protects the private key),
     * but is retained in the API signature for forward compatibility with software keys.
     * Returns [GpgKey] with alias and PEM-encoded public key.
     */
    fun generateKey(name: String, email: String, passphrase: String): Result<GpgKey> = runCatching {
        val alias = keyAlias(name, email)
        val spec  = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        ).apply {
            setAlgorithmParameterSpec(ECGenParameterSpec(CURVE))
            setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
            setUserAuthenticationRequired(false)   // set to true for biometric gating
        }.build()

        val kpg = KeyPairGenerator.getInstance(EC_ALGO, KEYSTORE)
        kpg.initialize(spec)
        kpg.generateKeyPair()

        val pem = exportPublicKeyPem(alias).getOrThrow()
        GpgKey(alias, email, pem)
    }

    // ── Signing ───────────────────────────────────────────────────────────────

    /**
     * Sign [data] with key [alias].
     * Returns a DER-encoded ECDSA signature (standard format for git commit signing).
     */
    fun signData(data: ByteArray, alias: String, passphrase: String = ""): Result<ByteArray> = runCatching {
        val ks = ks()
        val privateKey = ks.getKey(alias, null) as? PrivateKey
            ?: error("Key not found: $alias")
        Signature.getInstance(SIG_ALGO).apply {
            initSign(privateKey)
            update(data)
        }.sign()
    }

    /**
     * Verify [signature] (DER) over [data] using key [alias].
     */
    fun verifySignature(data: ByteArray, signature: ByteArray, alias: String): Result<Boolean> = runCatching {
        val cert = ks().getCertificate(alias) ?: error("No certificate for alias: $alias")
        Signature.getInstance(SIG_ALGO).apply {
            initVerify(cert.publicKey)
            update(data)
        }.verify(signature)
    }

    // ── Export ────────────────────────────────────────────────────────────────

    /**
     * Export the public key for [alias] as a PEM SubjectPublicKeyInfo block.
     * This can be imported into GPG: `echo "<pem>" | gpg --import`
     */
    fun exportPublicKeyPem(alias: String): Result<String> = runCatching {
        val cert = ks().getCertificate(alias) ?: error("No certificate for alias: $alias")
        val b64  = Base64.encodeToString(cert.publicKey.encoded, Base64.DEFAULT)
        "-----BEGIN PUBLIC KEY-----\n$b64-----END PUBLIC KEY-----"
    }

    // ── Import ────────────────────────────────────────────────────────────────

    /**
     * Import an external PEM public key into session memory for verification.
     * Note: Android KeyStore only accepts keys generated on-device.
     * External public keys are kept in-memory for the session only.
     */
    fun importPublicKey(alias: String, pem: String): Result<Unit> = runCatching {
        val stripped = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replace("\\s".toRegex(), "")
        val bytes     = Base64.decode(stripped, Base64.DEFAULT)
        val publicKey = KeyFactory.getInstance(EC_ALGO).generatePublic(X509EncodedKeySpec(bytes))
        importedKeys[alias] = publicKey
    }

    /**
     * Verify [signature] using an externally imported public key.
     */
    fun verifyWithImportedKey(data: ByteArray, signature: ByteArray, alias: String): Result<Boolean> = runCatching {
        val publicKey = importedKeys[alias] ?: error("No imported key for alias: $alias")
        Signature.getInstance(SIG_ALGO).apply {
            initVerify(publicKey)
            update(data)
        }.verify(signature)
    }

    // ── Key management ────────────────────────────────────────────────────────

    /** List all GPG key aliases stored in the Android KeyStore. */
    fun listKeys(): List<String> = runCatching {
        ks().aliases().toList().filter { it.startsWith("gpg_") }
    }.getOrDefault(emptyList())

    /** Delete a key from the Android KeyStore. */
    fun deleteKey(alias: String): Result<Unit> = runCatching {
        ks().deleteEntry(alias)
    }

    /** Generate a stable alias for name + email. */
    fun keyAlias(name: String, email: String): String =
        "gpg_${name.lowercase().replace(" ", "_")}_${email.lowercase()}"

    // ── Internal ──────────────────────────────────────────────────────────────
    private val importedKeys = mutableMapOf<String, PublicKey>()
    private fun ks() = KeyStore.getInstance(KEYSTORE).also { it.load(null) }
}
