# Prompt para Codex integrar este pacote

Trabalhe somente neste repositório.

Objetivo único:
integrar os modelos C bare-metal/low-level deste pacote sem expandir arquitetura, sem criar módulos conceituais novos e sem inventar dependências.

Tarefas:

1. Criar pasta `rafaelia_lowlevel_models/`.
2. Copiar os grupos Android NDK e MCU bare-metal para essa pasta.
3. Preservar comentários técnicos.
4. Não renomear funções públicas sem necessidade.
5. Adicionar targets de build separados:
   - host syntax check quando possível;
   - Android arm64-v8a;
   - Android armeabi-v7a;
   - AVR se `avr-gcc` existir;
   - Cortex-M se `arm-none-eabi-gcc` existir.
6. Gerar relatório `build_report.md` com:
   - comando executado;
   - sucesso/falha;
   - erro exato;
   - arquivo responsável;
   - próxima correção mínima.
7. Não integrar QEMU, Magisk, llama ou qualquer dependência externa.
8. Não alterar arquivos fora da integração sem justificativa objetiva.

Critério de pronto:
CI local executa e mostra claramente o que compila e o que depende de hardware/toolchain.
