# 02 — MCU true bare-metal C

10 modelos C para acesso direto a registradores, sem runtime pesado.

## Modelos

1. AVR ATmega328P GPIO toggle via PINB.
2. AVR Timer1 CTC.
3. AVR UART0 polling.
4. AVR ADC free-running.
5. RP2040 GPIO via SIO/IO_BANK0.
6. STM32F103 GPIO + TIM2.
7. STM32F401 USART2 + SysTick.
8. ESP32 GPIO register-level skeleton.
9. SAMD21 GPIO + timer skeleton.
10. Startup/vector table + linker mínimo genérico Cortex-M.

## Compilação

Alguns arquivos são skeletons por família e exigem toolchain correta:

- AVR: `avr-gcc`
- Cortex-M: `arm-none-eabi-gcc`
- ESP32: Xtensa toolchain ou ESP-IDF adaptado
- RP2040: `arm-none-eabi-gcc`, preferencialmente com linker/startup próprio

