#include <stdint.h>

/* Modelo 7: STM32F401 USART2 TX em PA2 + SysTick delay skeleton. */
#define MMIO32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define RCC_BASE   0x40023800u
#define GPIOA_BASE 0x40020000u
#define USART2_BASE 0x40004400u
#define SYST_CSR 0xE000E010u
#define SYST_RVR 0xE000E014u
#define SYST_CVR 0xE000E018u

#define RCC_AHB1ENR (RCC_BASE + 0x30u)
#define RCC_APB1ENR (RCC_BASE + 0x40u)
#define GPIOA_MODER (GPIOA_BASE + 0x00u)
#define GPIOA_AFRL  (GPIOA_BASE + 0x20u)
#define USART2_SR   (USART2_BASE + 0x00u)
#define USART2_DR   (USART2_BASE + 0x04u)
#define USART2_BRR  (USART2_BASE + 0x08u)
#define USART2_CR1  (USART2_BASE + 0x0Cu)

static void uart2_putc(char c) {
    while (!(MMIO32(USART2_SR) & (1u << 7u))) { }
    MMIO32(USART2_DR) = (uint32_t)c;
}

int main(void) {
    MMIO32(RCC_AHB1ENR) |= 1u;
    MMIO32(RCC_APB1ENR) |= (1u << 17u);
    MMIO32(GPIOA_MODER) &= ~(3u << 4u);
    MMIO32(GPIOA_MODER) |=  (2u << 4u);     /* PA2 AF */
    MMIO32(GPIOA_AFRL)  &= ~(0xFu << 8u);
    MMIO32(GPIOA_AFRL)  |=  (7u << 8u);     /* AF7 USART2 */
    MMIO32(USART2_BRR) = 0x0683u;           /* exemplo 16MHz/9600 */
    MMIO32(USART2_CR1) = (1u << 13u) | (1u << 3u);
    for (;;) {
        const char *s = "RAFAELIA STM32F401\r\n";
        while (*s) uart2_putc(*s++);
        for (volatile uint32_t d = 0; d < 1000000u; ++d) { }
    }
}
