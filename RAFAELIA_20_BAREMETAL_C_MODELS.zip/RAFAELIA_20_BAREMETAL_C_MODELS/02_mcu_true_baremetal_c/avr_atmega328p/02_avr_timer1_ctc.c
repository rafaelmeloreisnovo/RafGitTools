#include <stdint.h>

/* Modelo 2: Timer1 CTC em ATmega328P.
   OCR1A = F_CPU/(2*prescaler*f)-1. Exemplo: 1kHz com prescaler 8 => 999. */
#define MMIO8(a)  (*(volatile uint8_t *)(uintptr_t)(a))
#define MMIO16(a) (*(volatile uint16_t *)(uintptr_t)(a))
#define TCCR1A 0x80u
#define TCCR1B 0x81u
#define OCR1A  0x88u
#define TIMSK1 0x6Fu

void timer1_ctc_1khz_init(void) {
    MMIO8(TCCR1A) = 0x00u;
    MMIO8(TCCR1B) = (1u << 3u) | (1u << 1u); /* WGM12 + CS11 */
    MMIO16(OCR1A) = 999u;
    MMIO8(TIMSK1) |= (1u << 1u);             /* OCIE1A */
    __asm__ __volatile__("sei");
}

void __attribute__((signal, used)) __vector_11(void) {
    /* Timer1 COMPA vector no avr-gcc para ATmega328P. */
}

int main(void) {
    timer1_ctc_1khz_init();
    for (;;) { __asm__ __volatile__("sleep"); }
}
