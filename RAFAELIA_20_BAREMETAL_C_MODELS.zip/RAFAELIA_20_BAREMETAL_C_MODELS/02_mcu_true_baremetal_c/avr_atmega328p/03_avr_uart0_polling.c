#include <stdint.h>

/* Modelo 3: USART0 polling, 9600 baud @ 16 MHz. */
#define MMIO8(a) (*(volatile uint8_t *)(uintptr_t)(a))
#define UDR0   0xC6u
#define UCSR0A 0xC0u
#define UCSR0B 0xC1u
#define UCSR0C 0xC2u
#define UBRR0L 0xC4u
#define UBRR0H 0xC5u

static void uart0_init_9600(void) {
    MMIO8(UBRR0H) = 0u;
    MMIO8(UBRR0L) = 103u;
    MMIO8(UCSR0C) = (1u << 1u) | (1u << 0u); /* 8N1 */
    MMIO8(UCSR0B) = (1u << 4u) | (1u << 3u); /* RXEN0 + TXEN0 */
}

static void uart0_putc(uint8_t c) {
    while (!(MMIO8(UCSR0A) & (1u << 5u))) { }
    MMIO8(UDR0) = c;
}

int main(void) {
    uart0_init_9600();
    const char msg[] = "RAFAELIA AVR UART\r\n";
    for (;;) {
        for (uint8_t i = 0; msg[i]; ++i) uart0_putc((uint8_t)msg[i]);
        for (volatile uint32_t d = 0; d < 200000u; ++d) { }
    }
}
