#include <stdint.h>

/* Modelo 4: ADC free-running no ATmega328P, canal A0, AVCC ref. */
#define MMIO8(a) (*(volatile uint8_t *)(uintptr_t)(a))
#define ADMUX  0x7Cu
#define ADCSRA 0x7Au
#define ADCL   0x78u
#define ADCH   0x79u
#define DIDR0  0x7Eu

static void adc0_freerun_init(void) {
    MMIO8(DIDR0) = 0x3Fu;
    MMIO8(ADMUX) = (1u << 6u); /* AVCC, ADC0 */
    MMIO8(ADCSRA) = (1u << 7u) | (1u << 6u) | (1u << 5u) | 7u;
}

static uint16_t adc_read_last(void) {
    uint8_t lo = MMIO8(ADCL);
    uint8_t hi = MMIO8(ADCH);
    return (uint16_t)lo | ((uint16_t)hi << 8u);
}

int main(void) {
    adc0_freerun_init();
    volatile uint16_t last = 0;
    for (;;) last = adc_read_last();
}
