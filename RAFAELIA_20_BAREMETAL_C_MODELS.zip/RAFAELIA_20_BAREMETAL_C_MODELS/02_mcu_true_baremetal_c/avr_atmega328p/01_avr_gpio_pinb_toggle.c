#include <stdint.h>

/* Modelo 1: ATmega328P GPIO direto.
   PB5 = D13 no Arduino Uno/Nano. Escrever 1 em PINB alterna PORTB. */
#define DDRB_ADDR  0x24u
#define PINB_ADDR  0x23u
#define MMIO8(a) (*(volatile uint8_t *)(uintptr_t)(a))

int main(void) {
    MMIO8(DDRB_ADDR) |= (uint8_t)(1u << 5u);
    for (;;) {
        MMIO8(PINB_ADDR) = (uint8_t)(1u << 5u);
        for (volatile uint16_t d = 0; d < 30000u; ++d) { }
    }
}
