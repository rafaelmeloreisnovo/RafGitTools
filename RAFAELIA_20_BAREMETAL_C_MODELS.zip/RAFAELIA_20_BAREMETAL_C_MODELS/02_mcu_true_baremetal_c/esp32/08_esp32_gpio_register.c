#include <stdint.h>

/* Modelo 8: ESP32 GPIO register-level skeleton.
   Observação: ESP32 real exige boot/ROM/clock/cache inicializados pelo ambiente.
   Este arquivo demonstra o hot path GPIO por registrador. */
#define MMIO32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define GPIO_OUT_REG       0x3FF44004u
#define GPIO_ENABLE_REG    0x3FF44020u
#define GPIO_OUT_W1TS_REG  0x3FF44008u
#define GPIO_OUT_W1TC_REG  0x3FF4400Cu
#define GPIO_NUM 2u

void app_main(void) {
    MMIO32(GPIO_ENABLE_REG) |= (1u << GPIO_NUM);
    for (;;) {
        MMIO32(GPIO_OUT_W1TS_REG) = (1u << GPIO_NUM);
        for (volatile uint32_t d = 0; d < 100000u; ++d) { }
        MMIO32(GPIO_OUT_W1TC_REG) = (1u << GPIO_NUM);
        for (volatile uint32_t d = 0; d < 100000u; ++d) { }
    }
}
