#include <stdint.h>

/* Modelo 6: STM32F103 GPIOC13 + TIM2 skeleton. */
#define MMIO32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define RCC_BASE   0x40021000u
#define GPIOC_BASE 0x40011000u
#define TIM2_BASE  0x40000000u
#define RCC_APB2ENR (RCC_BASE + 0x18u)
#define RCC_APB1ENR (RCC_BASE + 0x1Cu)
#define GPIOC_CRH   (GPIOC_BASE + 0x04u)
#define GPIOC_ODR   (GPIOC_BASE + 0x0Cu)
#define TIM2_CR1    (TIM2_BASE + 0x00u)
#define TIM2_SR     (TIM2_BASE + 0x10u)
#define TIM2_PSC    (TIM2_BASE + 0x28u)
#define TIM2_ARR    (TIM2_BASE + 0x2Cu)

int main(void) {
    MMIO32(RCC_APB2ENR) |= (1u << 4u); /* IOPCEN */
    MMIO32(RCC_APB1ENR) |= (1u << 0u); /* TIM2EN */
    MMIO32(GPIOC_CRH) &= ~(0xFu << 20u);
    MMIO32(GPIOC_CRH) |=  (0x2u << 20u); /* PC13 output 2MHz push-pull */
    MMIO32(TIM2_PSC) = 7200u - 1u;
    MMIO32(TIM2_ARR) = 10000u - 1u;
    MMIO32(TIM2_CR1) = 1u;
    for (;;) {
        if (MMIO32(TIM2_SR) & 1u) {
            MMIO32(TIM2_SR) &= ~1u;
            MMIO32(GPIOC_ODR) ^= (1u << 13u);
        }
    }
}
