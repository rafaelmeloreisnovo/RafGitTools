#include <stdint.h>

/* Modelo 9: SAMD21 GPIO skeleton.
   PA17 LED em algumas placas; ajuste conforme board. */
#define MMIO32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define PORT_BASE 0x41004400u
#define PORT_DIRSET0 (PORT_BASE + 0x08u)
#define PORT_OUTTGL0 (PORT_BASE + 0x1Cu)
#define PA17 17u

int main(void) {
    MMIO32(PORT_DIRSET0) = (1u << PA17);
    for (;;) {
        MMIO32(PORT_OUTTGL0) = (1u << PA17);
        for (volatile uint32_t d = 0; d < 200000u; ++d) { }
    }
}
