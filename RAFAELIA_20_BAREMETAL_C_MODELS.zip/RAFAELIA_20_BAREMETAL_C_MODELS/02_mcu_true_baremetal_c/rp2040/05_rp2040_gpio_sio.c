#include <stdint.h>

/* Modelo 5: RP2040 GPIO por registrador.
   Skeleton sem Pico SDK: usa SIO e IO_BANK0. */
#define MMIO32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define IO_BANK0_BASE 0x40014000u
#define SIO_BASE      0xD0000000u
#define GPIO25_CTRL   (IO_BANK0_BASE + 0x0CCu)
#define SIO_GPIO_OE_SET  (SIO_BASE + 0x024u)
#define SIO_GPIO_OUT_XOR (SIO_BASE + 0x01Cu)
#define FUNCSEL_SIO 5u

int main(void) {
    MMIO32(GPIO25_CTRL) = FUNCSEL_SIO;
    MMIO32(SIO_GPIO_OE_SET) = (1u << 25u);
    for (;;) {
        MMIO32(SIO_GPIO_OUT_XOR) = (1u << 25u);
        for (volatile uint32_t d = 0; d < 100000u; ++d) { }
    }
}
