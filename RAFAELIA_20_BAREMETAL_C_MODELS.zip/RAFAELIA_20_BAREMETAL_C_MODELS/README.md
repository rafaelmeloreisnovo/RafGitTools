# RAFAELIA 20 BAREMETAL C MODELS

Pacote pedido: opções 1 e 2 juntas, em C.

## Estrutura

- `01_android_arm32_arm64_ndk_c_lowlevel/`: 10 modelos C para Android NDK ARM32/ARM64 em estilo baixo nível.
- `02_mcu_true_baremetal_c/`: 10 modelos C para MCU/SoC com acesso direto a registradores.

## Nota técnica importante

Android NDK não é bare-metal estrito, porque roda sobre kernel Linux/Android, Bionic, SELinux e permissões do sistema. Neste pacote, a pasta Android usa estilo low-level C: JNI fino, syscalls, ciclo/contador, NEON, ring buffer, afinidade e mmap quando permitido.

Bare-metal real está na pasta MCU/SoC, com registradores, startup/linker e sem runtime pesado.

## Objetivo

Transformar a linha RAFAELIA em material testável:

1. Código C separado por alvo.
2. Sem dependência ornamental.
3. Comentários técnicos objetivos.
4. Caminho claro para Codex/GitHub Actions/Termux/NDK.
5. Hipótese separada de validação real.

## Validação inicial

Use:

- `scripts/list_models.sh` para listar os modelos.
- `scripts/sha256_refresh.sh` para recalcular hashes.
- `01_android_arm32_arm64_ndk_c_lowlevel/scripts/build_android.sh` em ambiente com Android NDK.

