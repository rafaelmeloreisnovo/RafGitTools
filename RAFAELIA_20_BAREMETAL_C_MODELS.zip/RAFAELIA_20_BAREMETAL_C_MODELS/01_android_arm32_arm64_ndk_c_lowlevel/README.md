# 01 — Android ARM32/ARM64 NDK C low-level

10 modelos C para Android NDK.

## Limite honesto

Isto não é bare-metal real. Android roda sobre kernel Linux. O objetivo aqui é C baixo nível: mínimo JNI, zero malloc em hot path, leitura de ciclo quando disponível, NEON, CRC, ring buffer, afinidade e mmap quando a política do sistema permitir.

## Modelos

1. `01_raw_syscall_write.c` — escrita por syscall/Bionic mínimo.
2. `02_cycle_counter_arm64.c` — contador virtual ARM64.
3. `03_arm32_timer_fallback.c` — fallback portátil para ARM32.
4. `04_neon_u8_threshold.c` — pipeline NEON para sensores/bytes.
5. `05_crc32_armv8.c` — CRC32 via instruções ARMv8 quando disponível.
6. `06_zero_copy_ring.c` — ring buffer sem malloc.
7. `07_thread_affinity_latency.c` — afinidade e medição de latência.
8. `08_jni_bridge_minimal.c` — bridge JNI fino.
9. `09_mmap_device_window.c` — mmap de device/window quando permitido.
10. `10_build_probe.c` — probe de ABI, endian, ponteiro e features.

## Build

Edite `scripts/build_android.sh` apontando `ANDROID_NDK_HOME` ou exporte a variável.

