#define _POSIX_C_SOURCE 200809L
#include "rafa_android_lowlevel.h"
#include <stdint.h>
#include <time.h>

/* Modelo 3: fallback ARM32/qualquer ABI.
   ARM32 não tem um contador universalmente liberado para EL0/userspace.
   Esse fallback mede tempo monotônico em ns sem depender de Java. */
uint64_t rafa_time_now_ns_fallback(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return ((uint64_t)ts.tv_sec * 1000000000ull) + (uint64_t)ts.tv_nsec;
}
