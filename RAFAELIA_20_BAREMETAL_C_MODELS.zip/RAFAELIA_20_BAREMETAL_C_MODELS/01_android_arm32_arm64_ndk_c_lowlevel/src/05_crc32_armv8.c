#include "rafa_android_lowlevel.h"
#include <stdint.h>

/* Modelo 5: CRC32 usando instruções ARMv8 quando o compilador/alvo suporta.
   Compile arm64 com -march=armv8-a+crc quando quiser ativar o caminho rápido. */
uint32_t rafa_crc32_armv8(const uint8_t *p, uint32_t n, uint32_t seed) {
    if (!p) return seed;
    uint32_t c = seed;
#if defined(__aarch64__) && defined(__ARM_FEATURE_CRC32)
    uint32_t i = 0;
    for (; i + 8 <= n; i += 8) {
        uint64_t v;
        __builtin_memcpy(&v, p + i, sizeof(v));
        c = __builtin_aarch64_crc32x(c, v);
    }
    for (; i < n; ++i) c = __builtin_aarch64_crc32b(c, p[i]);
#else
    for (uint32_t i = 0; i < n; ++i) {
        c ^= p[i];
        for (uint32_t b = 0; b < 8; ++b)
            c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u)));
    }
#endif
    return c;
}
