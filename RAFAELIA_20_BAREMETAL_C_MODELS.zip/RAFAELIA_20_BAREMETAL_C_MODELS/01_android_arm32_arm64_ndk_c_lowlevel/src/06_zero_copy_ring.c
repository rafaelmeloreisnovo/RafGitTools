#include "rafa_android_lowlevel.h"
#include <stdint.h>

/* Modelo 6: ring buffer estático, sem malloc.
   Capacidade potência de 2 para mask barata. */
#define RAFA_RING_CAP 4096u
static uint8_t g_ring[RAFA_RING_CAP];
static volatile uint32_t g_head = 0;
static volatile uint32_t g_tail = 0;

static uint32_t used(void) { return (g_head - g_tail) & (RAFA_RING_CAP - 1u); }
static uint32_t free_space(void) { return (RAFA_RING_CAP - 1u) - used(); }

int rafa_ring_push_bytes(const uint8_t *src, uint32_t n) {
    if (!src) return -1;
    if (n > free_space()) return -2;
    for (uint32_t i = 0; i < n; ++i) {
        g_ring[g_head & (RAFA_RING_CAP - 1u)] = src[i];
        g_head = (g_head + 1u) & (RAFA_RING_CAP - 1u);
    }
    return 0;
}

int rafa_ring_pop_bytes(uint8_t *dst, uint32_t n) {
    if (!dst) return -1;
    if (n > used()) return -2;
    for (uint32_t i = 0; i < n; ++i) {
        dst[i] = g_ring[g_tail & (RAFA_RING_CAP - 1u)];
        g_tail = (g_tail + 1u) & (RAFA_RING_CAP - 1u);
    }
    return 0;
}
