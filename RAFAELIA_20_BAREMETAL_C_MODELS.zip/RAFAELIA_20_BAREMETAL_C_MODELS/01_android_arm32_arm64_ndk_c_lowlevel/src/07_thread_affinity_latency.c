#define _GNU_SOURCE
#include "rafa_android_lowlevel.h"
#include <stdint.h>
#include <sched.h>
#include <unistd.h>

/* Modelo 7: fixar thread no CPU0.
   Nem todo Android permite tudo dependendo de sandbox/política. */
int rafa_pin_to_cpu0(void) {
#if defined(__linux__)
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(0, &set);
    return sched_setaffinity(0, sizeof(set), &set);
#else
    return -1;
#endif
}
