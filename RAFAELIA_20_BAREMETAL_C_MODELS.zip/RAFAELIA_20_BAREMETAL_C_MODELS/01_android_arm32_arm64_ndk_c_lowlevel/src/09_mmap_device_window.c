#include "rafa_android_lowlevel.h"
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

/* Modelo 9: mmap de janela de device quando permitido.
   Em Android comum, /dev/mem ou devices físicos são bloqueados.
   Útil para ambiente próprio, rooted, vendor, embedded ou laboratório. */
int rafa_mmap_window(const char *path, uint64_t offset, uint32_t length, volatile uint8_t **out) {
    if (!path || !out || length == 0) return -1;
    int fd = open(path, O_RDWR | O_SYNC);
    if (fd < 0) return -2;
    void *p = mmap(0, (size_t)length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, (off_t)offset);
    close(fd);
    if (p == MAP_FAILED) return -3;
    *out = (volatile uint8_t *)p;
    return 0;
}
