#include "rafa_android_lowlevel.h"
#include <unistd.h>
#include <stdint.h>

/* Modelo 1: escrita mínima em stdout.
   Em Android, syscall direta muda por ABI e política; usar write() ainda é
   o caminho baixo nível estável via Bionic. Hot path sem alocação. */
int rafa_raw_write_stdout(const char *s, uint32_t n) {
    if (!s) return -1;
    uint32_t off = 0;
    while (off < n) {
        ssize_t r = write(1, s + off, (size_t)(n - off));
        if (r <= 0) return -2;
        off += (uint32_t)r;
    }
    return 0;
}
