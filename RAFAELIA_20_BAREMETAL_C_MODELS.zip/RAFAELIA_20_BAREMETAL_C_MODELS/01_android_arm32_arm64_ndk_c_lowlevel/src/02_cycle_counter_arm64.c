#include "rafa_android_lowlevel.h"
#include <stdint.h>
#include <time.h>

/* Modelo 2: contador ARM64.
   cntvct_el0 costuma ser acessível em userspace em muitos kernels Android.
   Quando não for ARM64, cai para clock_gettime. */
uint64_t rafa_cycle_now(void) {
#if defined(__aarch64__)
    uint64_t v;
    __asm__ __volatile__("mrs %0, cntvct_el0" : "=r"(v) :: "memory");
    return v;
#else
    return rafa_time_now_ns_fallback();
#endif
}
