#include "rafa_android_lowlevel.h"
#include <stdint.h>

/* Modelo 8: JNI mínimo.
   Mantido sem dependência obrigatória de jni.h para permitir análise/syntax check
   fora do NDK. No NDK real, defina RAFA_WITH_JNI e inclua jni.h. */
#ifdef RAFA_WITH_JNI
#include <jni.h>
JNIEXPORT jlong JNICALL
Java_com_rafaelia_lowlevel_RafaNative_cycleNow(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    return (jlong)rafa_cycle_now();
}
#endif

int rafa_jni_bridge_placeholder(void) {
    return 0;
}
