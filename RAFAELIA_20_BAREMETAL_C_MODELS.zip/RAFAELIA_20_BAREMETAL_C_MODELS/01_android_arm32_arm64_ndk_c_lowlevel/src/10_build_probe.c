#include "rafa_android_lowlevel.h"

/* Modelo 10: string de inspeção de build/ABI. */
const char *rafa_build_probe(void) {
#if defined(__aarch64__)
    return "RAFAELIA_ANDROID: ABI=arm64-v8a ARCH=aarch64 PTR=64";
#elif defined(__arm__)
    return "RAFAELIA_ANDROID: ABI=armeabi-v7a ARCH=arm32 PTR=32";
#elif defined(__x86_64__)
    return "RAFAELIA_ANDROID: ABI=x86_64 ARCH=x86_64 PTR=64";
#else
    return "RAFAELIA_ANDROID: ABI=unknown";
#endif
}
