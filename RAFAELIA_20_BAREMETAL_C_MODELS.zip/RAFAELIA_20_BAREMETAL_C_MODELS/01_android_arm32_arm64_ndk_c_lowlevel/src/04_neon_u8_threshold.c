#include "rafa_android_lowlevel.h"
#include <stdint.h>

#if defined(__ARM_NEON) || defined(__ARM_NEON__)
#include <arm_neon.h>
#endif

/* Modelo 4: threshold vetorial.
   Entrada: bytes de sensor/imagem.
   Saída: 0xFF quando in[i] > threshold, senão 0x00. */
void rafa_neon_u8_threshold(const uint8_t *in, uint8_t *out, uint32_t n, uint8_t threshold) {
    if (!in || !out) return;
    uint32_t i = 0;
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
    uint8x16_t th = vdupq_n_u8(threshold);
    for (; i + 16 <= n; i += 16) {
        uint8x16_t x = vld1q_u8(in + i);
        uint8x16_t y = vcgtq_u8(x, th);
        vst1q_u8(out + i, y);
    }
#endif
    for (; i < n; ++i) out[i] = (in[i] > threshold) ? 0xFFu : 0u;
}
