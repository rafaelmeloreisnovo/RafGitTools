#ifndef RAFA_ANDROID_LOWLEVEL_H
#define RAFA_ANDROID_LOWLEVEL_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int rafa_raw_write_stdout(const char *s, uint32_t n);
uint64_t rafa_cycle_now(void);
uint64_t rafa_time_now_ns_fallback(void);
void rafa_neon_u8_threshold(const uint8_t *in, uint8_t *out, uint32_t n, uint8_t threshold);
uint32_t rafa_crc32_armv8(const uint8_t *p, uint32_t n, uint32_t seed);
int rafa_ring_push_bytes(const uint8_t *src, uint32_t n);
int rafa_ring_pop_bytes(uint8_t *dst, uint32_t n);
int rafa_pin_to_cpu0(void);
int rafa_mmap_window(const char *path, uint64_t offset, uint32_t length, volatile uint8_t **out);
const char *rafa_build_probe(void);

#ifdef __cplusplus
}
#endif

#endif
