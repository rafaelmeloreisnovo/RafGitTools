#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_NDK_HOME:?export ANDROID_NDK_HOME=/path/to/android-ndk}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for ABI in arm64-v8a armeabi-v7a; do
  cmake -S "$ROOT" -B "$ROOT/build-$ABI" \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$ABI" \
    -DANDROID_PLATFORM=android-23 \
    -DCMAKE_BUILD_TYPE=Release
  cmake --build "$ROOT/build-$ABI" --config Release -j"$(nproc 2>/dev/null || echo 2)"
done
