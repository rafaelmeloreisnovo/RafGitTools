#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
find . -type f ! -name SHA256SUMS.txt ! -path './.git/*' -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.txt
cat SHA256SUMS.txt
