#!/usr/bin/env bash
set -euo pipefail
find . -type f \( -name '*.c' -o -name '*.h' -o -name '*.ld' -o -name 'CMakeLists.txt' -o -name 'Makefile*' \) | sort
