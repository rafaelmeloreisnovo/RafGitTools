# Validation Matrix

| Grupo | Alvo | Tipo | Validação necessária |
|---|---|---|---|
| Android | arm64-v8a | NDK C low-level | Compilar com NDK, rodar em aparelho, medir latência |
| Android | armeabi-v7a | NDK C low-level | Compilar com NDK, rodar em aparelho 32-bit quando possível |
| AVR | ATmega328P | bare-metal real | `avr-gcc`, flash via avrdude, medir GPIO |
| RP2040 | Cortex-M0+ | bare-metal real | toolchain ARM, linker real, medir GPIO25 |
| STM32 | F103/F401 | bare-metal real | toolchain ARM, board específica, UART/GPIO |
| ESP32 | Xtensa | register-level | ajustar boot/clock via ESP-IDF ou startup próprio |
| SAMD21 | Cortex-M0+ | bare-metal real | linker/startup do chip, board pinout |

## Critério de aceitação

1. Compila sem warning crítico.
2. Binário gerado tem tamanho registrado.
3. Hash SHA256 registrado.
4. Teste em hardware gera evidência: log, foto do osciloscópio ou serial output.
5. Técnica marcada como validada somente depois da evidência.
