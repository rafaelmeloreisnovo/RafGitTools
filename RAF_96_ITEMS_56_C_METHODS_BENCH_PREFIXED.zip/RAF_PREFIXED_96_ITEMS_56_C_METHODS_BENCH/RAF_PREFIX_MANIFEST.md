# RAF Prefix Manifest

Esta versão usa prefixo `RAF_` em todos os arquivos do pacote.

## Regras aplicadas

- Diretórios foram preservados.
- Todo arquivo recebeu prefixo `RAF_`.
- Includes C foram ajustados para `../include/RAF_rafaelia_common.h`.
- O pacote continua com 56 métodos `.c`, documentação, benchmark, scripts e prompt Codex.

## Observação

Android/Termux/Linux/Raspberry continuam sendo low-level userspace.
Bare-metal real fica para MCU/Cortex-M/AVR/RP2040/STM32/ESP32/SAMD21.

