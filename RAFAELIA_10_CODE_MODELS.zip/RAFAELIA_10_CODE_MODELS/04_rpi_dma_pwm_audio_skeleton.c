/*
 * 04_rpi_dma_pwm_audio_skeleton.c
 * RAFAELIA model: skeleton DMA -> PWM FIFO para audio/PWM streaming.
 * Observacao: este arquivo define estrutura e validacao de control blocks.
 * A ativacao real de DMA depende de enderecos bus-specific e permissao kernel.
 * Build:
 *   gcc -O2 -Wall -Wextra 04_rpi_dma_pwm_audio_skeleton.c -o dma_pwm_skel
 */

#include <stdint.h>
#include <stdio.h>
#include <stdalign.h>
#include <string.h>

#define RAF_DMA_TI_INTEN        (1u << 0)
#define RAF_DMA_TI_WAIT_RESP    (1u << 2)
#define RAF_DMA_TI_DEST_DREQ    (1u << 6)
#define RAF_DMA_TI_SRC_INC      (1u << 8)
#define RAF_DMA_PERMAP_PWM      (5u << 16)

#define RAF_PWM_FIFO_BUS_ADDR_EXAMPLE 0x7e20c018u /* exemplo BCM bus addr, validar por SoC */
#define RAF_AUDIO_WORDS 1024u

struct raf_dma_cb {
    uint32_t ti;
    uint32_t source_ad;
    uint32_t dest_ad;
    uint32_t txfr_len;
    uint32_t stride;
    uint32_t nextconbk;
    uint32_t reserved0;
    uint32_t reserved1;
};

typedef struct raf_dma_cb raf_dma_cb_t;

static alignas(32) raf_dma_cb_t g_cb;
static alignas(32) uint32_t g_audio_words[RAF_AUDIO_WORDS];

static void raf_make_test_wave(void) {
    uint32_t lfsr = 0xACE1u;
    for (unsigned i = 0; i < RAF_AUDIO_WORDS; ++i) {
        lfsr = (lfsr >> 1u) ^ (uint32_t)(-(int32_t)(lfsr & 1u) & 0xB400u);
        g_audio_words[i] = lfsr; /* 1-bit/sigma-delta placeholder */
    }
}

static void raf_dma_pwm_prepare(uint32_t src_bus_addr, uint32_t pwm_fifo_bus_addr, uint32_t next_cb_bus_addr) {
    memset(&g_cb, 0, sizeof(g_cb));
    g_cb.ti = RAF_DMA_TI_WAIT_RESP | RAF_DMA_TI_DEST_DREQ | RAF_DMA_TI_SRC_INC | RAF_DMA_PERMAP_PWM;
    g_cb.source_ad = src_bus_addr;
    g_cb.dest_ad = pwm_fifo_bus_addr;
    g_cb.txfr_len = RAF_AUDIO_WORDS * sizeof(uint32_t);
    g_cb.nextconbk = next_cb_bus_addr; /* circular quando aponta para ele mesmo */
}

int main(void) {
    raf_make_test_wave();
    raf_dma_pwm_prepare(0x00000000u, RAF_PWM_FIFO_BUS_ADDR_EXAMPLE, 0x00000000u);
    printf("DMA CB size=%zu align=32 ti=0x%08x len=%u dest=0x%08x\n",
           sizeof(g_cb), g_cb.ti, g_cb.txfr_len, g_cb.dest_ad);
    puts("Skeleton pronto. Antes de ativar DMA real, mapear bus address correto por SoC.");
    return 0;
}
