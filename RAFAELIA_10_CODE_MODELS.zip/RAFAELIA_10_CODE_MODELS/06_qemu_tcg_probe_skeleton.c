/*
 * 06_qemu_tcg_probe_skeleton.c
 * RAFAELIA model: probe isolado para medir custo de dispatch/traducao.
 * Uso: compilar fora do QEMU como microbenchmark ou portar hooks para TCG.
 * Build:
 *   gcc -O3 -Wall -Wextra 06_qemu_tcg_probe_skeleton.c -o tcg_probe
 */

#include <stdint.h>
#include <stdio.h>
#include <time.h>

struct raf_tcg_probe {
    uint64_t translated_blocks;
    uint64_t executed_blocks;
    uint64_t redundant_loads;
    uint64_t direct_neon_candidates;
};

static inline uint64_t raf_now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static uint64_t raf_dispatch_loop(uint64_t n, struct raf_tcg_probe *p) {
    uint64_t acc = 0x12345678u;
    for (uint64_t i = 0; i < n; ++i) {
        acc ^= (i + acc) << 7u;
        acc += (acc >> 3u) ^ 0x9E3779B97F4A7C15ull;
        p->executed_blocks++;
        p->redundant_loads += ((acc & 15u) == 0u);
        p->direct_neon_candidates += ((acc & 255u) == 42u);
    }
    return acc;
}

int main(void) {
    struct raf_tcg_probe p = {0};
    const uint64_t n = 10000000ull;
    uint64_t t0 = raf_now_ns();
    uint64_t acc = raf_dispatch_loop(n, &p);
    uint64_t t1 = raf_now_ns();
    double ns_per_block = (double)(t1 - t0) / (double)n;
    printf("acc=0x%llx blocks=%llu ns_per_block=%.2f redundant=%llu neon_candidates=%llu\n",
           (unsigned long long)acc,
           (unsigned long long)p.executed_blocks,
           ns_per_block,
           (unsigned long long)p.redundant_loads,
           (unsigned long long)p.direct_neon_candidates);
    return 0;
}
