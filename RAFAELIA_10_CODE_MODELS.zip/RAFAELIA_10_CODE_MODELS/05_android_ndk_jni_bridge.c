/*
 * 05_android_ndk_jni_bridge.c
 * RAFAELIA model: JNI fino para Android NDK.
 * Target: arm64-v8a / armeabi-v7a.
 * CMakeLists exemplo:
 *   add_library(rafaelia_native SHARED 05_android_ndk_jni_bridge.c)
 *   find_library(log-lib log)
 *   target_link_libraries(rafaelia_native ${log-lib})
 */

#include <jni.h>
#include <stdint.h>
#include <stddef.h>
#if defined(__ANDROID__)
#include <android/log.h>
#define RAF_LOGI(...) __android_log_print(ANDROID_LOG_INFO, "RAFAELIA", __VA_ARGS__)
#else
#define RAF_LOGI(...) ((void)0)
#endif

static uint32_t raf_crc32_step(uint32_t crc, uint8_t b) {
    crc ^= b;
    for (unsigned i = 0; i < 8; ++i) {
        crc = (crc >> 1u) ^ (0xEDB88320u & (uint32_t)-(int32_t)(crc & 1u));
    }
    return crc;
}

JNIEXPORT jint JNICALL
Java_com_rafcodephi_nativebridge_RafaeliaNative_crc32Bytes(JNIEnv *env, jclass clazz, jbyteArray data) {
    (void)clazz;
    if (!data) return 0;
    jsize n = (*env)->GetArrayLength(env, data);
    jbyte *p = (*env)->GetByteArrayElements(env, data, NULL);
    if (!p) return 0;
    uint32_t crc = 0xFFFFFFFFu;
    for (jsize i = 0; i < n; ++i) crc = raf_crc32_step(crc, (uint8_t)p[i]);
    (*env)->ReleaseByteArrayElements(env, data, p, JNI_ABORT);
    RAF_LOGI("crc32Bytes n=%d", (int)n);
    return (jint)(crc ^ 0xFFFFFFFFu);
}

JNIEXPORT jlong JNICALL
Java_com_rafcodephi_nativebridge_RafaeliaNative_cycleCounter(JNIEnv *env, jclass clazz) {
    (void)env; (void)clazz;
#if defined(__aarch64__)
    uint64_t v;
    __asm__ __volatile__("mrs %0, cntvct_el0" : "=r"(v));
    return (jlong)v;
#else
    return 0;
#endif
}
