#!/usr/bin/env python3
"""
08_register_map_validator.py
RAFAELIA model: validador simples de mapa de registradores.
Uso:
  python3 08_register_map_validator.py
"""

from dataclasses import dataclass
from typing import Dict, List

@dataclass(frozen=True)
class Reg:
    name: str
    addr: int
    width: int
    notes: str = ""

ATMEGA328P: Dict[str, Reg] = {
    "PINB": Reg("PINB", 0x23, 8, "input/toggle"),
    "DDRB": Reg("DDRB", 0x24, 8, "direction"),
    "PORTB": Reg("PORTB", 0x25, 8, "output/pullup"),
    "TCCR1A": Reg("TCCR1A", 0x80, 8),
    "TCCR1B": Reg("TCCR1B", 0x81, 8),
    "OCR1A": Reg("OCR1A", 0x88, 16),
    "TIMSK1": Reg("TIMSK1", 0x6F, 8),
    "UCSR0A": Reg("UCSR0A", 0xC0, 8),
    "UDR0": Reg("UDR0", 0xC6, 8),
}

BCM2711_OFFSETS: Dict[str, Reg] = {
    "GPIO": Reg("GPIO", 0x00200000, 32),
    "PWM": Reg("PWM", 0x0020C000, 32),
    "SPI0": Reg("SPI0", 0x00204000, 32),
    "TIMER": Reg("TIMER", 0x00003000, 32),
}

def validate_unique(regs: Dict[str, Reg]) -> List[str]:
    errors: List[str] = []
    seen = {}
    for r in regs.values():
        if r.addr in seen:
            errors.append(f"DUPLICADO addr=0x{r.addr:x}: {seen[r.addr]} e {r.name}")
        seen[r.addr] = r.name
        if r.width not in (8, 16, 32, 64):
            errors.append(f"WIDTH invalido {r.name}: {r.width}")
    return errors

def emit_c_header(regs: Dict[str, Reg], prefix: str) -> str:
    lines = ["/* gerado por 08_register_map_validator.py */"]
    for key in sorted(regs):
        r = regs[key]
        lines.append(f"#define {prefix}_{r.name}_ADDR 0x{r.addr:X}u /* {r.width}-bit {r.notes} */")
    return "\n".join(lines) + "\n"

if __name__ == "__main__":
    errors = validate_unique(ATMEGA328P) + validate_unique(BCM2711_OFFSETS)
    if errors:
        print("ERROS:")
        for e in errors:
            print(" -", e)
        raise SystemExit(1)
    print("OK: mapas basicos validos")
    print(emit_c_header(ATMEGA328P, "RAF_AVR"))
