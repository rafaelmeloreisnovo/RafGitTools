/*
 * 09_tiny_bnn_inference.c
 * RAFAELIA model: BNN tiny com XNOR + popcount.
 * Target: MCU/ARM/Linux. Sem malloc, sem float.
 * Build:
 *   gcc -O3 -Wall -Wextra 09_tiny_bnn_inference.c -o tiny_bnn
 */

#include <stdint.h>
#include <stdio.h>

#define RAF_INPUT_BITS 64u
#define RAF_HIDDEN     8u
#define RAF_CLASSES    4u

static const uint64_t W1[RAF_HIDDEN] = {
    0xFFFF0000FFFF0000ull, 0xAAAAAAAAAAAAAAAAull, 0xCCCCCCCCCCCCCCCCull, 0xF0F0F0F0F0F0F0F0ull,
    0x0F0F0F0F0F0F0F0Full, 0x3333333333333333ull, 0x5555555555555555ull, 0x00FF00FF00FF00FFull
};

static const uint16_t W2[RAF_CLASSES] = {
    0b11110000u, 0b11001100u, 0b10101010u, 0b01100110u
};

static inline unsigned pop64(uint64_t x) {
#if defined(__GNUC__) || defined(__clang__)
    return (unsigned)__builtin_popcountll(x);
#else
    unsigned c = 0;
    while (x) { x &= x - 1u; c++; }
    return c;
#endif
}

static uint8_t raf_bnn_infer(uint64_t input_bits) {
    uint8_t hidden = 0;
    for (unsigned h = 0; h < RAF_HIDDEN; ++h) {
        unsigned same = pop64(~(input_bits ^ W1[h]));
        if (same >= (RAF_INPUT_BITS / 2u)) hidden |= (uint8_t)(1u << h);
    }

    int best_score = -9999;
    uint8_t best = 0;
    for (unsigned c = 0; c < RAF_CLASSES; ++c) {
        uint8_t w = (uint8_t)W2[c];
        unsigned same = (unsigned)__builtin_popcount((unsigned)(~(hidden ^ w) & 0xFFu));
        int score = (int)same - (int)(RAF_HIDDEN - same);
        if (score > best_score) {
            best_score = score;
            best = (uint8_t)c;
        }
    }
    return best;
}

int main(void) {
    uint64_t sensor_state = 0xF0F0AA55CC3300FFull;
    printf("class=%u\n", raf_bnn_infer(sensor_state));
    return 0;
}
