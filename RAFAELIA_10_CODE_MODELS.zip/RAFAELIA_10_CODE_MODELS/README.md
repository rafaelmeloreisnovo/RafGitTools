# RAFAELIA 10 Code Models

Pacote com 10 modelos de codigo derivados da linha bare-metal + Vectras/Termux/QEMU.

## Arquivos principais

1. `01_avr_atmega328p_bare_gpio_timer.c` — AVR GPIO + Timer1 CTC sem Arduino.
2. `02_rpi4_bcm2711_gpio_mmap.c` — Raspberry Pi GPIO via `/dev/gpiomem`.
3. `03_arm64_neon_sensor_pipeline.c` — pipeline de sensores com NEON/fallback.
4. `04_rpi_dma_pwm_audio_skeleton.c` — skeleton DMA -> PWM FIFO.
5. `05_android_ndk_jni_bridge.c` — ponte JNI fina para Android NDK.
6. `06_qemu_tcg_probe_skeleton.c` — probe de custo de dispatch/traducao estilo TCG.
7. `07_termux_orchestrator.sh` — orquestrador leve Termux/Linux.
8. `08_register_map_validator.py` — validador/gerador simples de mapa de registradores.
9. `09_tiny_bnn_inference.c` — inferencia BNN 1-bit sem malloc/float.
10. `10_github_actions_multi_target.yml` — workflow CI multi-target.

## Uso rapido

```bash
bash 07_termux_orchestrator.sh check
bash 07_termux_orchestrator.sh build-host
bash 07_termux_orchestrator.sh bench
python3 08_register_map_validator.py
```

## Observacao tecnica

Alguns modelos sao skeletons de baixo nivel. Antes de acessar MMIO, DMA ou GPIO real, validar o SoC, permissao do kernel, endereco fisico/bus address e datasheet.
