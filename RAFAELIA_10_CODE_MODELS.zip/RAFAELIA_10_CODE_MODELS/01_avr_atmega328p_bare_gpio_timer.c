/*
 * 01_avr_atmega328p_bare_gpio_timer.c
 * RAFAELIA model: ATmega328P GPIO + Timer1 CTC sem Arduino.h
 * Target: Arduino Uno/Nano/Pro Mini ATmega328P @ 16MHz
 * Build:
 *   avr-gcc -mmcu=atmega328p -DF_CPU=16000000UL -Os -ffunction-sections -fdata-sections \
 *     -Wl,--gc-sections 01_avr_atmega328p_bare_gpio_timer.c -o avr_blink.elf
 *   avr-objcopy -O ihex avr_blink.elf avr_blink.hex
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>

#define RAF_BIT(n)            (1u << (n))
#define RAF_REG8(addr)        (*(volatile uint8_t *)(addr))
#define RAF_DDRB_ADDR         0x24u
#define RAF_PINB_ADDR         0x23u
#define RAF_TCCR1A_ADDR       0x80u
#define RAF_TCCR1B_ADDR       0x81u
#define RAF_OCR1A_ADDR        0x88u
#define RAF_TIMSK1_ADDR       0x6Fu

static volatile uint16_t g_ticks;

ISR(TIMER1_COMPA_vect) {
    g_ticks++;
    if ((g_ticks & 0x03FFu) == 0u) {
        RAF_REG8(RAF_PINB_ADDR) = RAF_BIT(5); /* toggle PB5/D13 via PINB */
    }
}

static void raf_timer1_ctc_1khz(void) {
    RAF_REG8(RAF_TCCR1A_ADDR) = 0x00u;
    RAF_REG8(RAF_TCCR1B_ADDR) = RAF_BIT(3) | RAF_BIT(1); /* WGM12 + prescaler 8 */
    *(volatile uint16_t *)RAF_OCR1A_ADDR = 999u;
    RAF_REG8(RAF_TIMSK1_ADDR) |= RAF_BIT(1); /* OCIE1A */
}

int main(void) {
    RAF_REG8(RAF_DDRB_ADDR) |= RAF_BIT(5); /* PB5/D13 output */
    raf_timer1_ctc_1khz();
    sei();

    for (;;) {
        /* loop vazio: timing fica no hardware/ISR */
    }
}
