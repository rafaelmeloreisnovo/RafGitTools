#!/usr/bin/env bash
# 07_termux_orchestrator.sh
# RAFAELIA model: orquestrador leve para Termux/Linux.
# Uso:
#   bash 07_termux_orchestrator.sh check
#   bash 07_termux_orchestrator.sh build-host
#   bash 07_termux_orchestrator.sh bench

set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

need() { command -v "$1" >/dev/null 2>&1 || { echo "FALTA: $1" >&2; exit 1; }; }

case "${1:-check}" in
  check)
    echo "== RAFAELIA CHECK =="
    uname -a || true
    for t in cc gcc clang cmake ninja python3 sha256sum; do
      if command -v "$t" >/dev/null 2>&1; then echo "OK  $t: $(command -v "$t")"; else echo "MISS $t"; fi
    done
    ;;
  build-host)
    need cc
    echo "== BUILD HOST C MODELS =="
    for f in "$ROOT"/*.c; do
      base="$(basename "$f" .c)"
      case "$base" in
        01_avr_*|05_android_*) echo "SKIP target-specific $base" ;;
        *) cc -O2 -Wall -Wextra "$f" -o "$BUILD/$base" && echo "OK $base" ;;
      esac
    done
    ;;
  bench)
    "$0" build-host
    echo "== BENCH =="
    for exe in "$BUILD"/*; do
      [ -x "$exe" ] || continue
      echo "-- $(basename "$exe")"
      "$exe" || true
    done
    ;;
  hash)
    sha256sum "$ROOT"/* > "$BUILD/SHA256SUMS.txt"
    cat "$BUILD/SHA256SUMS.txt"
    ;;
  *)
    echo "Uso: $0 {check|build-host|bench|hash}" >&2
    exit 2
    ;;
esac
