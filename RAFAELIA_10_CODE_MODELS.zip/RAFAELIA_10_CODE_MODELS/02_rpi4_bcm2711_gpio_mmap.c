/*
 * 02_rpi4_bcm2711_gpio_mmap.c
 * RAFAELIA model: Raspberry Pi GPIO por MMIO usando /dev/gpiomem.
 * Target: Raspberry Pi 4/5 Linux userspace.
 * Build:
 *   gcc -O3 -Wall -Wextra 02_rpi4_bcm2711_gpio_mmap.c -o rpi_gpio
 * Run:
 *   sudo ./rpi_gpio 17 1000000
 */

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

#define GPIO_MAP_LEN 0x1000u
#define GPFSEL_INDEX(pin) ((pin) / 10u)
#define GPFSEL_SHIFT(pin) (((pin) % 10u) * 3u)
#define GPSET_INDEX(pin)  (7u + ((pin) / 32u))
#define GPCLR_INDEX(pin)  (10u + ((pin) / 32u))
#define GPIO_MASK(pin)    (1u << ((pin) & 31u))

static inline void mmio_barrier(void) {
#if defined(__aarch64__) || defined(__arm__)
    __asm__ __volatile__("dmb sy" ::: "memory");
#else
    __sync_synchronize();
#endif
}

static volatile uint32_t *map_gpio(void) {
    int fd = open("/dev/gpiomem", O_RDWR | O_SYNC);
    if (fd < 0) {
        perror("open /dev/gpiomem");
        return NULL;
    }
    void *p = mmap(NULL, GPIO_MAP_LEN, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (p == MAP_FAILED) {
        perror("mmap");
        return NULL;
    }
    return (volatile uint32_t *)p;
}

static void gpio_output(volatile uint32_t *gpio, unsigned pin) {
    const unsigned idx = GPFSEL_INDEX(pin);
    const unsigned sh = GPFSEL_SHIFT(pin);
    uint32_t v = gpio[idx];
    v &= ~(7u << sh);
    v |=  (1u << sh); /* output */
    gpio[idx] = v;
    mmio_barrier();
}

int main(int argc, char **argv) {
    unsigned pin = argc > 1 ? (unsigned)strtoul(argv[1], NULL, 0) : 17u;
    unsigned loops = argc > 2 ? (unsigned)strtoul(argv[2], NULL, 0) : 1000000u;
    if (pin > 53u) {
        fprintf(stderr, "GPIO invalido: %u\n", pin);
        return 2;
    }

    volatile uint32_t *gpio = map_gpio();
    if (!gpio) return 1;
    gpio_output(gpio, pin);

    const uint32_t mask = GPIO_MASK(pin);
    const unsigned set_idx = GPSET_INDEX(pin);
    const unsigned clr_idx = GPCLR_INDEX(pin);

    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC_RAW, &a);
    for (unsigned i = 0; i < loops; ++i) {
        gpio[set_idx] = mask;
        gpio[clr_idx] = mask;
    }
    mmio_barrier();
    clock_gettime(CLOCK_MONOTONIC_RAW, &b);

    double sec = (double)(b.tv_sec - a.tv_sec) + (double)(b.tv_nsec - a.tv_nsec) / 1e9;
    printf("pin=%u loops=%u elapsed=%.6f s toggles_per_sec=%.2f\n", pin, loops, sec, (double)loops / sec);
    munmap((void *)gpio, GPIO_MAP_LEN);
    return 0;
}
