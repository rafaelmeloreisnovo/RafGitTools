/*
 * 03_arm64_neon_sensor_pipeline.c
 * RAFAELIA model: pipeline NEON para sensores 8-bit.
 * Target: ARM64 Linux/Android NDK.
 * Build:
 *   clang -O3 -march=armv8-a+simd 03_arm64_neon_sensor_pipeline.c -o neon_sensor
 */

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

#if defined(__aarch64__)
#include <arm_neon.h>
#endif

/* Saida: bitmask compacta. 1 quando sample > threshold. */
size_t raf_threshold_pack_u8(const uint8_t *samples, size_t n, uint8_t threshold, uint64_t *out_masks) {
    size_t out = 0;
#if defined(__aarch64__)
    const uint8x16_t th = vdupq_n_u8(threshold);
    for (size_t i = 0; i + 16 <= n; i += 16) {
        uint8x16_t x = vld1q_u8(samples + i);
        uint8x16_t cmp = vcgtq_u8(x, th);
        uint8_t tmp[16];
        vst1q_u8(tmp, cmp);
        uint64_t mask = 0;
        for (unsigned k = 0; k < 16; ++k) mask |= (uint64_t)(tmp[k] != 0) << k;
        out_masks[out++] = mask;
    }
#else
    for (size_t i = 0; i + 16 <= n; i += 16) {
        uint64_t mask = 0;
        for (unsigned k = 0; k < 16; ++k) mask |= (uint64_t)(samples[i + k] > threshold) << k;
        out_masks[out++] = mask;
    }
#endif
    return out;
}

int main(void) {
    uint8_t samples[32];
    uint64_t masks[2];
    for (unsigned i = 0; i < 32; ++i) samples[i] = (uint8_t)(i * 7u);
    size_t count = raf_threshold_pack_u8(samples, 32, 96, masks);
    for (size_t i = 0; i < count; ++i) printf("mask[%zu]=0x%04llx\n", i, (unsigned long long)masks[i]);
    return 0;
}
