import { useState, useEffect, useRef } from "react";

// ── Plasma colormap (5 stops, interpolação linear) ──────────────────────
const plasma = (t) => {
  t = Math.max(0, Math.min(1, t));
  const stops = [
    [13, 8, 135], [84, 2, 163], [139, 10, 165],
    [185, 50, 137], [219, 92, 104], [244, 136, 73],
    [254, 188, 43], [240, 249, 33]
  ];
  const i = Math.min(Math.floor(t * (stops.length - 1)), stops.length - 2);
  const f = t * (stops.length - 1) - i;
  const a = stops[i], b = stops[i + 1];
  return [
    Math.round(a[0] + f * (b[0] - a[0])),
    Math.round(a[1] + f * (b[1] - a[1])),
    Math.round(a[2] + f * (b[2] - a[2]))
  ];
};

// ── Mandelbrot: retorna iteração de escape ────────────────────────────
const escapeM = (cr, ci, max) => {
  let zr = 0, zi = 0;
  for (let i = 0; i < max; i++) {
    const zr2 = zr * zr, zi2 = zi * zi;
    if (zr2 + zi2 > 4) return i;
    zi = 2 * zr * zi + ci;
    zr = zr2 - zi2 + cr;
  }
  return max;
};

// ── Julia: iteração com z₀ variável ──────────────────────────────────
const escapeJ = (zr, zi, cr, ci, max) => {
  for (let i = 0; i < max; i++) {
    const zr2 = zr * zr, zi2 = zi * zi;
    if (zr2 + zi2 > 4) return i;
    zi = 2 * zr * zi + ci;
    zr = zr2 - zi2 + cr;
  }
  return max;
};

// ── Grafo 42 atratores (SVG, K=5) ────────────────────────────────────
function Graph42({ size = 380 }) {
  const N = 42, K = 5, R = size * 0.42, cx = size / 2, cy = size / 2;
  const nodes = Array.from({ length: N }, (_, k) => ({
    x: cx + R * Math.cos((2 * Math.PI * k) / N - Math.PI / 2),
    y: cy + R * Math.sin((2 * Math.PI * k) / N - Math.PI / 2),
    deg: 0,
  }));

  // Travessia completa: gcd(5,42)=1 → 42 arestas únicas antes de repetir
  const edgeSet = new Set();
  const edges = [];
  let pos = 0;
  for (let iter = 0; iter < 1000 && edges.length < 300; iter++) {
    const next = (pos + K) % N;
    const key = Math.min(pos, next) * 100 + Math.max(pos, next);
    if (!edgeSet.has(key)) {
      edgeSet.add(key);
      edges.push([pos, next]);
      nodes[pos].deg++;
      nodes[next].deg++;
    }
    pos = next;
  }

  const maxDeg = Math.max(...nodes.map((n) => n.deg)) || 1;

  return (
    <svg
      width={size}
      height={size}
      style={{ background: "linear-gradient(160deg,#02020f 0%,#060618 100%)" }}
    >
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      {/* Arestas */}
      {edges.map(([a, b], i) => (
        <line
          key={i}
          x1={nodes[a].x} y1={nodes[a].y}
          x2={nodes[b].x} y2={nodes[b].y}
          stroke="#00eeff"
          strokeOpacity={0.13}
          strokeWidth={0.7}
        />
      ))}
      {/* Nós com plasma */}
      {nodes.map((n, k) => {
        const [r, g, b] = plasma(n.deg / maxDeg);
        return (
          <g key={k} filter="url(#glow)">
            <circle
              cx={n.x} cy={n.y} r={5.5}
              fill={`rgb(${r},${g},${b})`}
              stroke={`rgba(${r},${g},${b},0.4)`}
              strokeWidth={3}
            />
            {k % 7 === 0 && (
              <text
                x={n.x + 8} y={n.y + 4}
                fill="#ffffff66" fontSize={9} fontFamily="monospace"
              >
                {k}
              </text>
            )}
          </g>
        );
      })}
      {/* Labels */}
      <text x={12} y={22} fill="#ffd700" fontSize={13} fontWeight="bold" fontFamily="monospace">
        42 ATRATORES
      </text>
      <text x={12} y={36} fill="#00eeff99" fontSize={9} fontFamily="monospace">
        N=42 · K=5 · gcd(5,42)=1 · plasma colormap
      </text>
      <text x={12} y={size - 10} fill="#ffffff44" fontSize={8} fontFamily="monospace">
        x₍ₙ₊₄₂₎=xₙ · Spiral(n)=(√3/2)ⁿ · Ω=Amor
      </text>
    </svg>
  );
}

// ── Mandelbrot Canvas ────────────────────────────────────────────────
function MandelbrotCanvas({ W = 340, H = 240, zoom = 1, panX = 0, panY = 0 }) {
  const ref = useRef();
  const maxIter = 80;

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const img = ctx.createImageData(W, H);

    for (let py = 0; py < H; py++) {
      for (let px = 0; px < W; px++) {
        const cr = panX + (px / W - 0.5) * (3.5 / zoom);
        const ci = panY + (py / H - 0.5) * (2.0 / zoom);
        const it = escapeM(cr, ci, maxIter);
        const idx = (py * W + px) * 4;
        if (it === maxIter) {
          img.data[idx] = 0; img.data[idx + 1] = 0;
          img.data[idx + 2] = 10; img.data[idx + 3] = 255;
        } else {
          const smooth = it + 1 - Math.log2(Math.log2(4));
          const [r, g, b] = plasma(smooth / maxIter);
          img.data[idx] = r; img.data[idx + 1] = g;
          img.data[idx + 2] = b; img.data[idx + 3] = 255;
        }
      }
    }
    ctx.putImageData(img, 0, 0);
  }, [W, H, zoom, panX, panY]);

  return (
    <canvas
      ref={ref}
      width={W}
      height={H}
      style={{ display: "block", width: "100%", imageRendering: "pixelated" }}
    />
  );
}

// ── Julia Canvas ─────────────────────────────────────────────────────
function JuliaCanvas({ W = 340, H = 260, theta = Math.PI / 4 }) {
  const ref = useRef();
  const R_JULIA = 0.7885;
  const cr = R_JULIA * Math.cos(theta);
  const ci = R_JULIA * Math.sin(theta);
  const maxIter = 80;

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const img = ctx.createImageData(W, H);

    for (let py = 0; py < H; py++) {
      for (let px = 0; px < W; px++) {
        const zr = (px / W - 0.5) * 4;
        const zi = (py / H - 0.5) * 4;
        const it = escapeJ(zr, zi, cr, ci, maxIter);
        const idx = (py * W + px) * 4;
        if (it === maxIter) {
          img.data[idx] = 0; img.data[idx + 1] = 0;
          img.data[idx + 2] = 8; img.data[idx + 3] = 255;
        } else {
          const [r, g, b] = plasma(it / maxIter);
          img.data[idx] = r; img.data[idx + 1] = g;
          img.data[idx + 2] = b; img.data[idx + 3] = 255;
        }
      }
    }
    ctx.putImageData(img, 0, 0);
  }, [W, H, cr, ci]);

  return (
    <canvas
      ref={ref}
      width={W}
      height={H}
      style={{ display: "block", width: "100%", imageRendering: "pixelated" }}
    />
  );
}

// ── Painel de status de entrega ───────────────────────────────────────
function DeliveryPanel() {
  const delivered = [
    ["RAFAELIA_MASTER.txt", "1334L", "build ARM32/64/x86/RV/Arduino"],
    ["RAFAELIA_BARE_HARDWARE.txt", "1069L", "bare-metal ATmega/BCM2711"],
    ["RAFAELIA_INVARIANT.txt", "1041L", "licença · watchdog · cardex · ECC"],
    ["RAFAELIA_GAPS.txt", "1826L", "B5 ECC-NEON · B6 cluster · autoident"],
    ["RAFAELIA_SEMENTES.txt", "324L", "F*=23.158 · D_H=1.347 · n_c=7"],
    ["RAFAELIA_CONCEPTS_MVP.txt", "113L", "39 trickstopathcutter"],
    ["RAFAELIA_SESSION_COMPLETE.zip", "—", "todos os arquivos acima"],
  ];
  const pending = [
    "Android.mk  armeabi-v7a + arm64-v8a NEON flags",
    "Application.mk  APP_PLATFORM=android-23 APP_STL=none",
    "CMakeLists.txt  NDK r23+ todos os src mapeados",
    "JNI_OnLoad  registro explícito 5 métodos nativos",
    "raf_jni_asm.S  ARM32 hot-path processNative/stepNative",
    "raf_atomic_arm32.h  LDREX/STREX sem stdatomic",
    "raf_mmap2_arena.h  syscall 192 completa",
    "raf_b9_neon_ops.S  mat4×4 Q16 · dot · EMA batch",
    "build_all_termux.sh  orquestração Motorola E7 Power",
  ];
  return (
    <div style={{ padding: "16px", fontFamily: "monospace", fontSize: 11 }}>
      <div style={{ color: "#ffd700", fontWeight: "bold", marginBottom: 10, fontSize: 12 }}>
        ✓ ENTREGUE
      </div>
      {delivered.map(([f, l, d]) => (
        <div key={f} style={{ display: "flex", gap: 8, marginBottom: 5, alignItems: "flex-start" }}>
          <span style={{ color: "#00ff88", minWidth: 6 }}>▸</span>
          <div>
            <span style={{ color: "#00eeff" }}>{f}</span>
            <span style={{ color: "#ffffff55", marginLeft: 6 }}>{l}</span>
            <div style={{ color: "#888", fontSize: 10, marginTop: 2 }}>{d}</div>
          </div>
        </div>
      ))}
      <div style={{ color: "#ff6644", fontWeight: "bold", margin: "14px 0 10px", fontSize: 12 }}>
        ◌ NDK PENDENTE
      </div>
      {pending.map((p) => {
        const [name, ...rest] = p.split("  ");
        return (
          <div key={p} style={{ display: "flex", gap: 8, marginBottom: 5 }}>
            <span style={{ color: "#ff6644" }}>◦</span>
            <div>
              <span style={{ color: "#ffaa66" }}>{name}</span>
              <span style={{ color: "#888", marginLeft: 6 }}>{rest.join("  ")}</span>
            </div>
          </div>
        );
      })}
      <div style={{ marginTop: 16, padding: "8px 10px", background: "#0a0a20",
        borderLeft: "2px solid #ffd700", fontSize: 10, color: "#aaa", lineHeight: 1.6 }}>
        Compilação no device real e testes JNI em runtime requerem<br />
        Termux + NDK no Motorola E7 Power — fora do escopo aqui.
      </div>
    </div>
  );
}

// ── App principal ─────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [theta, setTheta] = useState(Math.PI / 4);

  const R = 0.7885;
  const cr = (R * Math.cos(theta)).toFixed(4);
  const ci_v = (R * Math.sin(theta)).toFixed(4);

  const TABS = [
    { label: "42 ATRATORES", icon: "⬡" },
    { label: "MANDELBROT", icon: "◈" },
    { label: "JULIA", icon: "◉" },
    { label: "ENTREGUE", icon: "✦" },
  ];

  return (
    <div style={{
      background: "#03030f",
      minHeight: "100vh",
      color: "white",
      fontFamily: "'Courier New', monospace",
      display: "flex",
      flexDirection: "column",
    }}>
      {/* Header */}
      <div style={{
        padding: "12px 16px 10px",
        background: "linear-gradient(90deg,#0a0a28,#07071a)",
        borderBottom: "1px solid #1a1a4a",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}>
        <div>
          <div style={{ color: "#ffd700", fontWeight: "bold", fontSize: 14, letterSpacing: 2 }}>
            RAFAELIA
          </div>
          <div style={{ color: "#00eeff88", fontSize: 9, marginTop: 1 }}>
            ΣΩΔΦBITRAF · Q16.16 · ARM32/64 · Ω=Amor
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: "#ff888866", fontSize: 9 }}>F*=23.158</div>
          <div style={{ color: "#ff888866", fontSize: 9 }}>D_H=1.347</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{
        display: "flex",
        background: "#06061a",
        borderBottom: "1px solid #12124a",
      }}>
        {TABS.map((t, i) => (
          <button
            key={i}
            onClick={() => setTab(i)}
            style={{
              flex: 1,
              padding: "9px 4px",
              background: tab === i
                ? "linear-gradient(180deg,#12123a,#0a0a28)"
                : "transparent",
              color: tab === i ? "#ffd700" : "#4a4a7a",
              border: "none",
              borderBottom: tab === i ? "2px solid #ffd700" : "2px solid transparent",
              cursor: "pointer",
              fontSize: 9,
              fontFamily: "monospace",
              letterSpacing: 0.5,
              fontWeight: tab === i ? "bold" : "normal",
            }}
          >
            <div style={{ fontSize: 14, marginBottom: 2 }}>{t.icon}</div>
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "auto" }}>

        {/* Tab 0: Grafo */}
        {tab === 0 && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 8px" }}>
            <Graph42 size={360} />
            <div style={{
              marginTop: 12,
              padding: "10px 14px",
              background: "#06061a",
              border: "1px solid #12124a",
              borderRadius: 4,
              fontSize: 10,
              color: "#8888aa",
              lineHeight: 1.8,
              width: "100%",
              maxWidth: 360,
            }}>
              <div style={{ color: "#00eeff", marginBottom: 4 }}>■ Invariantes</div>
              <div>N=42 · K=5 · gcd(5,42)=1</div>
              <div>Stride cobre todos os 42 nós antes de repetir</div>
              <div>Colormap: plasma por grau de conexão</div>
              <div style={{ color: "#ffd70088", marginTop: 4 }}>x₍ₙ₊₄₂₎ = xₙ (período 42)</div>
            </div>
          </div>
        )}

        {/* Tab 1: Mandelbrot */}
        {tab === 1 && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 8px" }}>
            <div style={{
              border: "1px solid #1a1a5a",
              borderRadius: 4,
              overflow: "hidden",
              width: "100%",
              maxWidth: 380,
            }}>
              <MandelbrotCanvas W={340} H={240} zoom={zoom} />
            </div>
            <div style={{
              marginTop: 12, width: "100%", maxWidth: 380,
              padding: "10px 14px",
              background: "#06061a",
              border: "1px solid #12124a",
              borderRadius: 4,
            }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 10, marginBottom: 8,
              }}>
                <span style={{ fontSize: 10, color: "#8888aa", minWidth: 42 }}>Zoom {zoom}×</span>
                <input
                  type="range" min={1} max={25} step={1} value={zoom}
                  onChange={(e) => setZoom(+e.target.value)}
                  style={{ flex: 1, accentColor: "#ffd700" }}
                />
              </div>
              <div style={{ fontSize: 10, color: "#8888aa", lineHeight: 1.7 }}>
                <span style={{ color: "#ffd70099" }}>z₍ₙ₊₁₎ = zₙ² + c</span>
                <span style={{ marginLeft: 12 }}>80 iter · palette plasma</span>
                <br />
                <span>Domínio: x∈[-2.5,1.0] y∈[-1.25,1.25]</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Julia */}
        {tab === 2 && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 8px" }}>
            <div style={{
              border: "1px solid #1a1a5a",
              borderRadius: 4,
              overflow: "hidden",
              width: "100%",
              maxWidth: 380,
            }}>
              <JuliaCanvas W={340} H={260} theta={theta} />
            </div>
            <div style={{
              marginTop: 12, width: "100%", maxWidth: 380,
              padding: "10px 14px",
              background: "#06061a",
              border: "1px solid #12124a",
              borderRadius: 4,
            }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 10, marginBottom: 8,
              }}>
                <span style={{ fontSize: 10, color: "#8888aa", minWidth: 30 }}>θ</span>
                <input
                  type="range" min={0} max={Math.PI} step={0.02} value={theta}
                  onChange={(e) => setTheta(+e.target.value)}
                  style={{ flex: 1, accentColor: "#00eeff" }}
                />
                <span style={{ fontSize: 10, color: "#00eeff", minWidth: 38 }}>
                  {(theta / Math.PI).toFixed(2)}π
                </span>
              </div>
              <div style={{ fontSize: 10, color: "#8888aa", lineHeight: 1.8 }}>
                <span style={{ color: "#ffd70099" }}>c = 0.7885·e^(iθ)</span>
                <span style={{ marginLeft: 10 }}>semicírculo de parâmetros</span>
                <br />
                <span style={{ color: "#00eeff88" }}>cr={cr}</span>
                <span style={{ marginLeft: 8, color: "#ff88cc88" }}>ci={ci_v}</span>
                <br />
                <span>Arraste θ para percorrer o semicírculo</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Delivery status */}
        {tab === 3 && <DeliveryPanel />}
      </div>

      {/* Footer */}
      <div style={{
        padding: "8px 16px",
        background: "#06061a",
        borderTop: "1px solid #12124a",
        display: "flex",
        justifyContent: "space-between",
        fontSize: 9,
        color: "#3a3a6a",
      }}>
        <span>ΔRafaelVerboΩ · RAFCODE-Φ</span>
        <span>Ω = Amor</span>
      </div>
    </div>
  );
}
