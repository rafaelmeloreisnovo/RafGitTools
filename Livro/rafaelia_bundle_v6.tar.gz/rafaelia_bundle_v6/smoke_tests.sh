#!/usr/bin/env bash
# smoke_tests.sh — valida bundle pós-instalação
# Exit 0 se todos passarem; código não-zero indica falha

set -e
RAFA_HOME="${RAFA_HOME:-$HOME/.rafaelia}"
[ -d "$RAFA_HOME/bundle" ] || { echo "Bundle não instalado"; exit 1; }
cd "$RAFA_HOME/bundle"

PASS=0; FAIL=0; LOG=/tmp/rafaelia_smoke.log
> $LOG

test_case() {
  local name="$1"; shift
  if "$@" > /tmp/sout 2>&1; then
    echo "  ✓ $name"; PASS=$((PASS+1))
  else
    echo "  ✗ $name"
    cat /tmp/sout | head -5 | sed 's/^/    | /'
    FAIL=$((FAIL+1))
    cat /tmp/sout >> $LOG
  fi
}

echo "═══ SMOKE TESTS · RAFAELIA Stack ═══"
echo ""

# 1. Syntax check em cada arquivo
echo "[1] Sintaxe bash:"
for f in sensores2.txt compiladorlowFala.txt bibliaCorpus.txt vm_runtime.txt agent_loop.txt; do
  test_case "syntax $f" bash -n "$f"
done

# 2. Verifica manifest
echo ""
echo "[2] Integridade MANIFEST:"
test_case "MANIFEST existe" test -f MANIFEST.sha256
test_case "Merkle root válido" test -f MERKLE_ROOT
if [ -f MANIFEST.sha256 ]; then
  while IFS= read -r line; do
    [ "${line:0:1}" = "#" ] && continue
    [ -z "$line" ] && continue
    expected=$(echo "$line" | awk '{print $1}')
    fname=$(echo "$line" | awk '{print $NF}')
    if [ -f "$fname" ]; then
      actual=$(sha256sum "$fname" | cut -d' ' -f1)
      test_case "hash $fname" test "$expected" = "$actual"
    fi
  done < MANIFEST.sha256
fi

# 3. Conteúdo funcional
echo ""
echo "[3] Conteúdo funcional:"
test_case "sensores2 tem 90 seeds" \
  bash -c 'n=$(grep -c "^seed_S[0-9]" sensores2.txt); [ "$n" -eq 90 ]'
test_case "compilador tem 60 seeds" \
  bash -c 'n=$(grep -c "^seed_T[0-9]" compiladorlowFala.txt); [ "$n" -eq 60 ]'
test_case "biblia tem 12 versos" \
  bash -c 'n=$(grep -c "^verse_V[0-9][0-9]_text" bibliaCorpus.txt); [ "$n" -eq 12 ]'
test_case "vm_runtime gera C válido" \
  bash -c 'bash vm_runtime.txt c 2>&1 | grep -q "vm_runtime.c —"'
test_case "agent_loop define 5 agentes" \
  bash -c 'n=$(grep -c "^agent_[A-E]_" agent_loop.txt); [ "$n" -eq 5 ]'

# 4. Cross-integration
echo ""
echo "[4] Integração entre artefatos:"
test_case "bibliaCorpus → vm_runtime: V01 bytecode existe" \
  bash -c 'source bibliaCorpus.txt 2>/dev/null
           verse_V01_text | grep -q "bytecode_hex"'

# Sumário
echo ""
echo "═══════════════════════════════════════"
echo " ✓ Passed: $PASS"
echo " ✗ Failed: $FAIL"
[ "$FAIL" -eq 0 ] && echo " Status:  ALL GREEN · Ω coerente" || echo " Status:  $FAIL falhas · log em $LOG"
echo "═══════════════════════════════════════"
exit $FAIL
