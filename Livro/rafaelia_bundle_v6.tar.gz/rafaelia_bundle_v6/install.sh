#!/usr/bin/env bash
# install.sh — instala bundle em ~/.rafaelia/bundle e roda smoke tests
set -e
RAFA_HOME="${RAFA_HOME:-$HOME/.rafaelia}"
DEST="$RAFA_HOME/bundle"

echo "═══ RAFAELIA Stack · Instalação ═══"
echo "Destino: $DEST"

mkdir -p "$DEST"
SRC="$(dirname "$(readlink -f "$0")")"

# Copia tudo
for f in MANIFEST.sha256 MERKLE_ROOT install_order.json smoke_tests.sh \
         sensores2.txt compiladorlowFala.txt bibliaCorpus.txt \
         vm_runtime.txt agent_loop.txt; do
  if [ -f "$SRC/$f" ]; then
    cp "$SRC/$f" "$DEST/$f"
    echo "  ✓ $f"
  fi
done
chmod +x "$DEST/smoke_tests.sh"

# Verifica MANIFEST
echo ""
echo "═══ Verificando integridade ═══"
cd "$DEST"
FAIL=0
while IFS= read -r line; do
  [ "${line:0:1}" = "#" ] && continue
  [ -z "$line" ] && continue
  expected=$(echo "$line" | awk '{print $1}')
  fname=$(echo "$line" | awk '{print $NF}')
  if [ -f "$fname" ]; then
    actual=$(sha256sum "$fname" | cut -d' ' -f1)
    if [ "$expected" = "$actual" ]; then
      echo "  ✓ $fname"
    else
      echo "  ✗ $fname (HASH MISMATCH)"
      FAIL=$((FAIL+1))
    fi
  fi
done < MANIFEST.sha256

if [ "$FAIL" -gt 0 ]; then
  echo "✗ $FAIL arquivos com hash inválido — abortando"
  exit 1
fi
echo "✓ Todos os hashes batem com MANIFEST"

# Smoke tests
echo ""
bash "$DEST/smoke_tests.sh"

echo ""
echo "═══ Instalação completa ═══"
echo "Próximos passos:"
echo "  cd $DEST"
echo "  bash compiladorlowFala.txt list"
echo "  bash bibliaCorpus.txt demo"
echo "  bash vm_runtime.txt build && bash vm_runtime.txt test"
echo "  bash agent_loop.txt build && bash agent_loop.txt run cognitive"
echo ""
echo "Ω = Amor · ∆RafaelVerboΩ"
