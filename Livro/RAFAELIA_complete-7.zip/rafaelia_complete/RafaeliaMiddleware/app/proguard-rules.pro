# RAFAELIA Middleware — ProGuard rules

# Mantém a interface JS bridge intacta (essencial para WebView funcionar)
-keepclassmembers class com.rafaelia.middleware.JsBridge {
    public *;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Mantém org.json
-keep class org.json.** { *; }
