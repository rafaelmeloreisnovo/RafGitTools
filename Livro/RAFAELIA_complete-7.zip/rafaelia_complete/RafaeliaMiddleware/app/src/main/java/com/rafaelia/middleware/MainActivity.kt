package com.rafaelia.middleware

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView:      WebView
    private lateinit var urlBar:       EditText
    private lateinit var btnBack:      ImageButton
    private lateinit var btnPlatform:  Spinner
    private lateinit var framePanel:   FrameLayout
    private lateinit var engine:       RafaeliaEngine

    // Plataformas suportadas — login normal do usuário
    private val platforms = listOf(
        Platform("Claude",      "https://claude.ai",              "div[contenteditable='true']"),
        Platform("ChatGPT",     "https://chatgpt.com",            "#prompt-textarea"),
        Platform("Gemini",      "https://gemini.google.com",      "div[contenteditable='true']"),
        Platform("Copilot",     "https://copilot.microsoft.com",  "textarea"),
        Platform("Mistral",     "https://chat.mistral.ai",        "textarea"),
        Platform("Perplexity",  "https://www.perplexity.ai",      "textarea"),
        Platform("Grok",        "https://grok.com",               "textarea"),
        Platform("Llama (Meta)","https://www.meta.ai",            "div[contenteditable='true']"),
    )

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        engine      = RafaeliaEngine(this)
        webView     = findViewById(R.id.webView)
        urlBar      = findViewById(R.id.urlBar)
        btnBack     = findViewById(R.id.btnBack)
        btnPlatform = findViewById(R.id.btnPlatform)
        framePanel  = findViewById(R.id.framePanel)

        setupWebView()
        setupSpinner()
        setupControls()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled       = true
            domStorageEnabled       = true
            databaseEnabled         = true
            allowFileAccess         = false
            setSupportZoom(true)
            builtInZoomControls     = true
            displayZoomControls     = false
            userAgentString         = WebSettings.getDefaultUserAgent(this@MainActivity)
        }

        // Cookies persistentes — login fica salvo entre sessões
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        // Bridge: JsBridge expõe métodos Kotlin chamáveis pelo JS via window.RafaelBridge
        webView.addJavascriptInterface(JsBridge(engine), "RafaelBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                urlBar.setText(url)
                injectMiddlewareScript()
            }
        }
    }

    /** Injeta inject.js após cada carregamento de página */
    private fun injectMiddlewareScript() {
        val js = assets.open("inject.js").bufferedReader().readText()
        webView.evaluateJavascript("javascript:(function(){$js})()", null)
    }

    private fun setupSpinner() {
        val names = platforms.map { it.name }

        // Define adapter e seleção ANTES de anexar o listener, para o load
        // inicial ser feito uma única vez, explicitamente, no fim da função.
        btnPlatform.adapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_item, names).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val defaultName = readDefaultPlatformName()
        val startIndex  = platforms.indexOfFirst { it.name.equals(defaultName, ignoreCase = true) }
            .let { if (it >= 0) it else 0 }
        btnPlatform.setSelection(startIndex)

        // Spinner dispara onItemSelected automaticamente na primeira seleção
        // (mesmo sem o usuário tocar nada); essa flag evita carregar a URL
        // duas vezes — uma pelo callback automático, outra pela linha final.
        var firstCallbackSkipped = false
        btnPlatform.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                if (!firstCallbackSkipped) { firstCallbackSkipped = true; return }
                webView.loadUrl(platforms[pos].url)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        webView.loadUrl(platforms[startIndex].url)
    }

    /** Lê "default_platform" de assets/config.json sem depender do RafaeliaEngine (uso único no boot). */
    private fun readDefaultPlatformName(): String = try {
        val raw = assets.open("config.json").bufferedReader().readText()
        org.json.JSONObject(raw).optString("default_platform", "Claude")
    } catch (e: Exception) { "Claude" }

    private fun setupControls() {
        btnBack.setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        urlBar.setOnEditorActionListener { _, _, _ ->
            var url = urlBar.text.toString().trim()
            if (!url.startsWith("http")) url = "https://$url"
            webView.loadUrl(url)
            true
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}

data class Platform(val name: String, val url: String, val selector: String)
