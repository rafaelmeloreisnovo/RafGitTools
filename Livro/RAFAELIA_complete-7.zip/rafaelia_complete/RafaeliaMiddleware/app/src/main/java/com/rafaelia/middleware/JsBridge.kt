package com.rafaelia.middleware

import android.webkit.JavascriptInterface

/**
 * JsBridge
 * Exposto ao JavaScript do WebView como window.RafaelBridge.
 *
 * Única responsabilidade: dado o texto do usuário, calcular o texto
 * enriquecido. O inject.js insere esse texto no DOM e clica em enviar —
 * tudo do lado JS, em uma única chamada síncrona à ponte. Não há
 * round-trip Kotlin→JS de volta, evitando dupla manipulação do campo.
 */
class JsBridge(private val engine: RafaeliaEngine) {

    /** Lista de frames disponíveis (debug / painel de configuração). */
    @JavascriptInterface
    fun getFrames(): String = engine.listFramesJson()

    /** Config bruta (preview_panel_enabled, auto_submit_after_confirm, etc). */
    @JavascriptInterface
    fun getConfig(): String = engine.configJson()

    /**
     * Dado o texto atual no campo da IA, retorna o texto enriquecido
     * com o bloco de contexto RAFAELIA. Chamado pelo inject.js antes
     * de mostrar o painel de preview, e novamente (mesmo resultado,
     * determinístico) para montar o texto final após confirmação.
     */
    @JavascriptInterface
    fun previewEnrich(userText: String): String = engine.enrich(userText)
}

