package com.rafaelia.middleware

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * RafaeliaEngine
 * Carrega os frames RAFAELIA e, dado o texto do usuário,
 * seleciona os frames mais relevantes e monta o prompt enriquecido.
 *
 * Fluxo:
 *   texto_usuario → tokenize → score frames → top-K → montar bloco → retorno
 */
class RafaeliaEngine(context: Context) {

    data class Frame(
        val id:       String,
        val name:     String,
        val content:  String,
        val tags:     List<String>,
        val level:    Int,          // T7 nível 1–7
        val path:     String,       // URGENT / MENOSPREZADO / SEED
        val ic:       Double,       // information concentration
        val pp:       Double,       // production pressure
    )

    private val frames: List<Frame>
    private val config: JSONObject

    init {
        // Carrega frames_seed.json do assets
        val raw = context.assets.open("frames_seed.json")
            .bufferedReader().readText()
        val arr  = JSONArray(raw)
        frames = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val tagsArr = o.optJSONArray("tags") ?: JSONArray()
            Frame(
                id      = o.optString("id",""),
                name    = o.optString("name",""),
                content = o.optString("content",""),
                tags    = (0 until tagsArr.length()).map { tagsArr.getString(it) },
                level   = o.optInt("level", 3),
                path    = o.optString("path","SEED"),
                ic      = o.optDouble("IC", 0.0),
                pp      = o.optDouble("PP", 0.0),
            )
        }

        // Config: quantos frames, modo de montagem
        val cfgRaw = try {
            context.assets.open("config.json").bufferedReader().readText()
        } catch (e: Exception) { "{}" }
        config = JSONObject(cfgRaw)
    }

    /**
     * Dado o texto que o usuário está prestes a enviar,
     * retorna o prompt enriquecido pronto para submissão.
     */
    fun enrich(userText: String): String {
        val topK      = config.optInt("top_k_frames", 3)
        val maxChars  = config.optInt("max_context_chars", 1200)
        val showSig   = config.optBoolean("show_signature", true)
        val minScore  = config.optDouble("min_score_threshold", 0.05)

        // Tokeniza input do usuário
        val tokens = tokenize(userText)

        // Pontua cada frame por relevância
        val scored = frames.map { frame ->
            val score = scoreFrame(frame, tokens)
            Pair(score, frame)
        }.sortedByDescending { it.first }

        // Seleciona top-K acima do threshold mínimo, priorizando URGENT > MENOSPREZADO > SEED
        val selected = scored
            .filter { it.first >= minScore }
            .sortedWith(compareByDescending<Pair<Double, Frame>> {
                when (it.second.path) {
                    "URGENT"       -> 3.0
                    "MENOSPREZADO" -> 2.0
                    else           -> 1.0
                } * it.first
            })
            .take(topK)
            .map { it.second }

        // Se nenhum frame relevante, usa o frame de identidade padrão
        val toUse = if (selected.isEmpty()) listOf(frames.first()) else selected

        return buildPrompt(userText, toUse, maxChars, showSig)
    }

    /** Tokenização simples: lowercase + split por não-alfanum */
    private fun tokenize(text: String): Set<String> =
        text.lowercase()
            .split(Regex("[^a-záéíóúàãõüç0-9_]+"))
            .filter { it.length >= 3 }
            .toSet()

    /** Score de um frame contra os tokens do input */
    private fun scoreFrame(frame: Frame, tokens: Set<String>): Double {
        var score = 0.0
        val frameTokens = tokenize(frame.name + " " + frame.content + " " + frame.tags.joinToString(" "))

        // Interseção de tokens
        val common = tokens.intersect(frameTokens).size
        if (common == 0) return 0.0

        score += common.toDouble() / maxOf(1, tokens.size).toDouble()

        // Boost por IC e PP
        score += frame.ic * 0.3
        score += frame.pp * 0.2

        // Boost por nível T7 (quanto maior, mais específico)
        score += frame.level * 0.05

        return score
    }

    /** Monta o bloco de contexto + texto do usuário, respeitando maxChars como orçamento global */
    private fun buildPrompt(
        userText: String,
        frames:   List<Frame>,
        maxChars: Int,
        showSig:  Boolean,
    ): String {
        val sb = StringBuilder()
        val perFrameBudget = maxOf(80, maxChars / maxOf(1, frames.size))

        sb.appendLine("╔═[RAFAELIA·CONTEXT]═══════════════════")
        var used = 0
        for ((i, f) in frames.withIndex()) {
            if (used >= maxChars) break  // orçamento global esgotado, para de adicionar frames

            val dim = listOf("ψ","χ","ρ","Δ","Σ","Ω","T⁷").getOrElse(f.level - 1) { "T⁷" }
            val remaining = maxChars - used
            val budget    = minOf(perFrameBudget, remaining)
            val excerpt   = if (f.content.length > budget) f.content.take(budget) + "…" else f.content

            sb.appendLine("║ [${i+1}] ${f.name} · L${f.level}·$dim · ${f.path}")
            sb.appendLine(excerpt)
            used += excerpt.length

            if (i < frames.size - 1) sb.appendLine("╠───────────────────────────────────────")
        }
        sb.appendLine("╚═══════════════════════════════════════")
        if (showSig) sb.appendLine("RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ")
        sb.appendLine()
        sb.append(userText)

        return sb.toString()
    }

    // ── API para o JsBridge ─────────────────────────────────────────

    /** Retorna o config.json bruto, para o inject.js ler flags de comportamento. */
    fun configJson(): String = config.toString()

    /** Retorna JSON com frames disponíveis (para o painel de preview) */
    fun listFramesJson(): String {
        val arr = JSONArray()
        frames.take(20).forEach { f ->
            arr.put(JSONObject().apply {
                put("id", f.id); put("name", f.name)
                put("path", f.path); put("level", f.level)
                put("IC", f.ic); put("PP", f.pp)
            })
        }
        return arr.toString()
    }
}
