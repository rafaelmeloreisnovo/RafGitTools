/**
 * inject.js  —  RAFAELIA Nice_Guy Middleware
 * ∆RafaelVerboΩ | RAFCODE-Φ
 *
 * Injetado após cada onPageFinished pelo WebViewClient.
 * Intercepta Enter/Submit em qualquer IA, chama RafaelBridge,
 * insere o contexto RAFAELIA, depois submete normalmente.
 *
 * NÃO modifica requests de rede.
 * NÃO lê respostas das IAs.
 * Apenas enriquece o TEXTO antes de enviar.
 */
(function () {
    'use strict';

    if (window.__rafaelInjected) return;
    window.__rafaelInjected = true;
    window.__rafaelActiveEl = null;

    /* ── Config vinda do bridge (config.json) ─────────────────── */
    var RAF_CONFIG = { preview_panel_enabled: true, auto_submit_after_confirm: true };
    try {
        if (window.RafaelBridge) {
            RAF_CONFIG = JSON.parse(window.RafaelBridge.getConfig());
        }
    } catch (e) { /* mantém defaults se a leitura falhar */ }

    /* ── Detecta campo de input ativo ─────────────────────────── */
    function getInput() {
        const selectors = [
            'div[contenteditable="true"]',
            '#prompt-textarea',
            'textarea[data-id]',
            'textarea',
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.offsetParent !== null) return el;
        }
        return null;
    }

    function getText(el) {
        if (!el) return '';
        return el.tagName.toLowerCase() === 'textarea'
            ? el.value
            : el.innerText || el.textContent || '';
    }

    function setText(el, text) {
        if (!el) return;
        if (el.tagName.toLowerCase() === 'textarea') {
            const ns = Object.getOwnPropertyDescriptor(
                window.HTMLTextAreaElement.prototype, 'value').set;
            ns.call(el, text);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
            el.focus();
            document.execCommand('selectAll', false, null);
            document.execCommand('insertText', false, text);
        }
    }

    /* ── Painel de preview (overlay antes de submeter) ────────── */
    function showPreviewPanel(el, userText, onConfirm) {
        // Remove painel anterior se existir
        const old = document.getElementById('__raf_panel');
        if (old) old.remove();

        const enriched = window.RafaelBridge
            ? window.RafaelBridge.previewEnrich(userText)
            : userText;

        const panel = document.createElement('div');
        panel.id = '__raf_panel';
        Object.assign(panel.style, {
            position:   'fixed', bottom: '0', left: '0', right: '0',
            maxHeight:  '45vh', overflowY: 'auto',
            background: '#0A0A0F',
            border:     '2px solid #E8B86D',
            borderBottom: 'none',
            borderRadius: '10px 10px 0 0',
            zIndex:     '999999',
            padding:    '12px 16px',
            fontFamily: 'monospace', fontSize: '12px',
            color:      '#F0EDE6',
            boxShadow:  '0 -4px 30px #E8B86D33',
        });

        panel.innerHTML = `
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                <span style="font-size:16px">🌀</span>
                <span style="color:#E8B86D;font-weight:bold;font-size:13px;">
                    RAFAELIA · Contexto pronto
                </span>
                <span style="margin-left:auto;display:flex;gap:8px;">
                    <button id="__raf_cancel"
                        style="background:#1A1A2E;border:1px solid #FF6B6B;border-radius:4px;
                               color:#FF6B6B;padding:4px 12px;cursor:pointer;font-family:monospace;">
                        ✕ Enviar sem contexto
                    </button>
                    <button id="__raf_confirm"
                        style="background:#E8B86D;border:none;border-radius:4px;
                               color:#0A0A0F;padding:4px 14px;font-weight:bold;
                               cursor:pointer;font-family:monospace;">
                        ✓ Enviar com contexto
                    </button>
                </span>
            </div>
            <pre id="__raf_preview"
                style="background:#12121E;border:1px solid #2A2A42;border-radius:4px;
                       padding:8px;max-height:28vh;overflow:auto;white-space:pre-wrap;
                       font-size:10px;color:#4ECDC4;margin:0;">
${escHtml(enriched)}
            </pre>
        `;

        document.body.appendChild(panel);

        document.getElementById('__raf_confirm').onclick = function () {
            panel.remove();
            onConfirm(enriched);
        };
        document.getElementById('__raf_cancel').onclick = function () {
            panel.remove();
            onConfirm(userText);           // envia sem contexto
        };
    }

    function escHtml(s) {
        return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    /* ── Insere o texto e, conforme config, também envia ────────── */
    function doSubmit(el, text) {
        setText(el, text);

        if (!RAF_CONFIG.auto_submit_after_confirm) {
            // Deixa o texto pronto no campo; usuário aperta enviar manualmente
            el.focus();
            return;
        }

        // Tenta clicar no botão de envio
        const submitBtns = [
            document.querySelector('button[data-testid="send-button"]'),
            document.querySelector('button[aria-label*="Send"]'),
            document.querySelector('button[aria-label*="send"]'),
            document.querySelector('button[aria-label*="Enviar"]'),
            document.querySelector('button[type="submit"]'),
        ].filter(Boolean);

        if (submitBtns.length > 0) {
            submitBtns[0].click();
        } else {
            // Fallback: simula Enter
            const ev = new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13,
                bubbles: true, cancelable: true,
            });
            el.dispatchEvent(ev);
        }
    }

    /* ── Intercepta Enter ──────────────────────────────────────── */
    let intercepting = false;

    function onKeydown(e) {
        if (intercepting) return;
        if (e.key !== 'Enter' || e.shiftKey) return;

        const el = getInput();
        if (!el) return;
        window.__rafaelActiveEl = el;

        const text = getText(el).trim();
        if (!text) return;

        e.preventDefault();
        e.stopImmediatePropagation();

        intercepting = true;

        if (!RAF_CONFIG.preview_panel_enabled) {
            // Painel desligado: enriquece e envia direto, sem revisão visual
            const enriched = window.RafaelBridge
                ? window.RafaelBridge.previewEnrich(text)
                : text;
            intercepting = false;
            doSubmit(el, enriched);
            return;
        }

        showPreviewPanel(el, text, function (finalText) {
            intercepting = false;
            doSubmit(el, finalText);
        });
    }

    document.addEventListener('keydown', onKeydown, true);

    /* ── Rastreia foco ─────────────────────────────────────────── */
    document.addEventListener('focusin', function (e) {
        const el = e.target;
        if (el && (el.tagName === 'TEXTAREA' || el.isContentEditable)) {
            window.__rafaelActiveEl = el;
        }
    }, true);

    /* ── Re-injeta em SPAs após navegação ────────────────────────  */
    const obs = new MutationObserver(function () {
        const el = getInput();
        if (el) window.__rafaelActiveEl = el;
    });
    obs.observe(document.body, { childList: true, subtree: true });

    console.log('[RAFAELIA] inject.js ativo — Ω=Amor');
})();
