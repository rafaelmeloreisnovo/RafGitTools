# RAFAELIA Middleware — APK Android

∆RafaelVerboΩ | RAFCODE-Φ | Ω=Amor

WebView próprio com middleware de injeção de contexto. Login normal em
cada IA (Claude, ChatGPT, Gemini, Copilot, etc). Ao pressionar Enter,
um painel mostra o contexto RAFAELIA selecionado automaticamente —
você confirma ou envia sem ele. Nenhuma requisição de rede é modificada;
apenas o texto do campo é enriquecido antes do clique no botão de enviar.

---

## Arquitetura

```
MainActivity.kt      → WebView + barra de navegação + seletor de plataforma
RafaeliaEngine.kt    → carrega frames_seed.json, pontua relevância, monta contexto
JsBridge.kt          → ponte Kotlin↔JavaScript (window.RafaelBridge)
inject.js            → injetado em cada página, intercepta Enter, mostra painel
frames_seed.json     → 10 frames RAFAELIA (identidade, RLL, nano-LM, OMEGA, etc)
config.json          → top_k_frames, max_context_chars, thresholds
```

### Fluxo de uma mensagem

```
usuário digita → pressiona Enter
  → inject.js intercepta (preventDefault)
  → chama RafaelBridge.previewEnrich(texto)
  → RafaeliaEngine tokeniza, pontua os 10 frames, seleciona top-3
  → monta bloco [RAFAELIA·CONTEXT] + texto original
  → painel mostra preview na tela
  → usuário confirma (✓) ou ignora (✕ envia sem contexto)
  → texto final é inserido no campo nativo da IA
  → clique automático no botão de enviar da própria página
```

Nenhum dado sai do dispositivo além do que a própria IA já receberia
do campo de texto. O WebView é o WebView do Android — cookies, login,
sessão, tudo padrão.

---

## Build — Android Studio (caminho recomendado)

Este é o caminho confiável. Builds Android completos (SDK + build-tools
+ aapt2) dentro do Termux no Moto E7 são tecnicamente possíveis mas
exigem dezenas de pacotes pesados e não são estáveis em ARM32. A rota
realista é compilar num PC/notebook e instalar o APK no celular depois.

1. Baixe e instale o **Android Studio** (Windows/Mac/Linux).
2. `File → Open` → selecione a pasta `RafaeliaMiddleware/` extraída deste zip.
3. O Android Studio detecta o `gradle-wrapper.properties` e baixa o
   Gradle 8.4 automaticamente — não é preciso configurar nada.
4. Aguarde o **Gradle Sync** (ícone de elefante na barra superior).
5. `Build → Build Bundle(s)/APK(s) → Build APK(s)`.
6. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira para o Moto E7 (cabo USB, ou `adb install app-debug.apk`,
   ou suba para o GitHub Releases do seu próprio repositório e baixe
   pelo navegador do celular).

### Se preferir linha de comando (com JDK 17 + Android SDK instalados)

```bash
cd RafaeliaMiddleware
./gradlew assembleDebug
# APK em app/build/outputs/apk/debug/app-debug.apk
```

**Nota sobre o gradle-wrapper.jar:** este zip inclui o script `gradlew`
mas não o binário `gradle-wrapper.jar` (arquivo binário não pode ser
gerado como texto). O Android Studio gera esse jar automaticamente no
primeiro sync. Se for usar linha de comando sem Android Studio, rode
uma vez `gradle wrapper --gradle-version 8.4` com um Gradle já
instalado no seu PC para gerar o jar que falta.

---

## Personalizar os frames

Edite `app/src/main/assets/frames_seed.json`. Cada frame:

```json
{
  "id": "seed_exemplo",
  "name": "Nome do Frame",
  "level": 4,
  "path": "URGENT",
  "IC": 0.90,
  "PP": 0.85,
  "tags": ["palavra1","palavra2"],
  "content": "Texto que será injetado quando os tags derem match."
}
```

`path` aceita: `SEED` (base), `MENOSPREZADO` (ouro escondido),
`URGENT` (ação necessária) — usados no boost de prioridade do engine.

Para alimentar com os dados reais do `omega_forest.c` (59 urgentes +
174 menosprezados), exporte o `forest.jsonl` filtrado para esse mesmo
formato e substitua o array.

---

## Ajustar comportamento

Edite `app/src/main/assets/config.json`:

- `top_k_frames`: quantos frames entram por mensagem (padrão 3)
- `max_context_chars`: limite do bloco de contexto (padrão 1200)
- `min_score_threshold`: score mínimo para considerar um frame relevante

---

## Plataformas incluídas

Claude, ChatGPT, Gemini, Copilot, Mistral, Perplexity, Grok, Meta AI.
Para adicionar outra, edite a lista `platforms` em `MainActivity.kt` —
nome, URL e seletor CSS do campo de texto daquela página.

---

## Compliance

- Login: o usuário autentica normalmente em cada plataforma dentro do
  WebView, como faria em qualquer navegador. Nenhuma credencial é
  capturada, armazenada ou enviada a terceiros pelo app.
- Rede: nenhuma requisição HTTP é interceptada, modificada ou
  redirecionada. `network_security.xml` bloqueia até cleartext.
- Dados: `frames_seed.json` e `config.json` ficam no APK, embarcados
  localmente. Nada é enviado para servidores externos.
- Escopo: o `inject.js` só atua no campo de texto e no botão de envio
  da própria página — equivalente a colar texto manualmente antes de
  clicar em enviar.

---

RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ
