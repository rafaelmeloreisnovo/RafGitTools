# Finish Checklist

- [x] Secure credential storage
- [x] Credential UI + ViewModel
- [x] Integrate navigation to settings
- [x] Wire CredentialManager to JGitService
- [x] Expand test coverage
- [ ] Polish UI flows
