# Build (Local + CI)

> **Goal:** `./gradlew assembleDevDebug` buildar sem dor (Android Studio / CLI / CI).

---

## ✅ Requisitos (toolchain)

- **JDK 17**
- **Gradle Wrapper** (já vem no repo)
- **Android SDK**
  - `platforms;android-36`
  - `build-tools;35.0.0`
  - `platform-tools`

> AGP **8.13.x** suporta no máximo **API 36** e usa por padrão **Build Tools 35.0.0** (compatibilidade oficial).  

---

## 🧪 Build local (Android Studio)

1. Instale Android Studio e configure o **SDK Manager**.
2. Em **SDK Platforms**: marque **Android 16 / API 36**.
3. Em **SDK Tools**: marque **Android SDK Build-Tools 35.0.0** + **Platform-Tools**.
4. Abra o projeto e rode:
   - `devDebug` (mais leve pra iterar)
   - ou `productionDebug`

---

## 🧰 Build local (CLI com `sdkmanager`)

Se você tem o SDK instalado e o `sdkmanager` disponível:

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"   # ajuste
export ANDROID_HOME="$ANDROID_SDK_ROOT"

# instala o mínimo necessário para compileSdk 36 + AGP 8.13.x
./scripts/ci/install_android_sdk_packages.sh

# builda
./gradlew --no-daemon clean assembleDevDebug
```

---

## 🤖 Build via GitHub Actions (recomendado no celular)

Se você está no **Termux/Android** e quer **APK compilado sem SDK local**:

1. Faça push do repo para o GitHub (ou abra PR).
2. Abra **Actions → CI**.
3. Baixe o artifact `apk-devDebug` (ou o variant que você quiser).

> Obs: os workflows instalam os pacotes do SDK automaticamente via `scripts/ci/install_android_sdk_packages.sh`.

---

## 🔥 Troubleshooting rápido

### `Failed to find target with hash string 'android-36'`
→ falta instalar **platforms;android-36**.

### `Failed to find Build Tools revision 35.0.0`
→ falta instalar **build-tools;35.0.0**.

### Java / Kotlin / Gradle incompatível
- JDK precisa ser **17**
- Gradle wrapper precisa ser **8.13**
- AGP precisa ser **8.13.x**

---

## 🧾 Comandos úteis

```bash
./gradlew tasks
./gradlew :app:dependencies
./gradlew :app:assembleDevDebug --stacktrace --info
```

