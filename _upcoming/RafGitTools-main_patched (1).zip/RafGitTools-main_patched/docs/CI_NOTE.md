# CI Notes (GitHub Actions)

Este repo usa Actions major versions recentes (ex.: `actions/checkout@v6`, `actions/upload-artifact@v6`).
Em runners **GitHub-hosted** isso costuma funcionar direto.

Se você usa **self-hosted** ou **GHES**, confira se o runner está atualizado para suportar Actions que rodam em Node.js 24.

