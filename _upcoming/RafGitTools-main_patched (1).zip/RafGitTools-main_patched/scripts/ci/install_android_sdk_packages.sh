#!/usr/bin/env bash
set -euo pipefail

# RafGitTools CI helper: ensure required Android SDK packages exist.
# Compatible with GitHub-hosted runners and most local SDK installs.

# Resolve SDK root
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "${SDK_ROOT}" ]]; then
  # Common default for GitHub-hosted runners
  if [[ -d "${HOME}/android-sdk" ]]; then
    SDK_ROOT="${HOME}/android-sdk"
  elif [[ -d "${HOME}/.android/sdk" ]]; then
    SDK_ROOT="${HOME}/.android/sdk"
  fi
fi

if [[ -z "${SDK_ROOT}" || ! -d "${SDK_ROOT}" ]]; then
  echo "❌ ANDROID_SDK_ROOT/ANDROID_HOME not set or not found. SDK_ROOT='${SDK_ROOT:-}'" >&2
  echo "   Tip: in GitHub Actions, run android-actions/setup-android first." >&2
  exit 2
fi

export ANDROID_SDK_ROOT="${SDK_ROOT}"
export ANDROID_HOME="${SDK_ROOT}"

# Find sdkmanager
SDKMANAGER="${SDK_ROOT}/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "${SDKMANAGER}" ]]; then
  # Some setups use numbered cmdline-tools (e.g. 16.0) or 'bin' directly
  SDKMANAGER_CANDIDATES=(
    "${SDK_ROOT}/cmdline-tools/*/bin/sdkmanager"
    "${SDK_ROOT}/tools/bin/sdkmanager"
  )
  for cand in ${SDKMANAGER_CANDIDATES[@]}; do
    if [[ -x ${cand} ]]; then SDKMANAGER="${cand}"; break; fi
  done
fi

if [[ ! -x "${SDKMANAGER}" ]]; then
  echo "❌ sdkmanager not found under: ${SDK_ROOT}" >&2
  echo "   Expected something like: cmdline-tools/latest/bin/sdkmanager" >&2
  exit 3
fi

echo "✅ SDK_ROOT=${SDK_ROOT}"
echo "✅ sdkmanager=${SDKMANAGER}"

# Accept licenses (non-interactive)
yes | "${SDKMANAGER}" --licenses >/dev/null || true

# Required by AGP 8.13.x compatibility matrix:
# - compileSdk can be 36, but Build Tools default is 35.0.0.
#   See AGP 8.13 compatibility table.
REQ_PKGS=(
  "platform-tools"
  "platforms;android-36"
  "build-tools;35.0.0"
)

echo "📦 Installing required SDK packages:"
printf " - %s\n" "${REQ_PKGS[@]}"

"${SDKMANAGER}" --install "${REQ_PKGS[@]}"

echo "✅ Android SDK packages installed."
