#!/usr/bin/env bash
set -euo pipefail

# Faz 1 commit WIP único (pra parar a hemorragia de 200 commits 😅)
# Uso: ./scripts/git/one_wip_commit.sh "WIP: salvage"

MSG="${1:-WIP: salvage}"
git status --porcelain >/dev/null || { echo "Não parece ser um repo git aqui."; exit 2; }

git add -A
if git diff --cached --quiet; then
  echo "Nada staged. Nada a commitar."
  exit 0
fi

git commit -m "$MSG"
echo "✅ Commit criado: $MSG"
